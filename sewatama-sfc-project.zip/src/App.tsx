import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  db,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  onSnapshot,
  testConnection,
  handleFirestoreError,
  OperationType,
} from './firebase';
import { CAPACITOR_SOURCE_FILES } from './sourceFilesData';
import {
  Calculator,
  FileSpreadsheet,
  Settings,
  Code2,
  Copy,
  Check,
  Download,
  Plus,
  Trash2,
  LogOut,
  RotateCcw,
  Sparkles,
  Pencil,
  Share2,
  TrendingUp,
  X,
} from 'lucide-react';

const SESSION_KEY = 'sewatama_sfc_operator_session';
const LOCAL_SETTINGS_KEY = 'sewatama_sfc_baseline_settings';
const LOCAL_LOGS_BACKUP_KEY = 'sewatama_sfc_local_logs_backup';
const DAILY_LOGS_COLLECTION = 'daily_logs';
const SETTINGS_COLLECTION = 'settings';
const BASELINE_DOC_ID = 'baseline_config';
const FULL_TANK_VALUE = '14000';
const STANDARD_TANK_NUMBER = 14000;

// Batas Kontrak SFC (0.2800 s/d 0.2842 = Hijau, > 0.2842 = Merah, < 0.2800 = Kuning)
const SFC_CONTRACT_MIN = 0.2800;
const SFC_CONTRACT_MAX = 0.2842;

export interface DailyLogRecord {
  dateId: string;
  displayDate: string;
  timestamp: number;
  flowmeterToday: string;
  flowmeterReference: string;
  referenceSource: 'YESTERDAY' | 'BASELINE' | 'MANUAL_OVERRIDE';
  fuelConsumed: number;
  totalKwhProduced: number;
  sfc: number;
  sfcFormatted: string;
  kwhBlocks: Record<string, string>;
  blockReferences?: Record<string, string>;
  meterReplacements?: Record<string, boolean>;
  tankLevels: Record<string, number>;
  tankVariance?: number;
  tankRemark?: string;
  operator: string;
}

export interface AppSettingsState {
  flowmeterBaseline: string;
  blocks: string[];
  tanks: string[];
  blockBaselines: Record<string, string>;
}

const DEFAULT_SETTINGS: AppSettingsState = {
  flowmeterBaseline: '1250000',
  blocks: ['Blok 1', 'Blok 2'],
  tanks: ['Tangki 1', 'Tangki 2'],
  blockBaselines: {
    'Blok 1': '4500000.00',
    'Blok 2': '4800000.00',
  },
};

function sanitizeDigits(value: string): string {
  return String(value || '')
    .replace(/[^0-9]/g, '')
    .slice(0, 15);
}

/**
 * Validasi input Metering kWh: mendukung hingga 15 digit bulat + maksimal 2 angka di belakang koma/titik.
 */
function sanitizeKwhDecimal(value: string): string {
  const normalized = String(value || '').replace(/,/g, '.');
  const cleaned = normalized.replace(/[^0-9.]/g, '');
  const parts = cleaned.split('.');
  const intPart = (parts[0] || '').slice(0, 15);
  if (parts.length > 1) {
    const decPart = parts.slice(1).join('').slice(0, 2);
    return `${intPart}.${decPart}`;
  }
  return intPart;
}

/**
 * Konversi string kWh (maks 2 desimal) menjadi Scaled BigInt (dikali 100n)
 */
function parseKwhToScaledBigInt(valueStr: string): bigint {
  const clean = sanitizeKwhDecimal(valueStr);
  if (!clean) return 0n;
  const [intPartRaw = '0', decPartRaw = ''] = clean.split('.');
  const intDigits = intPartRaw.replace(/[^0-9]/g, '') || '0';
  const decDigits = decPartRaw.replace(/[^0-9]/g, '').slice(0, 2).padEnd(2, '0');
  return BigInt(intDigits + decDigits);
}

function formatKwhDisplay(val: number | string | undefined): string {
  const num = Number(val ?? 0);
  if (Number.isNaN(num)) return '0,00';
  return num.toLocaleString('id-ID', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Evaluasi status warna SFC sesuai Kontrak:
 * - Rentang 0.2800 sampai 0.2842 -> Hijau
 * - Lebih dari 0.2842 -> Merah
 * - Kurang dari 0.2800 (dan > 0) -> Kuning
 */
function evaluateSfcContractStatus(sfcValue: number | string | undefined) {
  const val = Number(Number(sfcValue ?? 0).toFixed(4));
  if (val <= 0 || Number.isNaN(val)) {
    return {
      zone: 'neutral' as const,
      textClass: 'text-slate-300',
      borderClass: 'border-slate-700/80',
      barBgClass: 'bg-slate-500',
      dotClass: 'bg-slate-400',
      shortLabel: 'Belum Dihitung',
      label: 'Menunggu input harian',
    };
  }
  if (val >= SFC_CONTRACT_MIN && val <= SFC_CONTRACT_MAX) {
    return {
      zone: 'green' as const,
      textClass: 'text-emerald-400',
      borderClass: 'border-emerald-500/50',
      barBgClass: 'bg-emerald-400',
      dotClass: 'bg-emerald-400 shadow-[0_0_8px_#34d399]',
      shortLabel: 'HIJAU · Sesuai Kontrak',
      label: 'HIJAU · Sesuai Kontrak (0.2800 – 0.2842)',
    };
  }
  if (val > SFC_CONTRACT_MAX) {
    return {
      zone: 'red' as const,
      textClass: 'text-rose-400',
      borderClass: 'border-rose-500/60',
      barBgClass: 'bg-rose-400',
      dotClass: 'bg-rose-400 shadow-[0_0_8px_#fb7185]',
      shortLabel: 'MERAH · > 0.2842',
      label: 'MERAH · Melebihi Maksimal Kontrak (> 0.2842)',
    };
  }
  return {
    zone: 'yellow' as const,
    textClass: 'text-amber-400',
    borderClass: 'border-amber-500/50',
    barBgClass: 'bg-amber-400',
    dotClass: 'bg-amber-400 shadow-[0_0_8px_#fbbf24]',
    shortLabel: 'KUNING · < 0.2800',
    label: 'KUNING · Di Bawah Rentang Kontrak (< 0.2800)',
  };
}

/**
 * Hitung keterangan selisih level tangki BBM terhadap standar 14000 Liter per tangki.
 * Contoh:
 * - Tangki 1 = 14200 L (+200), Tangki 2 = 14100 L (+100) -> "BBM +300 L"
 * - Tangki 1 = 13500 L (-500), Tangki 2 = 13200 L (-800) -> "BBM -1300 L"
 * - Semua tangki = 14000 L -> "-"
 * Catatan ini tidak mempengaruhi perhitungan SFC (SFC murni dari selisih Flowmeter).
 */
function computeTankVarianceInfo(
  tankLevels: Record<string, number | string> | undefined,
  meterReplacements?: Record<string, boolean>
) {
  let totalVariance = 0;
  let hasNonStandard = false;

  if (tankLevels && typeof tankLevels === 'object') {
    for (const [, rawVal] of Object.entries(tankLevels)) {
      const num = Number(rawVal ?? 0);
      if (Number.isNaN(num)) continue;
      const diff = num - STANDARD_TANK_NUMBER;
      if (diff !== 0) {
        hasNonStandard = true;
      }
      totalVariance += diff;
    }
  }

  const parts: string[] = [];
  if (hasNonStandard) {
    if (totalVariance > 0) {
      parts.push(`BBM +${totalVariance} L`);
    } else if (totalVariance < 0) {
      parts.push(`BBM ${totalVariance} L`);
    } else {
      parts.push('BBM 0 L');
    }
  }

  if (meterReplacements && typeof meterReplacements === 'object') {
    const replacedUnits = Object.entries(meterReplacements)
      .filter(([, isReplaced]) => Boolean(isReplaced))
      .map(([unit]) => (unit === 'flowmeter' ? 'Flowmeter' : unit));
    if (replacedUnits.length > 0) {
      parts.push(`Ganti Meter: ${replacedUnits.join(', ')}`);
    }
  }

  return {
    totalVariance,
    hasNonStandard,
    remark: parts.length > 0 ? parts.join(' · ') : '-',
  };
}

function getTodayIsoDate(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getYesterdayIsoDate(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() - 1);
  return dt.toISOString().slice(0, 10);
}

function getNextIsoDate(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() + 1);
  return dt.toISOString().slice(0, 10);
}

function formatToDdMmYyyy(yyyyMmDd: string): string {
  const parts = yyyyMmDd.split('-');
  if (parts.length !== 3) return yyyyMmDd;
  return `${parts[2]}-${parts[1]}-${parts[0]}`;
}

export default function App() {
  // Auth state (hardcoded: ampenan / sewatama)
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return false;
      const parsed = JSON.parse(raw);
      return parsed?.username === 'ampenan';
    } catch {
      return false;
    }
  });
  const [usernameInput, setUsernameInput] = useState('ampenan');
  const [passwordInput, setPasswordInput] = useState('sewatama');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Navigation tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'reports' | 'settings' | 'source'>('dashboard');

  // Firebase real-time connection state
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  // Settings state ("Data Awal", dynamic blocks & tanks)
  const [settings, setSettings] = useState<AppSettingsState>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_SETTINGS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...DEFAULT_SETTINGS, ...parsed };
      }
    } catch {
      // ignore
    }
    return DEFAULT_SETTINGS;
  });

  // Daily logs state (synced from Firestore daily_logs via onSnapshot)
  const [dailyLogs, setDailyLogs] = useState<DailyLogRecord[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_LOGS_BACKUP_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Daily Input Form state
  const [selectedDate, setSelectedDate] = useState<string>(getTodayIsoDate());
  const [flowmeterToday, setFlowmeterToday] = useState<string>('');
  const [replaceFlowmeterFlag, setReplaceFlowmeterFlag] = useState<boolean>(false);
  const [flowmeterNewBase, setFlowmeterNewBase] = useState<string>('0');
  const [blockInputs, setBlockInputs] = useState<Record<string, string>>({
    'Blok 1': '',
    'Blok 2': '',
  });
  const [replaceBlockFlags, setReplaceBlockFlags] = useState<Record<string, boolean>>({});
  const [blockNewBases, setBlockNewBases] = useState<Record<string, string>>({});
  const [tankFullFlags, setTankFullFlags] = useState<Record<string, boolean>>({
    'Tangki 1': false,
    'Tangki 2': false,
  });
  const [tankInputs, setTankInputs] = useState<Record<string, string>>({
    'Tangki 1': '',
    'Tangki 2': '',
  });

  // Edit Modal state (Fitur #3: Edit Tanggal, Flowmeter, Metering kWh Blok, Level BBM Tangki, & Ganti Alat Meter)
  const [editingOriginalDateId, setEditingOriginalDateId] = useState<string | null>(null);
  const [editDate, setEditDate] = useState<string>('');
  const [editFlowmeter, setEditFlowmeter] = useState<string>('');
  const [editReplaceFlowmeterFlag, setEditReplaceFlowmeterFlag] = useState<boolean>(false);
  const [editFlowmeterNewBase, setEditFlowmeterNewBase] = useState<string>('0');
  const [editBlockInputs, setEditBlockInputs] = useState<Record<string, string>>({});
  const [editReplaceBlockFlags, setEditReplaceBlockFlags] = useState<Record<string, boolean>>({});
  const [editBlockNewBases, setEditBlockNewBases] = useState<Record<string, string>>({});
  const [editTankFullFlags, setEditTankFullFlags] = useState<Record<string, boolean>>({});
  const [editTankInputs, setEditTankInputs] = useState<Record<string, string>>({});
  const [isSavingEdit, setIsSavingEdit] = useState<boolean>(false);
  const [deletingDateId, setDeletingDateId] = useState<string | null>(null);

  // Reference metering resolved from Yesterday (Firestore) or Baseline (Settings)
  const [referenceInfo, setReferenceInfo] = useState<{
    source: 'YESTERDAY' | 'BASELINE';
    yesterdayId: string;
    flowmeterRef: string;
    blockRefs: Record<string, string>;
  }>({
    source: 'BASELINE',
    yesterdayId: getYesterdayIsoDate(getTodayIsoDate()),
    flowmeterRef: DEFAULT_SETTINGS.flowmeterBaseline,
    blockRefs: DEFAULT_SETTINGS.blockBaselines,
  });

  // Feedback message
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reports filter state
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');

  // Settings form state
  const [newBlockName, setNewBlockName] = useState('');
  const [newTankName, setNewTankName] = useState('');
  const [confirmResetDb, setConfirmResetDb] = useState(false);

  // Source Code viewer state
  const [selectedFileId, setSelectedFileId] = useState<string>(CAPACITOR_SOURCE_FILES[0].id);
  const [copiedFileId, setCopiedFileId] = useState<string | null>(null);

  const showNotice = useCallback((text: string, type: 'success' | 'error' = 'success') => {
    setFeedback({ text, type });
    setTimeout(() => {
      setFeedback((prev) => (prev?.text === text ? null : prev));
    }, 6000);
  }, []);

  // Test initial Firestore connection
  useEffect(() => {
    testConnection().then((ok) => {
      setIsOnline(ok && navigator.onLine);
    });

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Real-time Firestore onSnapshot listeners for daily_logs and settings
  useEffect(() => {
    if (!isLoggedIn) return;

    const logsPath = DAILY_LOGS_COLLECTION;
    const unsubscribeLogs = onSnapshot(
      collection(db, logsPath),
      { includeMetadataChanges: true },
      (snapshot) => {
        const offlineState = snapshot.metadata.fromCache && !navigator.onLine;
        setIsOnline(!offlineState);

        const records: DailyLogRecord[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as DailyLogRecord;
          const varianceInfo = computeTankVarianceInfo(data.tankLevels);
          records.push({
            ...data,
            dateId: docSnap.id,
            tankVariance: data.tankVariance ?? varianceInfo.totalVariance,
            tankRemark: data.tankRemark || varianceInfo.remark,
          });
        });

        records.sort((a, b) => (a.dateId < b.dateId ? 1 : -1));
        setDailyLogs(records);
        localStorage.setItem(LOCAL_LOGS_BACKUP_KEY, JSON.stringify(records));
      },
      (error) => {
        setIsOnline(false);
        try {
          handleFirestoreError(error, OperationType.LIST, logsPath);
        } catch (err) {
          console.warn('Menggunakan cache lokal daily_logs:', err);
        }
      }
    );

    const settingsDocPath = `${SETTINGS_COLLECTION}/${BASELINE_DOC_ID}`;
    const unsubscribeSettings = onSnapshot(
      doc(db, SETTINGS_COLLECTION, BASELINE_DOC_ID),
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          const nextSettings: AppSettingsState = {
            flowmeterBaseline: sanitizeDigits(data.flowmeterBaseline || '1250000') || '0',
            blocks:
              Array.isArray(data.blocks) && data.blocks.length > 0
                ? data.blocks
                : ['Blok 1', 'Blok 2'],
            tanks:
              Array.isArray(data.tanks) && data.tanks.length > 0
                ? data.tanks
                : ['Tangki 1', 'Tangki 2'],
            blockBaselines: data.blockBaselines || {
              'Blok 1': '4500000.00',
              'Blok 2': '4800000.00',
            },
          };
          setSettings(nextSettings);
          localStorage.setItem(LOCAL_SETTINGS_KEY, JSON.stringify(nextSettings));
        }
      },
      (error) => {
        try {
          handleFirestoreError(error, OperationType.GET, settingsDocPath);
        } catch (err) {
          console.warn('Menggunakan pengaturan Data Awal lokal:', err);
        }
      }
    );

    return () => {
      unsubscribeLogs();
      unsubscribeSettings();
    };
  }, [isLoggedIn]);

  // Ensure blockInputs and tankInputs keys stay in sync with settings.blocks & settings.tanks
  useEffect(() => {
    setBlockInputs((prev) => {
      const next: Record<string, string> = {};
      settings.blocks.forEach((b) => {
        next[b] = prev[b] ?? '';
      });
      return next;
    });

    setTankFullFlags((prev) => {
      const next: Record<string, boolean> = {};
      settings.tanks.forEach((t) => {
        next[t] = prev[t] ?? false;
      });
      return next;
    });

    setTankInputs((prev) => {
      const next: Record<string, string> = {};
      settings.tanks.forEach((t) => {
        next[t] = tankFullFlags[t] ? FULL_TANK_VALUE : prev[t] ?? '';
      });
      return next;
    });
  }, [settings.blocks, settings.tanks]);

  // Query Yesterday's document from Firestore or fallback to Settings "Data Awal"
  const fetchReferenceForDate = useCallback(
    async (dateStr: string, logsOverride?: DailyLogRecord[]) => {
      const yesterdayId = getYesterdayIsoDate(dateStr);
      const activeLogs = logsOverride ?? dailyLogs;

      const localMatch = activeLogs.find((d) => d.dateId === yesterdayId);
      if (localMatch) {
        const resolved = {
          source: 'YESTERDAY' as const,
          yesterdayId,
          flowmeterRef: sanitizeDigits(localMatch.flowmeterToday) || '0',
          blockRefs: localMatch.kwhBlocks || {},
        };
        if (!logsOverride) setReferenceInfo(resolved);
        return resolved;
      }

      try {
        const yesterdaySnap = await getDoc(doc(db, DAILY_LOGS_COLLECTION, yesterdayId));
        if (yesterdaySnap.exists()) {
          const data = yesterdaySnap.data() as DailyLogRecord;
          const resolved = {
            source: 'YESTERDAY' as const,
            yesterdayId,
            flowmeterRef: sanitizeDigits(data.flowmeterToday) || '0',
            blockRefs: data.kwhBlocks || {},
          };
          if (!logsOverride) setReferenceInfo(resolved);
          return resolved;
        }
      } catch (error) {
        console.warn('Fallback ke cache/Data Awal saat mengecek dokumen kemarin:', error);
      }

      const fallback = {
        source: 'BASELINE' as const,
        yesterdayId,
        flowmeterRef: sanitizeDigits(settings.flowmeterBaseline) || '0',
        blockRefs: { ...settings.blockBaselines },
      };
      if (!logsOverride) setReferenceInfo(fallback);
      return fallback;
    },
    [dailyLogs, settings]
  );

  useEffect(() => {
    if (isLoggedIn && selectedDate) {
      fetchReferenceForDate(selectedDate);
    }
  }, [isLoggedIn, selectedDate, fetchReferenceForDate]);

  // Handler Login Operator (hardcoded ampenan / sewatama)
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = usernameInput.trim().toLowerCase();
    const cleanPass = passwordInput.trim();

    if (cleanUser === 'ampenan' && cleanPass === 'sewatama') {
      const sessionPayload = {
        username: 'ampenan',
        siteName: 'PLTD Ampenan',
        loggedInAt: new Date().toISOString(),
      };
      localStorage.setItem(SESSION_KEY, JSON.stringify(sessionPayload));
      setIsLoggedIn(true);
      setLoginError(null);
    } else {
      setLoginError('Username atau password salah. Gunakan akun resmi PLTD (ampenan / sewatama).');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem(SESSION_KEY);
    setIsLoggedIn(false);
    setUsernameInput('ampenan');
    setPasswordInput('sewatama');
  };

  // Strict Numeric Input Guard (Prevents 'E', '-', '+', '.', and limits to 15 digits)
  const handleNumericKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (['e', 'E', '+', '-', '.', ','].includes(e.key)) {
      e.preventDefault();
    }
  };

  // Decimal Input Guard for kWh Metering (Allows up to 1 decimal separator '.' or ',', blocks 'E', '+', '-')
  const handleKwhDecimalKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (['e', 'E', '+', '-'].includes(e.key)) {
      e.preventDefault();
    }
    if ((e.key === '.' || e.key === ',') && e.currentTarget.value.includes('.')) {
      e.preventDefault();
    }
  };

  // Toggle Tank Full Checkbox (Ya = auto-fill 14000 & disabled; Tidak = manual input)
  const handleToggleTankFull = (tankName: string, checked: boolean) => {
    setTankFullFlags((prev) => ({ ...prev, [tankName]: checked }));
    setTankInputs((prev) => ({
      ...prev,
      [tankName]: checked ? FULL_TANK_VALUE : '',
    }));
  };

  // Fill Example Valid Inputs based on current Reference (demonstrates Green Contract SFC 0.2820 & BBM +300 L remark)
  const handleFillSampleTodayInput = () => {
    try {
      const flowRefBig = BigInt(sanitizeDigits(referenceInfo.flowmeterRef) || '1250000');
      // Add 2,820 Liters -> with 10,000.00 kWh gives SFC = 0.2820 (HIJAU - Sesuai Kontrak 0.2800-0.2842)
      const sampleFlowToday = (flowRefBig + 2820n).toString();
      setFlowmeterToday(sampleFlowToday);

      const nextBlocks: Record<string, string> = {};
      settings.blocks.forEach((bName, index) => {
        const bRefScaledBig = parseKwhToScaledBigInt(
          referenceInfo.blockRefs[bName] ?? settings.blockBaselines[bName] ?? '4500000.00'
        );
        // Add 5,000.25 kWh on Block 1 and 4,999.75 kWh on Block 2 (Total = 10,000.00 kWh)
        const incrementScaled = index === 0 ? 500025n : 499975n;
        const nextScaled = bRefScaledBig + incrementScaled;
        nextBlocks[bName] = (Number(nextScaled) / 100).toFixed(2);
      });
      setBlockInputs(nextBlocks);

      // Set Tangki 1 = 14200 L & Tangki 2 = 14100 L -> Keterangan: BBM +300 L
      const nextFlags: Record<string, boolean> = {};
      const nextTanks: Record<string, string> = {};
      settings.tanks.forEach((tName, index) => {
        nextFlags[tName] = false;
        nextTanks[tName] = index === 0 ? '14200' : '14100';
      });
      setTankFullFlags(nextFlags);
      setTankInputs(nextTanks);

      showNotice(
        'Angka simulasi diisi (+2.820 L BBM & +10.000,00 kWh -> SFC 0.2820 L/kWh [HIJAU Kontrak], Level Tangki 14.200 L & 14.100 L -> Ket: BBM +300 L).',
        'success'
      );
    } catch (err) {
      console.error(err);
    }
  };

  // Live BigInt Preview Calculation (with Scaled BigInt x100n for 2-decimal kWh & Tank Variance Preview)
  const livePreview = useMemo(() => {
    try {
      const currentTanksMap: Record<string, number> = {};
      settings.tanks.forEach((tName) => {
        const raw = tankFullFlags[tName] ? FULL_TANK_VALUE : sanitizeDigits(tankInputs[tName] || '');
        if (raw) {
          currentTanksMap[tName] = Number(raw);
        }
      });
      const activeMeterReplacements: Record<string, boolean> = {
        flowmeter: replaceFlowmeterFlag,
        ...replaceBlockFlags,
      };
      const tankVariancePreview = computeTankVarianceInfo(currentTanksMap, activeMeterReplacements);

      if (!flowmeterToday) {
        return {
          fuelConsumed: 0,
          totalKwhProduced: 0,
          sfc: 0,
          sfcFormatted: '0.0000',
          isValid: false,
          blockDeltas: {},
          tankVariancePreview,
        };
      }
      const flowTodayBig = BigInt(sanitizeDigits(flowmeterToday) || '0');
      const effectiveFlowRef = replaceFlowmeterFlag
        ? sanitizeDigits(flowmeterNewBase || '0') || '0'
        : sanitizeDigits(referenceInfo.flowmeterRef) || '0';
      const flowRefBig = BigInt(effectiveFlowRef);
      const fuelDeltaBig = flowTodayBig - flowRefBig;

      let totalKwhScaledBig = 0n;
      const blockDeltas: Record<string, bigint> = {};

      for (const bName of settings.blocks) {
        const valStr = sanitizeKwhDecimal(blockInputs[bName] || '');
        if (!valStr) {
          return {
            fuelConsumed: Number(fuelDeltaBig),
            totalKwhProduced: 0,
            sfc: 0,
            sfcFormatted: '0.0000',
            isValid: false,
            blockDeltas,
            tankVariancePreview,
          };
        }
        const bTodayScaledBig = parseKwhToScaledBigInt(valStr);
        const effectiveBlockRefStr = replaceBlockFlags[bName]
          ? sanitizeKwhDecimal(blockNewBases[bName] ?? '0.00') || '0.00'
          : referenceInfo.blockRefs[bName] ?? settings.blockBaselines[bName] ?? '0';
        const bRefScaledBig = parseKwhToScaledBigInt(effectiveBlockRefStr);
        const delta = bTodayScaledBig - bRefScaledBig;
        blockDeltas[bName] = delta;
        totalKwhScaledBig += delta;
      }

      const fuelConsumed = Number(fuelDeltaBig);
      const totalKwhProduced = Number((Number(totalKwhScaledBig) / 100).toFixed(2));
      const isValid =
        fuelDeltaBig >= 0n &&
        totalKwhScaledBig > 0n &&
        Object.values(blockDeltas).every((d) => d >= 0n);

      const sfc = isValid && totalKwhProduced > 0 ? fuelConsumed / totalKwhProduced : 0;

      return {
        fuelConsumed,
        totalKwhProduced,
        sfc,
        sfcFormatted: sfc.toFixed(4),
        isValid,
        blockDeltas,
        tankVariancePreview,
      };
    } catch {
      return null;
    }
  }, [
    flowmeterToday,
    replaceFlowmeterFlag,
    flowmeterNewBase,
    blockInputs,
    replaceBlockFlags,
    blockNewBases,
    tankFullFlags,
    tankInputs,
    referenceInfo,
    settings,
  ]);

  /**
   * Core builder for DailyLogRecord (supports Ganti Alat Meter per unit so calculation never goes negative,
   * and preserves locked historical reference snapshots when editing an existing record).
   */
  const buildDailyRecordObject = useCallback(
    async (
      targetDateId: string,
      rawFlowToday: string,
      rawBlockMap: Record<string, string>,
      rawTankMap: Record<string, number>,
      logsSnapshot: DailyLogRecord[],
      meterReplacementsInput: Record<string, boolean> = {},
      customReferencesInput: Record<string, string> = {},
      existingLockedRecord: DailyLogRecord | null = null
    ): Promise<DailyLogRecord> => {
      const cleanFlowToday = sanitizeDigits(rawFlowToday);
      if (!targetDateId || !cleanFlowToday) {
        throw new Error('Tanggal dan Flowmeter BBM Hari Ini wajib diisi dengan angka.');
      }

      const refData = await fetchReferenceForDate(targetDateId, logsSnapshot);

      // PERTAHANAN RIWAYAT: Jika sedang mengedit data lama dan tidak ada H-1, gunakan acuan yang sudah terkunci pada dokumen tersebut
      const lockedFlowRef =
        existingLockedRecord && existingLockedRecord.flowmeterReference
          ? String(existingLockedRecord.flowmeterReference)
          : null;
      const lockedBlockRefs =
        existingLockedRecord && existingLockedRecord.blockReferences
          ? existingLockedRecord.blockReferences
          : {};

      const isFlowReplaced = Boolean(meterReplacementsInput.flowmeter);
      const defaultFlowRef =
        refData.source === 'YESTERDAY'
          ? refData.flowmeterRef
          : lockedFlowRef !== null
          ? lockedFlowRef
          : refData.flowmeterRef;

      const cleanFlowRef = isFlowReplaced
        ? sanitizeDigits(customReferencesInput.flowmeter ?? '0') || '0'
        : sanitizeDigits(defaultFlowRef) || '0';

      // 1. Pengurangan Flowmeter BBM murni menggunakan BigInt
      const flowTodayBig = BigInt(cleanFlowToday);
      const flowRefBig = BigInt(cleanFlowRef);
      const fuelConsumedBig = flowTodayBig - flowRefBig;

      if (fuelConsumedBig < 0n) {
        throw new Error(
          `Validasi Gagal (${formatToDdMmYyyy(targetDateId)}): Flowmeter (${cleanFlowToday}) lebih kecil dari pengurang (${cleanFlowRef}). Jika alat meter baru diganti/reset, aktifkan centang "Ganti Alat Meter?".`
        );
      }

      // 2. Pengurangan kWh seluruh Blok menggunakan Scaled BigInt (x100n untuk 2 angka di belakang koma)
      const kwhBlocksPayload: Record<string, string> = {};
      const blockReferencesPayload: Record<string, string> = {};
      let totalKwhProducedScaledBig = 0n;
      let anyMeterReplaced = isFlowReplaced;

      for (const blockName of settings.blocks) {
        const rawBlockVal = sanitizeKwhDecimal(rawBlockMap[blockName] || '');
        if (!rawBlockVal) {
          throw new Error(`Metering kWh untuk ${blockName} wajib diisi.`);
        }

        const isBlockReplaced = Boolean(meterReplacementsInput[blockName]);
        if (isBlockReplaced) anyMeterReplaced = true;

        const fallbackBlockRef =
          refData.source === 'YESTERDAY'
            ? refData.blockRefs[blockName]
            : lockedBlockRefs[blockName] !== undefined
            ? lockedBlockRefs[blockName]
            : refData.blockRefs[blockName];

        const blockRefStr = isBlockReplaced
          ? sanitizeKwhDecimal(customReferencesInput[blockName] ?? '0.00') || '0.00'
          : sanitizeKwhDecimal(
              fallbackBlockRef ?? settings.blockBaselines[blockName] ?? '0'
            ) || '0';

        const kwhTodayScaledBig = parseKwhToScaledBigInt(rawBlockVal);
        const kwhRefScaledBig = parseKwhToScaledBigInt(blockRefStr);
        const blockDeltaScaledBig = kwhTodayScaledBig - kwhRefScaledBig;

        if (blockDeltaScaledBig < 0n) {
          throw new Error(
            `Validasi Gagal (${formatToDdMmYyyy(targetDateId)}): Metering ${blockName} (${rawBlockVal}) lebih kecil dari pengurang (${blockRefStr}). Jika alat meter ${blockName} baru diganti, aktifkan centang "Ganti Alat Meter?".`
          );
        }

        kwhBlocksPayload[blockName] = (Number(kwhTodayScaledBig) / 100).toFixed(2);
        blockReferencesPayload[blockName] = (Number(kwhRefScaledBig) / 100).toFixed(2);
        totalKwhProducedScaledBig += blockDeltaScaledBig;
      }

      const fuelConsumed = Number(fuelConsumedBig);
      const totalKwhProduced = Number((Number(totalKwhProducedScaledBig) / 100).toFixed(2));

      if (totalKwhProduced <= 0) {
        throw new Error(
          'Validasi Gagal: Total Produksi kWh seluruh blok harus lebih besar dari 0 untuk menghitung SFC.'
        );
      }

      // 3. SFC murni dari selisih Flowmeter / Total Produksi kWh
      const sfcValue = fuelConsumed / totalKwhProduced;
      const sfcFormatted = sfcValue.toFixed(4);

      // 4. Catatan Keterangan Selisih Level Tangki BBM terhadap 14000 L + Info Ganti Meter
      const varianceInfo = computeTankVarianceInfo(rawTankMap, meterReplacementsInput);

      return {
        dateId: targetDateId,
        displayDate: formatToDdMmYyyy(targetDateId),
        timestamp: Date.now(),
        flowmeterToday: cleanFlowToday,
        flowmeterReference: cleanFlowRef,
        referenceSource: anyMeterReplaced ? 'MANUAL_OVERRIDE' : refData.source,
        fuelConsumed,
        totalKwhProduced,
        sfc: Number(sfcFormatted),
        sfcFormatted,
        kwhBlocks: kwhBlocksPayload,
        blockReferences: blockReferencesPayload,
        meterReplacements: meterReplacementsInput,
        tankLevels: rawTankMap,
        tankVariance: varianceInfo.totalVariance,
        tankRemark: varianceInfo.remark,
        operator: 'ampenan',
      };
    },
    [fetchReferenceForDate, settings]
  );

  // Daily Calculation & Save to Firestore (daily_logs/{YYYY-MM-DD})
  // PERTAHANAN RIWAYAT: Tanggal yang sudah di-submit dikunci dan tidak bisa ditimpa dari Dashboard,
  // serta tidak akan pernah mengubah atau menghitung ulang hari sebelum-sebelumnya.
  const handleDailySubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const existingForDate = dailyLogs.find((item) => item.dateId === selectedDate);
    if (existingForDate) {
      showNotice(
        `Proteksi Riwayat Aktif: Data tanggal ${existingForDate.displayDate} sudah di-submit dan dikunci permanen. Gunakan tombol Edit jika ingin mengubahnya.`,
        'error'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      // Validasi Level Tangki BBM
      const tankLevelsPayload: Record<string, number> = {};
      for (const tankName of settings.tanks) {
        const rawTankVal = tankFullFlags[tankName]
          ? FULL_TANK_VALUE
          : sanitizeDigits(tankInputs[tankName] || '');
        if (!rawTankVal) {
          showNotice(`Level ${tankName} wajib diisi.`, 'error');
          setIsSubmitting(false);
          return;
        }
        tankLevelsPayload[tankName] = Number(rawTankVal);
      }

      const meterReplacementsPayload: Record<string, boolean> = {
        flowmeter: replaceFlowmeterFlag,
      };
      const customReferencesPayload: Record<string, string> = {
        flowmeter: sanitizeDigits(flowmeterNewBase || '0') || '0',
      };
      settings.blocks.forEach((bName) => {
        meterReplacementsPayload[bName] = Boolean(replaceBlockFlags[bName]);
        customReferencesPayload[bName] = sanitizeKwhDecimal(blockNewBases[bName] ?? '0.00') || '0.00';
      });

      const newRecord = await buildDailyRecordObject(
        selectedDate,
        flowmeterToday,
        blockInputs,
        tankLevelsPayload,
        dailyLogs,
        meterReplacementsPayload,
        customReferencesPayload
      );

      const targetPath = `${DAILY_LOGS_COLLECTION}/${selectedDate}`;
      try {
        await setDoc(doc(db, DAILY_LOGS_COLLECTION, selectedDate), newRecord);
      } catch (fireErr) {
        try {
          handleFirestoreError(fireErr, OperationType.WRITE, targetPath);
        } catch {
          // continue with local update
        }
      }

      const nextLogs = [
        newRecord,
        ...dailyLogs.filter((item) => item.dateId !== selectedDate),
      ].sort((a, b) => (a.dateId < b.dateId ? 1 : -1));

      setDailyLogs(nextLogs);
      localStorage.setItem(LOCAL_LOGS_BACKUP_KEY, JSON.stringify(nextLogs));

      const contractStatus = evaluateSfcContractStatus(newRecord.sfc);
      showNotice(
        `Log harian ${newRecord.displayDate} disimpan & dikunci. SFC: ${newRecord.sfcFormatted} L/kWh (${contractStatus.shortLabel}) · Hasil hari-hari sebelumnya tetap aman.`,
        'success'
      );
    } catch (err: any) {
      showNotice(err?.message || 'Gagal menyimpan log harian.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Open Edit Modal from Reports Table
  const handleOpenEditModal = (log: DailyLogRecord) => {
    setEditingOriginalDateId(log.dateId);
    setEditDate(log.dateId);
    setEditFlowmeter(sanitizeDigits(log.flowmeterToday));

    const isFlowReplaced = Boolean(log.meterReplacements?.flowmeter);
    setEditReplaceFlowmeterFlag(isFlowReplaced);
    setEditFlowmeterNewBase(isFlowReplaced ? sanitizeDigits(log.flowmeterReference || '0') || '0' : '0');

    const nextEditBlocks: Record<string, string> = {};
    const nextEditReplaceBlocks: Record<string, boolean> = {};
    const nextEditBlockBases: Record<string, string> = {};
    settings.blocks.forEach((bName) => {
      nextEditBlocks[bName] = sanitizeKwhDecimal(log.kwhBlocks?.[bName] ?? '0.00');
      const isBlkRep = Boolean(log.meterReplacements?.[bName]);
      nextEditReplaceBlocks[bName] = isBlkRep;
      nextEditBlockBases[bName] = isBlkRep
        ? sanitizeKwhDecimal(log.blockReferences?.[bName] ?? '0.00') || '0.00'
        : '0.00';
    });
    setEditBlockInputs(nextEditBlocks);
    setEditReplaceBlockFlags(nextEditReplaceBlocks);
    setEditBlockNewBases(nextEditBlockBases);

    const nextEditFlags: Record<string, boolean> = {};
    const nextEditTanks: Record<string, string> = {};
    settings.tanks.forEach((tName) => {
      const levelVal =
        log.tankLevels && log.tankLevels[tName] !== undefined
          ? Number(log.tankLevels[tName])
          : STANDARD_TANK_NUMBER;
      const isStandardFull = levelVal === STANDARD_TANK_NUMBER;
      nextEditFlags[tName] = isStandardFull;
      nextEditTanks[tName] = String(levelVal);
    });
    setEditTankFullFlags(nextEditFlags);
    setEditTankInputs(nextEditTanks);
  };

  const handleCloseEditModal = () => {
    setEditingOriginalDateId(null);
  };

  // Save Edited Log (supports changing Date, Flowmeter, kWh Blocks, and Tank Levels + Cascade Recalculation)
  const handleSaveEditedLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOriginalDateId) return;
    setIsSavingEdit(true);

    try {
      const tankLevelsPayload: Record<string, number> = {};
      for (const tankName of settings.tanks) {
        const rawTankVal = editTankFullFlags[tankName]
          ? FULL_TANK_VALUE
          : sanitizeDigits(editTankInputs[tankName] || '');
        if (!rawTankVal) {
          showNotice(`Level ${tankName} pada form edit wajib diisi.`, 'error');
          setIsSavingEdit(false);
          return;
        }
        tankLevelsPayload[tankName] = Number(rawTankVal);
      }

      let workingLogs = [...dailyLogs];

      const existingOriginalRecord =
        editingOriginalDateId === editDate
          ? dailyLogs.find((item) => item.dateId === editingOriginalDateId) || null
          : null;

      // Jika tanggal diubah (misal dari 2026-09-28 ke 2026-09-27), hapus dokumen lama terlebih dahulu
      if (editingOriginalDateId !== editDate) {
        try {
          await deleteDoc(doc(db, DAILY_LOGS_COLLECTION, editingOriginalDateId));
        } catch {
          // ignore offline delete error
        }
        workingLogs = workingLogs.filter((item) => item.dateId !== editingOriginalDateId);
      }

      const editReplacementsPayload: Record<string, boolean> = {
        flowmeter: editReplaceFlowmeterFlag,
      };
      const editCustomRefsPayload: Record<string, string> = {
        flowmeter: sanitizeDigits(editFlowmeterNewBase || '0') || '0',
      };
      settings.blocks.forEach((bName) => {
        editReplacementsPayload[bName] = Boolean(editReplaceBlockFlags[bName]);
        editCustomRefsPayload[bName] =
          sanitizeKwhDecimal(editBlockNewBases[bName] ?? '0.00') || '0.00';
      });

      const updatedRecord = await buildDailyRecordObject(
        editDate,
        editFlowmeter,
        editBlockInputs,
        tankLevelsPayload,
        workingLogs,
        editReplacementsPayload,
        editCustomRefsPayload,
        existingOriginalRecord
      );

      try {
        await setDoc(doc(db, DAILY_LOGS_COLLECTION, editDate), updatedRecord);
      } catch (fireErr) {
        try {
          handleFirestoreError(
            fireErr,
            OperationType.WRITE,
            `${DAILY_LOGS_COLLECTION}/${editDate}`
          );
        } catch {
          // fallback local
        }
      }

      workingLogs = [
        updatedRecord,
        ...workingLogs.filter((item) => item.dateId !== editDate),
      ].sort((a, b) => (a.dateId < b.dateId ? 1 : -1));

      setDailyLogs(workingLogs);
      localStorage.setItem(LOCAL_LOGS_BACKUP_KEY, JSON.stringify(workingLogs));

      setEditingOriginalDateId(null);
      const status = evaluateSfcContractStatus(updatedRecord.sfc);
      showNotice(
        `Data tanggal ${updatedRecord.displayDate} berhasil diperbarui secara manual. SFC: ${updatedRecord.sfcFormatted} L/kWh (${status.shortLabel}) · Data hari lainnya tetap terkunci.`,
        'success'
      );
    } catch (err: any) {
      showNotice(err?.message || 'Gagal menyimpan perubahan data.', 'error');
    } finally {
      setIsSavingEdit(false);
    }
  };

  // Delete single log row from Reports (does NOT alter or recalculate any other days)
  const handleDeleteLogRow = async (dateId: string) => {
    try {
      await deleteDoc(doc(db, DAILY_LOGS_COLLECTION, dateId));
    } catch {
      // ignore offline
    }
    const remaining = dailyLogs.filter((item) => item.dateId !== dateId);
    setDailyLogs(remaining);
    localStorage.setItem(LOCAL_LOGS_BACKUP_KEY, JSON.stringify(remaining));
    setDeletingDateId(null);
    showNotice(
      `Data tanggal ${formatToDdMmYyyy(dateId)} berhasil dihapus. Data hari lainnya tetap terkunci.`,
      'success'
    );
  };

  // Copy Formatted Daily Report for WhatsApp / Telegram
  const handleCopyWhatsAppReport = (targetLog?: DailyLogRecord | null) => {
    const logToCopy =
      targetLog || dailyLogs.find((d) => d.dateId === selectedDate) || dailyLogs[0] || null;
    if (!logToCopy) {
      showNotice('Belum ada data log harian untuk disalin.', 'error');
      return;
    }

    const status = evaluateSfcContractStatus(logToCopy.sfc);
    const variance = computeTankVarianceInfo(logToCopy.tankLevels, logToCopy.meterReplacements);
    const remark = logToCopy.tankRemark || variance.remark;

    const blocksLines = Object.entries(logToCopy.kwhBlocks || {})
      .map(([k, v]) => `• Metering ${k}: ${formatKwhDisplay(v)} kWh`)
      .join('\n');
    const tanksLines = Object.entries(logToCopy.tankLevels || {})
      .map(([k, v]) => `${k}: ${Number(v).toLocaleString('id-ID')} L`)
      .join(' | ');

    const waText = [
      `*LAPORAN HARIAN SFC - PLTD AMPENAN*`,
      `Tanggal: ${logToCopy.displayDate}`,
      `--------------------------------`,
      `• Flowmeter BBM: ${logToCopy.flowmeterToday} L (Acuan: ${logToCopy.flowmeterReference} L)`,
      `• Konsumsi BBM: ${Number(logToCopy.fuelConsumed).toLocaleString('id-ID')} L`,
      blocksLines,
      `• Total Produksi: ${formatKwhDisplay(logToCopy.totalKwhProduced)} kWh`,
      `• *SFC Harian: ${Number(logToCopy.sfc).toFixed(4)} L/kWh (${status.shortLabel})*`,
      `• Level Tangki: ${tanksLines}`,
      `• Keterangan BBM: ${remark}`,
    ].join('\n');

    navigator.clipboard.writeText(waText);
    showNotice(
      `Ringkasan laporan ${logToCopy.displayDate} berhasil disalin ke clipboard (siap tempel ke WhatsApp).`,
      'success'
    );
  };

  // Current selected date log & MTD (Month-To-Date) SFC calculation
  const selectedDayRecord = useMemo(
    () => dailyLogs.find((d) => d.dateId === selectedDate) || null,
    [dailyLogs, selectedDate]
  );

  const activeSfcValue = selectedDayRecord
    ? Number(selectedDayRecord.sfc)
    : livePreview?.isValid
    ? livePreview.sfc
    : 0;
  const activeSfcStatus = evaluateSfcContractStatus(activeSfcValue);

  const mtdStats = useMemo(() => {
    const monthPrefix = (selectedDate || getTodayIsoDate()).slice(0, 7); // YYYY-MM
    const monthLogs = dailyLogs.filter((d) => d.dateId.startsWith(monthPrefix));
    if (monthLogs.length === 0) {
      return {
        avgSfc: '0.0000',
        avgSfcNum: 0,
        daysCount: 0,
        totalFuel: 0,
        totalKwh: 0,
      };
    }
    const sumSfc = monthLogs.reduce((acc, item) => acc + Number(item.sfc || 0), 0);
    const totalFuel = monthLogs.reduce((acc, item) => acc + Number(item.fuelConsumed || 0), 0);
    const totalKwh = monthLogs.reduce((acc, item) => acc + Number(item.totalKwhProduced || 0), 0);
    const avgNum = sumSfc / monthLogs.length;
    return {
      avgSfc: avgNum.toFixed(4),
      avgSfcNum: avgNum,
      daysCount: monthLogs.length,
      totalFuel,
      totalKwh,
    };
  }, [dailyLogs, selectedDate]);

  const mtdSfcStatus = evaluateSfcContractStatus(mtdStats.avgSfcNum);

  // Trend chart data (chronological last 14 days)
  const trendLogs = useMemo(() => {
    return [...dailyLogs].sort((a, b) => (a.dateId > b.dateId ? 1 : -1)).slice(-14);
  }, [dailyLogs]);

  // Filtered reports logs
  const filteredReports = useMemo(() => {
    return dailyLogs.filter((log) => {
      if (filterStartDate && log.dateId < filterStartDate) return false;
      if (filterEndDate && log.dateId > filterEndDate) return false;
      return true;
    });
  }, [dailyLogs, filterStartDate, filterEndDate]);

  // Export CSV (includes Status Kontrak SFC & Keterangan BBM +/- 14000 L)
  const handleExportCsv = () => {
    if (filteredReports.length === 0) {
      showNotice('Tidak ada data laporan pada rentang tanggal ini untuk diekspor.', 'error');
      return;
    }

    const headers = [
      'Tanggal (DD-MM-YYYY)',
      'Flowmeter Hari Ini',
      'Flowmeter Pengurang',
      'Sumber Pengurang',
      'Konsumsi BBM (Liter)',
      'Total Produksi (kWh)',
      'SFC (Liter/kWh)',
      'Status Kontrak SFC',
      'Detail Metering Blok kWh',
      'Level Tangki BBM (Liter)',
      'Keterangan BBM',
    ];

    const lines = [
      headers.join(','),
      ...filteredReports.map((row) => {
        const blocksStr = Object.entries(row.kwhBlocks || {})
          .map(([k, v]) => `${k}: ${Number(v || 0).toFixed(2)}`)
          .join(' | ');
        const tanksStr = Object.entries(row.tankLevels || {})
          .map(([k, v]) => `${k}: ${v}L`)
          .join(' | ');
        const statusInfo = evaluateSfcContractStatus(row.sfc);
        const varianceInfo = computeTankVarianceInfo(row.tankLevels, row.meterReplacements);
        const remarkStr = row.tankRemark || varianceInfo.remark;

        return [
          `"${row.displayDate}"`,
          `"${row.flowmeterToday}"`,
          `"${row.flowmeterReference}"`,
          `"${row.referenceSource}"`,
          row.fuelConsumed,
          Number(row.totalKwhProduced || 0).toFixed(2),
          Number(row.sfc).toFixed(4),
          `"${statusInfo.shortLabel}"`,
          `"${blocksStr}"`,
          `"${tanksStr}"`,
          `"${remarkStr}"`,
        ].join(',');
      }),
    ];

    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Sewatama_SFC_Report_${getTodayIsoDate()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showNotice('File CSV berhasil diunduh beserta kolom Keterangan BBM & Status Kontrak.', 'success');
  };

  // Save Settings ("Data Awal") to Firestore & localStorage
  const persistSettings = async (nextSettings: AppSettingsState, message: string) => {
    setSettings(nextSettings);
    localStorage.setItem(LOCAL_SETTINGS_KEY, JSON.stringify(nextSettings));

    const path = `${SETTINGS_COLLECTION}/${BASELINE_DOC_ID}`;
    try {
      await setDoc(doc(db, SETTINGS_COLLECTION, BASELINE_DOC_ID), {
        flowmeterBaseline: sanitizeDigits(nextSettings.flowmeterBaseline) || '0',
        blockBaselines: nextSettings.blockBaselines,
        blocks: nextSettings.blocks,
        tanks: nextSettings.tanks,
        updatedAt: Date.now(),
        operator: 'ampenan',
      });
      showNotice(message, 'success');
    } catch (error) {
      try {
        handleFirestoreError(error, OperationType.WRITE, path);
      } catch {
        showNotice(`${message} (Tersimpan lokal)`, 'success');
      }
    }
  };

  const handleSaveBaselineForm = async (e: React.FormEvent) => {
    e.preventDefault();
    await persistSettings(settings, 'Data Awal (Baseline) berhasil diperbarui.');
  };

  const handleAddBlock = async () => {
    const label = newBlockName.trim() || `Blok ${settings.blocks.length + 1}`;
    if (settings.blocks.includes(label)) {
      showNotice(`Nama ${label} sudah terdaftar.`, 'error');
      return;
    }
    const next: AppSettingsState = {
      ...settings,
      blocks: [...settings.blocks, label],
      blockBaselines: { ...settings.blockBaselines, [label]: '0.00' },
    };
    setNewBlockName('');
    await persistSettings(next, `${label} berhasil ditambahkan.`);
  };

  const handleRemoveBlock = async (blockName: string) => {
    if (settings.blocks.length <= 1) {
      showNotice('Minimal harus terdapat 1 Blok kWh aktif.', 'error');
      return;
    }
    const nextBaselines = { ...settings.blockBaselines };
    delete nextBaselines[blockName];
    const next: AppSettingsState = {
      ...settings,
      blocks: settings.blocks.filter((b) => b !== blockName),
      blockBaselines: nextBaselines,
    };
    await persistSettings(next, `${blockName} berhasil dihapus.`);
  };

  const handleAddTank = async () => {
    const label = newTankName.trim() || `Tangki ${settings.tanks.length + 1}`;
    if (settings.tanks.includes(label)) {
      showNotice(`Nama ${label} sudah terdaftar.`, 'error');
      return;
    }
    const next: AppSettingsState = {
      ...settings,
      tanks: [...settings.tanks, label],
    };
    setNewTankName('');
    await persistSettings(next, `${label} berhasil ditambahkan.`);
  };

  const handleRemoveTank = async (tankName: string) => {
    if (settings.tanks.length <= 1) {
      showNotice('Minimal harus terdapat 1 Tangki BBM aktif.', 'error');
      return;
    }
    const next: AppSettingsState = {
      ...settings,
      tanks: settings.tanks.filter((t) => t !== tankName),
    };
    await persistSettings(next, `${tankName} berhasil dihapus.`);
  };

  const handleResetDatabase = async () => {
    try {
      const snap = await getDocs(collection(db, DAILY_LOGS_COLLECTION));
      const deletions: Promise<void>[] = [];
      snap.forEach((d) => {
        deletions.push(deleteDoc(doc(db, DAILY_LOGS_COLLECTION, d.id)));
      });
      await Promise.all(deletions);
      setDailyLogs([]);
      localStorage.removeItem(LOCAL_LOGS_BACKUP_KEY);
      setConfirmResetDb(false);
      showNotice('Seluruh riwayat database daily_logs berhasil direset.', 'success');
    } catch (error) {
      setDailyLogs([]);
      localStorage.removeItem(LOCAL_LOGS_BACKUP_KEY);
      setConfirmResetDb(false);
      try {
        handleFirestoreError(error, OperationType.DELETE, DAILY_LOGS_COLLECTION);
      } catch {
        showNotice('Data lokal berhasil direset.', 'success');
      }
    }
  };

  const handleCopySourceFile = (fileId: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFileId(fileId);
    setTimeout(() => setCopiedFileId(null), 2000);
  };

  const handleDownloadSourceFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const activeSourceFile = useMemo(
    () => CAPACITOR_SOURCE_FILES.find((f) => f.id === selectedFileId) || CAPACITOR_SOURCE_FILES[0],
    [selectedFileId]
  );

  // ============================================================================
  // VIEW 1: LOGIN SCREEN (ampenan / sewatama)
  // ============================================================================
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#0B132B] text-slate-100 flex flex-col justify-between p-4 sm:p-6">
        <div className="max-w-md w-full mx-auto my-auto pt-6 pb-12">
          <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-6 sm:p-8 shadow-2xl">
            <p className="text-xs font-semibold tracking-wider text-amber-400 mb-2">
              PT SUMBERDAYA SEWATAMA · PLTD AMPENAN
            </p>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mb-2">
              Sewatama SFC
            </h1>
            <p className="text-sm text-slate-400 mb-6">
              Sistem Monitoring &amp; Kalkulasi Specific Fuel Consumption Harian Berbasis Presisi BigInt.
            </p>

            {loginError && (
              <div className="mb-5 p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200">
                {loginError}
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4" autoComplete="off">
              <div>
                <label
                  htmlFor="username"
                  className="block text-xs font-semibold text-slate-300 mb-1.5"
                >
                  Username Operator
                </label>
                <input
                  id="username"
                  type="text"
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  placeholder="ampenan"
                  required
                  className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl bg-[#0B132B] border border-slate-600 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>

              <div>
                <label
                  htmlFor="password"
                  className="block text-xs font-semibold text-slate-300 mb-1.5"
                >
                  Password
                </label>
                <input
                  id="password"
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl bg-[#0B132B] border border-slate-600 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>

              <button
                type="submit"
                className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-slate-950 font-semibold text-sm transition-all cursor-pointer whitespace-nowrap"
              >
                Masuk Sistem Operasi PLTD
              </button>
            </form>

            <div className="mt-5 pt-4 border-t border-slate-700/70 flex items-center justify-between text-xs text-slate-400">
              <span>Akun Hardcoded: ampenan / sewatama</span>
              <span className="text-emerald-400 font-medium">Siap Login</span>
            </div>
          </div>
        </div>

        <footer className="text-center text-xs text-slate-500 py-3">
          Sewatama SFC · Capacitor Android APK (`com.sewatama.sfc`)
        </footer>
      </div>
    );
  }

  // ============================================================================
  // VIEW 2: AUTHENTICATED MAIN APPLICATION
  // ============================================================================
  return (
    <div className="min-h-screen bg-[#0B132B] text-slate-100 pb-24 md:pb-12">
      {/* Top Bar Contract: Zone 1 (Single Brand Wordmark) — Zone 2 (Nav Links) — Zone 3 (Connection & Logout) */}
      <header className="sticky top-0 z-30 h-14 bg-[#0B132B]/95 backdrop-blur-md border-b border-slate-800 px-4 sm:px-6 flex items-center justify-between">
        <a
          href="#dashboard"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('dashboard');
          }}
          className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          Sewatama SFC
        </a>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className={`py-1 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'text-amber-400 border-b-2 border-amber-400'
                : 'hover:text-white'
            }`}
          >
            Dashboard
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('reports')}
            className={`py-1 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'reports'
                ? 'text-amber-400 border-b-2 border-amber-400'
                : 'hover:text-white'
            }`}
          >
            Reports
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`py-1 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'settings'
                ? 'text-amber-400 border-b-2 border-amber-400'
                : 'hover:text-white'
            }`}
          >
            Settings
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('source')}
            className={`py-1 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'source'
                ? 'text-amber-400 border-b-2 border-amber-400'
                : 'hover:text-white'
            }`}
          >
            Kode Sumber &amp; APK
          </button>
        </nav>

        <div className="flex items-center gap-4 shrink-0">
          <span
            className={`inline-flex items-center gap-2 text-xs font-semibold whitespace-nowrap ${
              isOnline ? 'text-emerald-400' : 'text-amber-400'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isOnline ? 'bg-emerald-400 shadow-[0_0_8px_#10b981]' : 'bg-amber-400'
              }`}
            />
            {isOnline ? 'Online' : 'Offline'}
          </span>

          <button
            type="button"
            onClick={handleLogout}
            className="min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Keluar</span>
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 pt-5">
        {/* Global Feedback Notification */}
        {feedback && (
          <div
            className={`mb-5 p-4 rounded-xl border text-sm flex items-center justify-between ${
              feedback.type === 'error'
                ? 'bg-rose-500/15 border-rose-500/40 text-rose-200'
                : 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200'
            }`}
          >
            <span>{feedback.text}</span>
            <button
              type="button"
              onClick={() => setFeedback(null)}
              className="text-xs underline ml-4 whitespace-nowrap cursor-pointer"
            >
              Tutup
            </button>
          </div>
        )}

        {/* =================================================================== */}
        {/* TAB 1: DASHBOARD & FORM INPUT HARIAN */}
        {/* =================================================================== */}
        {activeTab === 'dashboard' && (
          <div className="space-y-5">
            {/* KPI Summary Row with Contract Color Indicators */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
              <div
                className={`bg-[#1E293B] border rounded-2xl p-4 sm:p-5 transition-colors ${activeSfcStatus.borderClass}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <p className="text-xs text-slate-400">SFC Hari Ini (L/kWh)</p>
                  <span className={`w-2.5 h-2.5 rounded-full ${activeSfcStatus.dotClass}`} />
                </div>
                <p
                  className={`text-2xl sm:text-3xl font-bold font-mono-num ${activeSfcStatus.textClass}`}
                >
                  {selectedDayRecord
                    ? Number(selectedDayRecord.sfc).toFixed(4)
                    : livePreview?.isValid
                    ? livePreview.sfcFormatted
                    : '0.0000'}
                </p>
                <p className={`text-xs mt-1.5 font-medium ${activeSfcStatus.textClass}`}>
                  {selectedDayRecord
                    ? `${activeSfcStatus.shortLabel} · ${selectedDayRecord.displayDate}`
                    : livePreview?.isValid
                    ? `Pratinjau: ${activeSfcStatus.shortLabel}`
                    : 'Menunggu input harian'}
                </p>
              </div>

              <div
                className={`bg-[#1E293B] border rounded-2xl p-4 sm:p-5 transition-colors ${mtdSfcStatus.borderClass}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <p className="text-xs text-slate-400">Rata-rata SFC MTD</p>
                  <span className={`w-2.5 h-2.5 rounded-full ${mtdSfcStatus.dotClass}`} />
                </div>
                <p
                  className={`text-2xl sm:text-3xl font-bold font-mono-num ${mtdSfcStatus.textClass}`}
                >
                  {mtdStats.avgSfc}
                </p>
                <p className="text-xs text-slate-400 mt-1.5">
                  {mtdStats.daysCount > 0
                    ? `${mtdStats.daysCount} hari · ${mtdSfcStatus.shortLabel}`
                    : '0 hari tercatat bulan ini'}
                </p>
              </div>

              <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-4 sm:p-5">
                <p className="text-xs text-slate-400 mb-1">Konsumsi BBM Harian</p>
                <p className="text-xl sm:text-2xl font-bold text-slate-100 font-mono-num">
                  {(selectedDayRecord
                    ? selectedDayRecord.fuelConsumed
                    : livePreview?.fuelConsumed ?? 0
                  ).toLocaleString('id-ID')}{' '}
                  L
                </p>
                <p className="text-xs text-slate-400 mt-1.5">Murni Selisih Flowmeter (BigInt)</p>
              </div>

              <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-4 sm:p-5">
                <p className="text-xs text-slate-400 mb-1">Total Produksi kWh</p>
                <p className="text-xl sm:text-2xl font-bold text-slate-100 font-mono-num">
                  {formatKwhDisplay(
                    selectedDayRecord
                      ? selectedDayRecord.totalKwhProduced
                      : livePreview?.totalKwhProduced ?? 0
                  )}{' '}
                  kWh
                </p>
                <p className="text-xs text-slate-400 mt-1.5">
                  Akumulasi {settings.blocks.length} Blok (2 Desimal)
                </p>
              </div>
            </div>

            {/* Indikator Batas Kontrak SFC Bar */}
            <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-4">
                <span className="font-semibold text-white">
                  Standar Kontrak SFC (Maksimal 0.2842 L/kWh):
                </span>
                <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  Hijau: 0.2800 – 0.2842
                </span>
                <span className="inline-flex items-center gap-1.5 text-amber-400 font-medium">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                  Kuning: &lt; 0.2800
                </span>
                <span className="inline-flex items-center gap-1.5 text-rose-400 font-medium">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                  Merah: &gt; 0.2842
                </span>
              </div>

              <button
                type="button"
                onClick={() => handleCopyWhatsAppReport(selectedDayRecord)}
                className="min-h-[34px] px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-amber-300 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Salin Laporan WA</span>
              </button>
            </div>

            {/* Fitur #5: Grafik Tren SFC Harian terhadap Batas Kontrak (0.2800 - 0.2842) */}
            <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-amber-400" />
                  <h2 className="text-sm sm:text-base font-bold text-white">
                    Grafik Tren SFC Harian vs Batas Kontrak (0.2842)
                  </h2>
                </div>
                <span className="text-xs text-slate-400 font-mono-num">
                  14 Pencatatan Terakhir · Klik batang untuk memilih tanggal
                </span>
              </div>

              {trendLogs.length === 0 ? (
                <div className="h-32 rounded-xl bg-[#0B132B] border border-slate-800 flex items-center justify-center text-xs text-slate-400">
                  Belum ada riwayat harian untuk menampilkan grafik tren SFC.
                </div>
              ) : (
                <div className="rounded-xl bg-[#0B132B] border border-slate-800 p-4 overflow-x-auto">
                  <div className="flex items-end gap-3 min-h-[130px] pt-4">
                    {trendLogs.map((item) => {
                      const maxRef = Math.max(
                        0.32,
                        ...trendLogs.map((d) => Number(d.sfc || 0))
                      );
                      const sfcNum = Number(item.sfc || 0);
                      const heightPct = Math.max(
                        14,
                        Math.min(100, Math.round((sfcNum / maxRef) * 95))
                      );
                      const st = evaluateSfcContractStatus(sfcNum);
                      const isSelected = item.dateId === selectedDate;

                      return (
                        <button
                          key={item.dateId}
                          type="button"
                          onClick={() => setSelectedDate(item.dateId)}
                          title={`${item.displayDate} · SFC: ${sfcNum.toFixed(4)} (${st.shortLabel})`}
                          className={`flex flex-col items-center justify-end min-w-[52px] h-28 group cursor-pointer rounded-lg p-1 transition-colors ${
                            isSelected ? 'bg-slate-800/90' : 'hover:bg-slate-800/40'
                          }`}
                        >
                          <span
                            className={`text-[10px] font-mono-num font-bold mb-1 ${st.textClass}`}
                          >
                            {sfcNum.toFixed(4)}
                          </span>
                          <div className="w-full flex items-end justify-center h-20">
                            <div
                              style={{ height: `${heightPct}%` }}
                              className={`w-6 rounded-t-md transition-all ${st.barBgClass}`}
                            />
                          </div>
                          <span className="text-[10px] font-mono-num text-slate-400 mt-1.5">
                            {item.displayDate.slice(0, 5)}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Main Daily Input Form Card */}
            <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-5 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-5 border-b border-slate-700/70">
                <div>
                  <h2 className="text-lg font-bold text-white">Form Input Metering Harian PLTD</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Rumus: SFC = Selisih Flowmeter BBM Harian (Liter) / Total Produksi kWh Seluruh Blok
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="text-xs text-slate-300 font-mono-num">
                    {referenceInfo.source === 'YESTERDAY'
                      ? `Pengurang: Data Kemarin (${referenceInfo.yesterdayId})`
                      : 'Pengurang: Data Awal (Settings)'}
                  </span>

                  <button
                    type="button"
                    onClick={handleFillSampleTodayInput}
                    className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs font-medium text-amber-300 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Isi Contoh Angka Uji</span>
                  </button>
                </div>
              </div>

              <form onSubmit={handleDailySubmit} className="space-y-5" autoComplete="off">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Tanggal Pencatatan */}
                  <div>
                    <label
                      htmlFor="input-date"
                      className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-1.5"
                    >
                      <span>Tanggal Pencatatan</span>
                      <span className="text-slate-400 font-normal font-mono-num">
                        ID: {selectedDate}
                      </span>
                    </label>
                    <input
                      id="input-date"
                      type="date"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      required
                      className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl bg-[#0B132B] border border-slate-600 text-sm text-white font-mono-num focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* Flowmeter BBM Hari Ini + Fitur Ganti Alat Meter */}
                  <div className="p-3.5 rounded-xl bg-[#0B132B] border border-slate-700/80">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div>
                        <label
                          htmlFor="input-flowmeter"
                          className="block text-xs font-semibold text-slate-200"
                        >
                          Flowmeter BBM Hari Ini (Liter)
                        </label>
                        <span className="text-[11px] text-amber-400/90 font-mono-num">
                          Pengurang Aktif:{' '}
                          {replaceFlowmeterFlag
                            ? `${flowmeterNewBase || '0'} (Meter Baru)`
                            : referenceInfo.flowmeterRef}
                        </span>
                      </div>

                      <label
                        htmlFor="check-replace-flowmeter"
                        className="inline-flex items-center gap-1.5 text-xs text-amber-400 font-medium cursor-pointer select-none min-h-[28px]"
                      >
                        <input
                          id="check-replace-flowmeter"
                          type="checkbox"
                          checked={replaceFlowmeterFlag}
                          onChange={(e) => setReplaceFlowmeterFlag(e.target.checked)}
                          className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                        />
                        <span>Ganti Alat Meter?</span>
                      </label>
                    </div>

                    {replaceFlowmeterFlag && (
                      <div className="mb-2.5 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/35">
                        <label
                          htmlFor="input-flowmeter-new-base"
                          className="flex items-center justify-between text-[11px] font-semibold text-amber-300 mb-1"
                        >
                          <span>Stand Awal Flowmeter Baru (Pengurang Pengganti)</span>
                          <span className="font-mono-num">Default: 0</span>
                        </label>
                        <input
                          id="input-flowmeter-new-base"
                          type="text"
                          inputMode="numeric"
                          maxLength={15}
                          value={flowmeterNewBase}
                          onKeyDown={handleNumericKeyDown}
                          onChange={(e) => setFlowmeterNewBase(sanitizeDigits(e.target.value))}
                          placeholder="Stand awal meter baru (contoh: 0)"
                          className="w-full min-h-[38px] px-3 py-1.5 rounded-lg bg-[#0B132B] border border-amber-500/50 text-xs text-amber-200 font-mono-num focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    )}

                    <input
                      id="input-flowmeter"
                      type="text"
                      inputMode="numeric"
                      maxLength={15}
                      value={flowmeterToday}
                      onKeyDown={handleNumericKeyDown}
                      onChange={(e) => setFlowmeterToday(sanitizeDigits(e.target.value))}
                      placeholder="Maks 15 digit angka (tanpa titik/koma)"
                      required
                      className="w-full min-h-[44px] px-3.5 py-2 rounded-lg bg-[#1E293B] border border-slate-600 text-sm text-white font-mono-num placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                {/* Metering kWh per Blok + Fitur Ganti Alat Meter per Blok */}
                <div className="pt-2">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <h3 className="text-sm font-semibold text-slate-200">
                      kWh Metering Hari Ini per Blok Pembangkit
                    </h3>
                    <span className="text-xs text-slate-400">
                      Centang &ldquo;Ganti Alat Meter?&rdquo; jika kWh meter blok diganti baru agar tidak minus
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {settings.blocks.map((blockName, idx) => {
                      const refVal =
                        referenceInfo.blockRefs[blockName] ??
                        settings.blockBaselines[blockName] ??
                        '0.00';
                      const currentVal = blockInputs[blockName] || '';
                      const isBlockReplaced = !!replaceBlockFlags[blockName];
                      const customBlockBase = blockNewBases[blockName] ?? '0.00';

                      return (
                        <div
                          key={blockName}
                          className="p-3.5 rounded-xl bg-[#0B132B] border border-slate-700/80"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                            <div>
                              <label
                                htmlFor={`block-input-${idx}`}
                                className="block text-xs font-semibold text-slate-200"
                              >
                                kWh Metering Hari Ini {blockName}
                              </label>
                              <span className="text-[11px] text-amber-400/90 font-mono-num">
                                Pengurang Aktif:{' '}
                                {isBlockReplaced
                                  ? `${formatKwhDisplay(customBlockBase)} (Meter Baru)`
                                  : formatKwhDisplay(refVal)}
                              </span>
                            </div>

                            <label
                              htmlFor={`check-replace-block-${idx}`}
                              className="inline-flex items-center gap-1.5 text-xs text-amber-400 font-medium cursor-pointer select-none min-h-[28px]"
                            >
                              <input
                                id={`check-replace-block-${idx}`}
                                type="checkbox"
                                checked={isBlockReplaced}
                                onChange={(e) => {
                                  const checked = e.target.checked;
                                  setReplaceBlockFlags((prev) => ({
                                    ...prev,
                                    [blockName]: checked,
                                  }));
                                  if (checked && blockNewBases[blockName] === undefined) {
                                    setBlockNewBases((prev) => ({
                                      ...prev,
                                      [blockName]: '0.00',
                                    }));
                                  }
                                }}
                                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                              />
                              <span>Ganti Alat Meter?</span>
                            </label>
                          </div>

                          {isBlockReplaced && (
                            <div className="mb-2.5 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/35">
                              <label
                                htmlFor={`block-new-base-${idx}`}
                                className="flex items-center justify-between text-[11px] font-semibold text-amber-300 mb-1"
                              >
                                <span>Stand Awal Meter Baru {blockName} (kWh)</span>
                                <span className="font-mono-num">Default: 0.00</span>
                              </label>
                              <input
                                id={`block-new-base-${idx}`}
                                type="text"
                                inputMode="decimal"
                                maxLength={18}
                                value={customBlockBase}
                                onKeyDown={handleKwhDecimalKeyDown}
                                onChange={(e) =>
                                  setBlockNewBases((prev) => ({
                                    ...prev,
                                    [blockName]: sanitizeKwhDecimal(e.target.value),
                                  }))
                                }
                                placeholder="Contoh: 0.00"
                                className="w-full min-h-[38px] px-3 py-1.5 rounded-lg bg-[#0B132B] border border-amber-500/50 text-xs text-amber-200 font-mono-num focus:outline-none focus:border-amber-400"
                              />
                            </div>
                          )}

                          <input
                            id={`block-input-${idx}`}
                            type="text"
                            inputMode="decimal"
                            maxLength={18}
                            value={currentVal}
                            onKeyDown={handleKwhDecimalKeyDown}
                            onChange={(e) =>
                              setBlockInputs((prev) => ({
                                ...prev,
                                [blockName]: sanitizeKwhDecimal(e.target.value),
                              }))
                            }
                            placeholder="Contoh: 4505120.25 (maks 2 desimal)"
                            required
                            className="w-full min-h-[44px] px-3.5 py-2 rounded-lg bg-[#1E293B] border border-slate-600 text-sm text-white font-mono-num placeholder-slate-500 focus:outline-none focus:border-amber-500"
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Checkbox Level Tangki BBM (Tangki 1 & 2 + Dinamis) */}
                <div className="pt-2">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <div>
                      <h3 className="text-sm font-semibold text-slate-200">
                        Level Tangki BBM Harian (Liter)
                      </h3>
                      <p className="text-xs text-slate-400">
                        Jika level bukan 14.000 L, selisih otomatis tercatat di kolom Keterangan pada Report (tidak mengubah hitungan SFC).
                      </p>
                    </div>
                    {livePreview?.tankVariancePreview?.hasNonStandard && (
                      <span className="text-xs font-mono-num font-semibold text-amber-300">
                        Catatan Report: {livePreview.tankVariancePreview.remark}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {settings.tanks.map((tankName, idx) => {
                      const isFull = !!tankFullFlags[tankName];
                      const val = isFull ? FULL_TANK_VALUE : tankInputs[tankName] || '';
                      const numericVal = Number(val || 0);
                      const singleDiff = val ? numericVal - STANDARD_TANK_NUMBER : 0;

                      return (
                        <div
                          key={tankName}
                          className="p-3.5 rounded-xl bg-[#0B132B] border border-slate-700/80"
                        >
                          <div className="flex items-center justify-between mb-2.5">
                            <span className="text-xs font-semibold text-slate-200">
                              Level {tankName}{' '}
                              {val && singleDiff !== 0 && (
                                <span
                                  className={`ml-1 font-mono-num ${
                                    singleDiff > 0 ? 'text-emerald-400' : 'text-amber-400'
                                  }`}
                                >
                                  ({singleDiff > 0 ? `+${singleDiff}` : singleDiff} L)
                                </span>
                              )}
                            </span>
                            <label
                              htmlFor={`tank-check-${idx}`}
                              className="inline-flex items-center gap-2 text-xs text-amber-400 font-medium cursor-pointer select-none min-h-[32px]"
                            >
                              <input
                                id={`tank-check-${idx}`}
                                type="checkbox"
                                checked={isFull}
                                onChange={(e) => handleToggleTankFull(tankName, e.target.checked)}
                                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                              />
                              <span>Penuh (Ya = 14000 L)</span>
                            </label>
                          </div>

                          <input
                            id={`tank-input-${idx}`}
                            type="text"
                            inputMode="numeric"
                            maxLength={15}
                            disabled={isFull}
                            value={val}
                            onKeyDown={handleNumericKeyDown}
                            onChange={(e) =>
                              setTankInputs((prev) => ({
                                ...prev,
                                [tankName]: sanitizeDigits(e.target.value),
                              }))
                            }
                            placeholder={`Input manual level ${tankName} (Liter)`}
                            required
                            className="w-full min-h-[44px] px-3.5 py-2 rounded-lg bg-[#1E293B] border border-slate-600 text-sm text-white font-mono-num placeholder-slate-500 disabled:bg-slate-900/80 disabled:text-amber-400 disabled:border-slate-700 disabled:cursor-not-allowed focus:outline-none focus:border-amber-500"
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Pertahanan Riwayat: Kunci Otomatis Jika Tanggal Sudah Di-Submit */}
                {selectedDayRecord && (
                  <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold text-emerald-300">
                        Proteksi Data Tersimpan Aktif (Tanggal {selectedDayRecord.displayDate} Terkunci)
                      </p>
                      <p className="text-xs text-slate-300 mt-0.5">
                        Data tanggal ini sudah di-submit (SFC: {Number(selectedDayRecord.sfc).toFixed(4)} L/kWh). Penggantian alat meter baru tidak akan pernah mengubah hasil tanggal ini maupun hari-hari sebelumnya. Jika ingin mengubah data tanggal ini, klik tombol Edit Manual.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleOpenEditModal(selectedDayRecord)}
                      className="min-h-[38px] px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-amber-500/40 text-xs font-semibold text-amber-300 flex items-center gap-1.5 shrink-0 cursor-pointer whitespace-nowrap"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      <span>Edit Manual Tanggal Ini</span>
                    </button>
                  </div>
                )}

                {/* Submit Button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting || Boolean(selectedDayRecord)}
                    className="w-full min-h-[48px] py-3 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed active:scale-[0.99] text-slate-950 font-semibold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap"
                  >
                    <Calculator className="w-4 h-4" />
                    <span>
                      {isSubmitting
                        ? 'Menyimpan ke Firestore...'
                        : selectedDayRecord
                        ? `Terkunci · Data ${selectedDayRecord.displayDate} Sudah Di-Submit (Hanya Bisa Diedit Manual)`
                        : 'Hitung & Simpan Log Harian (BigInt)'}
                    </span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* TAB 2: MENU REPORTS (Date Range Picker, Tabel Riwayat, Edit, CSV) */}
        {/* =================================================================== */}
        {activeTab === 'reports' && (
          <div className="space-y-6">
            <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-5 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-5 border-b border-slate-700/70">
                <div>
                  <h2 className="text-lg font-bold text-white">
                    Riwayat Harian, Keterangan Selisih BBM &amp; Edit Data
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Proteksi Riwayat Aktif: Setiap baris yang sudah di-submit terkunci permanen dan tidak akan berubah meskipun ada penggantian Flowmeter atau kWh Meter baru di hari berikutnya. Data hanya dapat diubah secara manual oleh user melalui tombol Edit.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleExportCsv}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap self-start sm:self-auto"
                >
                  <Download className="w-4 h-4" />
                  <span>Ekspor ke CSV</span>
                </button>
              </div>

              {/* Date Range Filter */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 mb-5">
                <div>
                  <label
                    htmlFor="filter-start"
                    className="block text-xs font-semibold text-slate-300 mb-1"
                  >
                    Dari Tanggal
                  </label>
                  <input
                    id="filter-start"
                    type="date"
                    value={filterStartDate}
                    onChange={(e) => setFilterStartDate(e.target.value)}
                    className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-[#0B132B] border border-slate-600 text-xs text-white font-mono-num focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label
                    htmlFor="filter-end"
                    className="block text-xs font-semibold text-slate-300 mb-1"
                  >
                    Sampai Tanggal
                  </label>
                  <input
                    id="filter-end"
                    type="date"
                    value={filterEndDate}
                    onChange={(e) => setFilterEndDate(e.target.value)}
                    className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-[#0B132B] border border-slate-600 text-xs text-white font-mono-num focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="button"
                    onClick={() => {
                      setFilterStartDate('');
                      setFilterEndDate('');
                    }}
                    className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-xs font-semibold text-slate-200 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Reset Rentang Tanggal
                  </button>
                </div>
              </div>

              {/* Reports Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-700/80">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#0B132B] text-slate-400 border-b border-slate-700/80">
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">Tanggal</th>
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">Flowmeter</th>
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">Metering kWh Blok</th>
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">Konsumsi BBM</th>
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">Produksi kWh</th>
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">SFC (L/kWh)</th>
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">Level Tangki</th>
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">Keterangan</th>
                      <th className="py-3 px-3.5 font-semibold whitespace-nowrap">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {filteredReports.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-8 text-center text-slate-400">
                          Belum ada riwayat perhitungan SFC pada rentang tanggal yang dipilih.
                        </td>
                      </tr>
                    ) : (
                      filteredReports.map((log) => {
                        const blocksSummary = Object.entries(log.kwhBlocks || {})
                          .map(([k, v]) => `${k}: ${formatKwhDisplay(v)}`)
                          .join(' · ');
                        const tankSummary = Object.entries(log.tankLevels || {})
                          .map(([k, v]) => `${k}: ${Number(v).toLocaleString('id-ID')} L`)
                          .join(' · ');

                        const sfcStatus = evaluateSfcContractStatus(log.sfc);
                        const varianceInfo = computeTankVarianceInfo(
                          log.tankLevels,
                          log.meterReplacements
                        );
                        const remarkText = log.tankRemark || varianceInfo.remark;
                        const remarkColorClass =
                          varianceInfo.totalVariance > 0
                            ? 'text-emerald-400 font-semibold'
                            : varianceInfo.totalVariance < 0
                            ? 'text-amber-400 font-semibold'
                            : remarkText !== '-'
                            ? 'text-sky-400 font-semibold'
                            : 'text-slate-400';

                        return (
                          <tr key={log.dateId} className="hover:bg-slate-800/60 transition-colors">
                            <td className="py-3 px-3.5 font-mono-num font-medium text-white whitespace-nowrap">
                              {log.displayDate}
                            </td>
                            <td className="py-3 px-3.5 font-mono-num text-slate-300 whitespace-nowrap">
                              {log.flowmeterToday}
                            </td>
                            <td className="py-3 px-3.5 font-mono-num text-slate-300 whitespace-nowrap">
                              {blocksSummary || '-'}
                            </td>
                            <td className="py-3 px-3.5 font-mono-num text-slate-200 whitespace-nowrap">
                              {Number(log.fuelConsumed).toLocaleString('id-ID')} L
                            </td>
                            <td className="py-3 px-3.5 font-mono-num text-slate-200 whitespace-nowrap">
                              {formatKwhDisplay(log.totalKwhProduced)} kWh
                            </td>
                            <td
                              className={`py-3 px-3.5 font-mono-num font-bold whitespace-nowrap ${sfcStatus.textClass}`}
                            >
                              <span className="inline-flex items-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${sfcStatus.dotClass}`} />
                                {Number(log.sfc).toFixed(4)}
                              </span>
                            </td>
                            <td className="py-3 px-3.5 font-mono-num text-slate-300 whitespace-nowrap">
                              {tankSummary || '-'}
                            </td>
                            <td
                              className={`py-3 px-3.5 font-mono-num whitespace-nowrap ${remarkColorClass}`}
                            >
                              {remarkText}
                            </td>
                            <td className="py-3 px-3.5 whitespace-nowrap">
                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleOpenEditModal(log)}
                                  className="min-h-[32px] px-2.5 py-1 rounded-lg bg-slate-700 hover:bg-slate-600 text-amber-300 font-semibold flex items-center gap-1 cursor-pointer"
                                  title="Edit Tanggal, Flowmeter, kWh Blok, atau Level BBM"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                  <span>Edit</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleCopyWhatsAppReport(log)}
                                  className="min-h-[32px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1 cursor-pointer"
                                  title="Salin Laporan WA"
                                >
                                  <Share2 className="w-3.5 h-3.5" />
                                  <span>WA</span>
                                </button>

                                {deletingDateId === log.dateId ? (
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteLogRow(log.dateId)}
                                    className="min-h-[32px] px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold cursor-pointer"
                                  >
                                    Ya, Hapus
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => setDeletingDateId(log.dateId)}
                                    className="min-h-[32px] px-2 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 flex items-center cursor-pointer"
                                    title="Hapus baris ini"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* TAB 3: MENU SETTINGS (Data Awal, Tambah/Hapus Blok & Tangki, Reset DB) */}
        {/* =================================================================== */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            {/* Data Awal (Baseline) Card */}
            <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-5 sm:p-6">
              <h2 className="text-lg font-bold text-white mb-1">
                Data Awal (Baseline Pengurang Pertama)
              </h2>
              <p className="text-xs text-slate-400 mb-5">
                Nilai Data Awal ini otomatis digunakan sebagai pengurang apabila data hari kemarin (H-1)
                tidak ditemukan di koleksi Firestore daily_logs.
              </p>

              <form onSubmit={handleSaveBaselineForm} className="space-y-4" autoComplete="off">
                <div>
                  <label
                    htmlFor="base-flowmeter"
                    className="block text-xs font-semibold text-slate-300 mb-1.5"
                  >
                    Data Awal Flowmeter BBM (Liter)
                  </label>
                  <input
                    id="base-flowmeter"
                    type="text"
                    inputMode="numeric"
                    maxLength={15}
                    value={settings.flowmeterBaseline}
                    onKeyDown={handleNumericKeyDown}
                    onChange={(e) =>
                      setSettings((prev) => ({
                        ...prev,
                        flowmeterBaseline: sanitizeDigits(e.target.value),
                      }))
                    }
                    required
                    className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl bg-[#0B132B] border border-slate-600 text-sm text-white font-mono-num focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {settings.blocks.map((blockName, idx) => (
                    <div key={blockName}>
                      <label
                        htmlFor={`base-block-${idx}`}
                        className="block text-xs font-semibold text-slate-300 mb-1.5"
                      >
                        Data Awal Metering kWh {blockName} (Maks 2 Desimal)
                      </label>
                      <input
                        id={`base-block-${idx}`}
                        type="text"
                        inputMode="decimal"
                        maxLength={18}
                        value={settings.blockBaselines[blockName] ?? '0.00'}
                        onKeyDown={handleKwhDecimalKeyDown}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            blockBaselines: {
                              ...prev.blockBaselines,
                              [blockName]: sanitizeKwhDecimal(e.target.value),
                            },
                          }))
                        }
                        placeholder="Contoh: 4500000.00"
                        required
                        className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl bg-[#0B132B] border border-slate-600 text-sm text-white font-mono-num focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  ))}
                </div>

                <button
                  type="submit"
                  className="min-h-[46px] px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs transition-colors cursor-pointer whitespace-nowrap"
                >
                  Simpan Konfigurasi Data Awal
                </button>
              </form>
            </div>

            {/* Manajemen Tambah/Hapus Blok & Tangki */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Kelola Blok kWh */}
              <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-5">
                <h3 className="text-base font-bold text-white mb-1">Kelola Blok Pembangkit kWh</h3>
                <p className="text-xs text-slate-400 mb-4">
                  Tambah atau hapus blok pembangkit yang dihitung pada total produksi kWh harian.
                </p>

                <div className="space-y-2 mb-4">
                  {settings.blocks.map((blockName) => (
                    <div
                      key={blockName}
                      className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-[#0B132B] border border-slate-700/80 text-xs"
                    >
                      <span className="font-semibold text-slate-200">{blockName}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveBlock(blockName)}
                        className="min-h-[32px] px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Hapus</span>
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newBlockName}
                    onChange={(e) => setNewBlockName(e.target.value)}
                    placeholder={`Contoh: Blok ${settings.blocks.length + 1}`}
                    className="flex-1 min-h-[42px] px-3 py-2 rounded-xl bg-[#0B132B] border border-slate-600 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddBlock}
                    className="min-h-[42px] px-3.5 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Tambah Blok</span>
                  </button>
                </div>
              </div>

              {/* Kelola Tangki BBM */}
              <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-5">
                <h3 className="text-base font-bold text-white mb-1">Kelola Tangki BBM</h3>
                <p className="text-xs text-slate-400 mb-4">
                  Tambah atau hapus unit tangki BBM harian (mendukung auto-isi 14000 L).
                </p>

                <div className="space-y-2 mb-4">
                  {settings.tanks.map((tankName) => (
                    <div
                      key={tankName}
                      className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-[#0B132B] border border-slate-700/80 text-xs"
                    >
                      <span className="font-semibold text-slate-200">{tankName}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveTank(tankName)}
                        className="min-h-[32px] px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Hapus</span>
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newTankName}
                    onChange={(e) => setNewTankName(e.target.value)}
                    placeholder={`Contoh: Tangki ${settings.tanks.length + 1}`}
                    className="flex-1 min-h-[42px] px-3 py-2 rounded-xl bg-[#0B132B] border border-slate-600 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddTank}
                    className="min-h-[42px] px-3.5 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Tambah Tangki</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Reset Database Card */}
            <div className="bg-[#1E293B] border border-rose-500/30 rounded-2xl p-5 sm:p-6">
              <h3 className="text-base font-bold text-white mb-1">Reset Database Firestore</h3>
              <p className="text-xs text-slate-400 mb-4">
                Tindakan ini akan menghapus seluruh dokumen riwayat pada koleksi daily_logs di
                Firebase Firestore.
              </p>

              {!confirmResetDb ? (
                <button
                  type="button"
                  onClick={() => setConfirmResetDb(true)}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-200 text-xs font-semibold flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset Database (Hapus Semua Log Harian)</span>
                </button>
              ) : (
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={handleResetDatabase}
                    className="min-h-[44px] px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    Ya, Hapus Permanen Seluruh Log
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmResetDb(false)}
                    className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    Batal
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* =================================================================== */}
        {/* TAB 4: SOURCE CODE & CAPACITOR ANDROID APK EXPORT */}
        {/* =================================================================== */}
        {activeTab === 'source' && (
          <div className="space-y-5">
            <div className="bg-[#1E293B] border border-slate-700/80 rounded-2xl p-5 sm:p-6">
              <div className="mb-4">
                <h2 className="text-lg font-bold text-white">
                  Kode Sumber Lengkap Capacitor Android &amp; GitHub Actions
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Seluruh file proyek (package.json, capacitor.config.json, .github/workflows/build.yml,
                  dan folder public/) siap digunakan untuk kompilasi APK Android.
                </p>
              </div>

              {/* File Selector Tabs */}
              <div className="flex flex-wrap gap-1.5 mb-4 p-1.5 bg-[#0B132B] rounded-xl border border-slate-800">
                {CAPACITOR_SOURCE_FILES.map((file) => (
                  <button
                    key={file.id}
                    type="button"
                    onClick={() => setSelectedFileId(file.id)}
                    className={`min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-mono-num font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      selectedFileId === file.id
                        ? 'bg-amber-500 text-slate-950 font-semibold'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {file.path}
                  </button>
                ))}
              </div>

              {/* Active File Header & Actions */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-[#0B132B] rounded-t-xl border border-slate-700/80 border-b-0">
                <div>
                  <p className="text-xs font-mono-num font-semibold text-amber-400">
                    {activeSourceFile.path}
                  </p>
                  <p className="text-xs text-slate-400 mt-0.5">{activeSourceFile.description}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      handleCopySourceFile(activeSourceFile.id, activeSourceFile.content)
                    }
                    className="min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    {copiedFileId === activeSourceFile.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Tersalin</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Salin Kode</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleDownloadSourceFile(activeSourceFile.filename, activeSourceFile.content)
                    }
                    className="min-h-[38px] px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-xs font-semibold text-slate-950 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh File</span>
                  </button>
                </div>
              </div>

              {/* Code Viewer */}
              <pre className="p-4 rounded-b-xl bg-[#070D1D] border border-slate-700/80 text-xs font-mono-num text-slate-200 overflow-x-auto max-h-[540px] leading-relaxed">
                <code>{activeSourceFile.content}</code>
              </pre>
            </div>
          </div>
        )}
      </main>

      {/* =================================================================== */}
      {/* MODAL EDIT DATA LOG HARIAN (Fitur #3: Tanggal, Flowmeter, kWh Blok, Tangki BBM) */}
      {/* =================================================================== */}
      {editingOriginalDateId && (
        <div className="fixed inset-0 z-50 bg-[#070D1D]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1E293B] border border-slate-600 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-5 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-700">
              <div>
                <h3 className="text-base sm:text-lg font-bold text-white">
                  Edit Data Log Harian ({formatToDdMmYyyy(editingOriginalDateId)})
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Perubahan pada tanggal, flowmeter, kWh blok, atau level tangki akan menghitung ulang SFC secara otomatis.
                </p>
              </div>
              <button
                type="button"
                onClick={handleCloseEditModal}
                className="min-h-[34px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 text-xs cursor-pointer"
              >
                <X className="w-4 h-4" />
                <span>Tutup</span>
              </button>
            </div>

            <form onSubmit={handleSaveEditedLog} className="space-y-4" autoComplete="off">
              {/* Edit Tanggal */}
              <div>
                <label
                  htmlFor="edit-date-field"
                  className="block text-xs font-semibold text-slate-300 mb-1.5"
                >
                  Tanggal Pencatatan
                </label>
                <input
                  id="edit-date-field"
                  type="date"
                  value={editDate}
                  onChange={(e) => setEditDate(e.target.value)}
                  required
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#0B132B] border border-slate-600 text-sm text-white font-mono-num focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Edit Flowmeter BBM + Ganti Alat Meter */}
              <div className="p-3.5 rounded-xl bg-[#0B132B] border border-slate-700/80">
                <div className="flex items-center justify-between mb-2">
                  <label
                    htmlFor="edit-flowmeter-field"
                    className="text-xs font-semibold text-slate-200"
                  >
                    Flowmeter BBM Hari Ini (Liter)
                  </label>
                  <label
                    htmlFor="edit-check-replace-flowmeter"
                    className="inline-flex items-center gap-1.5 text-xs text-amber-400 font-medium cursor-pointer"
                  >
                    <input
                      id="edit-check-replace-flowmeter"
                      type="checkbox"
                      checked={editReplaceFlowmeterFlag}
                      onChange={(e) => setEditReplaceFlowmeterFlag(e.target.checked)}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                    <span>Ganti Alat Meter?</span>
                  </label>
                </div>

                {editReplaceFlowmeterFlag && (
                  <div className="mb-2.5 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/35">
                    <label
                      htmlFor="edit-flowmeter-new-base-field"
                      className="block text-[11px] font-semibold text-amber-300 mb-1"
                    >
                      Stand Awal Flowmeter Baru (Pengurang)
                    </label>
                    <input
                      id="edit-flowmeter-new-base-field"
                      type="text"
                      inputMode="numeric"
                      maxLength={15}
                      value={editFlowmeterNewBase}
                      onKeyDown={handleNumericKeyDown}
                      onChange={(e) => setEditFlowmeterNewBase(sanitizeDigits(e.target.value))}
                      className="w-full min-h-[36px] px-3 py-1 rounded-lg bg-[#0B132B] border border-amber-500/50 text-xs text-amber-200 font-mono-num focus:outline-none"
                    />
                  </div>
                )}

                <input
                  id="edit-flowmeter-field"
                  type="text"
                  inputMode="numeric"
                  maxLength={15}
                  value={editFlowmeter}
                  onKeyDown={handleNumericKeyDown}
                  onChange={(e) => setEditFlowmeter(sanitizeDigits(e.target.value))}
                  required
                  className="w-full min-h-[42px] px-3.5 py-2 rounded-lg bg-[#1E293B] border border-slate-600 text-sm text-white font-mono-num focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Edit Metering kWh per Blok + Ganti Alat Meter per Blok */}
              <div className="space-y-3 pt-1">
                <p className="text-xs font-semibold text-slate-200">
                  Metering kWh per Blok (Maks 2 Desimal)
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {settings.blocks.map((blockName, idx) => {
                    const isBlkRep = !!editReplaceBlockFlags[blockName];
                    const blkBase = editBlockNewBases[blockName] ?? '0.00';

                    return (
                      <div
                        key={blockName}
                        className="p-3 rounded-xl bg-[#0B132B] border border-slate-700/80"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <label
                            htmlFor={`edit-block-field-${idx}`}
                            className="text-xs font-semibold text-slate-200"
                          >
                            {blockName}
                          </label>
                          <label
                            htmlFor={`edit-check-replace-block-${idx}`}
                            className="inline-flex items-center gap-1.5 text-[11px] text-amber-400 font-medium cursor-pointer"
                          >
                            <input
                              id={`edit-check-replace-block-${idx}`}
                              type="checkbox"
                              checked={isBlkRep}
                              onChange={(e) => {
                                const checked = e.target.checked;
                                setEditReplaceBlockFlags((prev) => ({
                                  ...prev,
                                  [blockName]: checked,
                                }));
                              }}
                              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                            />
                            <span>Ganti Meter?</span>
                          </label>
                        </div>

                        {isBlkRep && (
                          <div className="mb-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/35">
                            <label
                              htmlFor={`edit-block-base-${idx}`}
                              className="block text-[10px] font-semibold text-amber-300 mb-1"
                            >
                              Stand Awal Baru {blockName}
                            </label>
                            <input
                              id={`edit-block-base-${idx}`}
                              type="text"
                              inputMode="decimal"
                              maxLength={18}
                              value={blkBase}
                              onKeyDown={handleKwhDecimalKeyDown}
                              onChange={(e) =>
                                setEditBlockNewBases((prev) => ({
                                  ...prev,
                                  [blockName]: sanitizeKwhDecimal(e.target.value),
                                }))
                              }
                              className="w-full min-h-[34px] px-2.5 py-1 rounded bg-[#0B132B] border border-amber-500/50 text-xs text-amber-200 font-mono-num focus:outline-none"
                            />
                          </div>
                        )}

                        <input
                          id={`edit-block-field-${idx}`}
                          type="text"
                          inputMode="decimal"
                          maxLength={18}
                          value={editBlockInputs[blockName] || ''}
                          onKeyDown={handleKwhDecimalKeyDown}
                          onChange={(e) =>
                            setEditBlockInputs((prev) => ({
                              ...prev,
                              [blockName]: sanitizeKwhDecimal(e.target.value),
                            }))
                          }
                          required
                          className="w-full min-h-[40px] px-3 py-1.5 rounded-lg bg-[#1E293B] border border-slate-600 text-sm text-white font-mono-num focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Edit Level BBM per Tangki */}
              <div className="space-y-3 pt-1">
                <p className="text-xs font-semibold text-slate-200">
                  Level Tangki BBM (Liter)
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {settings.tanks.map((tankName, idx) => {
                    const isFull = !!editTankFullFlags[tankName];
                    const val = isFull ? FULL_TANK_VALUE : editTankInputs[tankName] || '';

                    return (
                      <div
                        key={tankName}
                        className="p-3 rounded-xl bg-[#0B132B] border border-slate-700/80"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-semibold text-slate-200">{tankName}</span>
                          <label
                            htmlFor={`edit-tank-check-${idx}`}
                            className="inline-flex items-center gap-1.5 text-[11px] text-amber-400 font-medium cursor-pointer"
                          >
                            <input
                              id={`edit-tank-check-${idx}`}
                              type="checkbox"
                              checked={isFull}
                              onChange={(e) => {
                                const checked = e.target.checked;
                                setEditTankFullFlags((prev) => ({ ...prev, [tankName]: checked }));
                                setEditTankInputs((prev) => ({
                                  ...prev,
                                  [tankName]: checked ? FULL_TANK_VALUE : prev[tankName] || '',
                                }));
                              }}
                              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                            />
                            <span>14000 L</span>
                          </label>
                        </div>

                        <input
                          type="text"
                          inputMode="numeric"
                          maxLength={15}
                          disabled={isFull}
                          value={val}
                          onKeyDown={handleNumericKeyDown}
                          onChange={(e) =>
                            setEditTankInputs((prev) => ({
                              ...prev,
                              [tankName]: sanitizeDigits(e.target.value),
                            }))
                          }
                          required
                          className="w-full min-h-[40px] px-3 py-1.5 rounded-lg bg-[#1E293B] border border-slate-600 text-sm text-white font-mono-num disabled:bg-slate-900/80 disabled:text-amber-400 disabled:border-slate-700 focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="submit"
                  disabled={isSavingEdit}
                  className="flex-1 min-h-[46px] py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs sm:text-sm cursor-pointer whitespace-nowrap"
                >
                  {isSavingEdit
                    ? 'Menyimpan & Menghitung Ulang...'
                    : 'Simpan Perubahan & Hitung Ulang SFC'}
                </button>
                <button
                  type="button"
                  onClick={handleCloseEditModal}
                  className="min-h-[46px] py-2.5 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold text-xs sm:text-sm cursor-pointer whitespace-nowrap"
                >
                  Batal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Fixed Bottom Navigation Bar for Mobile Ergonomics (<= 15% viewport height) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-[#0B132B]/95 backdrop-blur-md border-t border-slate-800 grid grid-cols-4 z-40">
        <button
          type="button"
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center gap-1 text-[11px] font-medium cursor-pointer ${
            activeTab === 'dashboard' ? 'text-amber-400' : 'text-slate-400'
          }`}
        >
          <Calculator className="w-5 h-5" />
          <span>Dashboard</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('reports')}
          className={`flex flex-col items-center justify-center gap-1 text-[11px] font-medium cursor-pointer ${
            activeTab === 'reports' ? 'text-amber-400' : 'text-slate-400'
          }`}
        >
          <FileSpreadsheet className="w-5 h-5" />
          <span>Reports</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center justify-center gap-1 text-[11px] font-medium cursor-pointer ${
            activeTab === 'settings' ? 'text-amber-400' : 'text-slate-400'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span>Settings</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('source')}
          className={`flex flex-col items-center justify-center gap-1 text-[11px] font-medium cursor-pointer ${
            activeTab === 'source' ? 'text-amber-400' : 'text-slate-400'
          }`}
        >
          <Code2 className="w-5 h-5" />
          <span>Kode APK</span>
        </button>
      </nav>
    </div>
  );
}
