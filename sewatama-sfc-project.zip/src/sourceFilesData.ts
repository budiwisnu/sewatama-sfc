import capacitorConfigRaw from '../capacitor.config.json?raw';
import githubWorkflowRaw from '../.github/workflows/build.yml?raw';
import publicIndexHtmlRaw from '../public/index.html?raw';
import publicStyleCssRaw from '../public/style.css?raw';
import publicFirebaseConfigRaw from '../public/firebaseConfig.js?raw';
import publicAuthJsRaw from '../public/auth.js?raw';
import publicAppJsRaw from '../public/app.js?raw';

export interface SourceFileEntry {
  id: string;
  filename: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

const capacitorPackageJson = `{
  "name": "sewatama-sfc",
  "version": "1.0.0",
  "description": "Aplikasi Android Monitoring Specific Fuel Consumption (SFC) Harian PLTD PT Sumberdaya Sewatama",
  "main": "public/index.html",
  "scripts": {
    "start": "npx serve public",
    "cap:add": "npx cap add android",
    "cap:sync": "npx cap sync android",
    "cap:open": "npx cap open android"
  },
  "dependencies": {
    "@capacitor/android": "^5.7.8",
    "@capacitor/cli": "^5.7.8",
    "@capacitor/core": "^5.7.8",
    "firebase": "^10.13.1"
  },
  "author": "PT Sumberdaya Sewatama",
  "license": "Proprietary"
}`;

export const CAPACITOR_SOURCE_FILES: SourceFileEntry[] = [
  {
    id: 'package-json',
    filename: 'package.json',
    path: 'package.json',
    language: 'json',
    description: 'Konfigurasi project Node.js, versi, dan dependencies Capacitor Android (kompatibel penuh JDK 17) + Firebase.',
    content: capacitorPackageJson,
  },
  {
    id: 'capacitor-config',
    filename: 'capacitor.config.json',
    path: 'capacitor.config.json',
    language: 'json',
    description: 'Konfigurasi Capacitor dengan App ID com.sewatama.sfc, appName Sewatama SFC, dan webDir public.',
    content: capacitorConfigRaw,
  },
  {
    id: 'github-workflow',
    filename: 'build.yml',
    path: '.github/workflows/build.yml',
    language: 'yaml',
    description: 'Workflow GitHub Actions CI/CD otomatis untuk build file APK Debug saat push ke branch main.',
    content: githubWorkflowRaw,
  },
  {
    id: 'public-index',
    filename: 'index.html',
    path: 'public/index.html',
    language: 'html',
    description: 'Antarmuka utama HTML5 Mobile-First (Halaman Login, Dashboard, Settings, dan Reports).',
    content: publicIndexHtmlRaw,
  },
  {
    id: 'public-style',
    filename: 'style.css',
    path: 'public/style.css',
    language: 'css',
    description: 'Stylesheet Industrial Modern Mobile-First dengan palet Navy Blue, Slate Gray, dan Amber.',
    content: publicStyleCssRaw,
  },
  {
    id: 'public-firebase-config',
    filename: 'firebaseConfig.js',
    path: 'public/firebaseConfig.js',
    language: 'javascript',
    description: 'Inisialisasi Firebase App dan Firestore (SDK v10 Modular) beserta kredensial database aktif Anda.',
    content: publicFirebaseConfigRaw,
  },
  {
    id: 'public-auth',
    filename: 'auth.js',
    path: 'public/auth.js',
    language: 'javascript',
    description: 'Fungsi loginOperator(username, password) mengecek ampenan & sewatama secara hardcoded dan menyimpan sesi di localStorage.',
    content: publicAuthJsRaw,
  },
  {
    id: 'public-app',
    filename: 'app.js',
    path: 'public/app.js',
    language: 'javascript',
    description: 'Logika utama kalkulasi harian SFC dengan BigInt & Scaled BigInt (2 desimal kWh), cek data kemarin vs Data Awal Settings, dan real-time onSnapshot Firestore.',
    content: publicAppJsRaw,
  },
];
