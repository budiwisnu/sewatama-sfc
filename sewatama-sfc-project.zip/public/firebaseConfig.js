// public/firebaseConfig.js
// Inisialisasi Firebase App dan Cloud Firestore menggunakan Firebase Modular SDK v10

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  enableIndexedDbPersistence
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

// Silakan isi dengan konfigurasi Firebase Project Anda (Spark Plan)
export const firebaseConfig = {
  apiKey: "AIzaSyCrzd66tZZtxpTO4i6JmlbciqEGeeN3q9o",
  authDomain: "unified-ion-382805.firebaseapp.com",
  projectId: "unified-ion-382805",
  storageBucket: "unified-ion-382805.firebasestorage.app",
  messagingSenderId: "25674890279",
  appId: "1:25674890279:web:8d0866bbc2c53dfea5a202",
  firestoreDatabaseId: "ai-studio-8846ef8d-2351-409b-98dc-8d81cde33cc3"
};

// Inisialisasi Firebase App & Firestore
const app = initializeApp(firebaseConfig);
const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Aktifkan offline persistence untuk mendukung sinkronisasi saat sinyal PLTD tidak stabil
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === "failed-precondition") {
    console.warn("Firestore persistence gagal: beberapa tab terbuka sekaligus.");
  } else if (err.code === "unimplemented") {
    console.warn("Browser/WebView tidak mendukung offline persistence.");
  }
});

export {
  app,
  db,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy
};
