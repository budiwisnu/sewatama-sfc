// public/app.js
// Logika Utama Kalkulasi SFC Harian (BigInt & Scaled BigInt 2 Desimal kWh),
// Fitur Ganti Alat Meter (Reset Stand Awal per Unit agar tidak minus),
// Keterangan Selisih Tangki BBM (14000 L), Indikator Warna Kontrak SFC (0.2800 - 0.2842),
// Fitur Edit Data Harian + Rekalkulasi Otomatis, Grafik Tren SFC, dan Sinkronisasi Real-time Firestore

import {
  db,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  onSnapshot
} from "./firebaseConfig.js";
import { loginOperator, getActiveSession, logoutOperator } from "./auth.js";

const DAILY_LOGS_COLLECTION = "daily_logs";
const SETTINGS_COLLECTION = "settings";
const BASELINE_DOC_ID = "baseline_config";
const LOCAL_SETTINGS_KEY = "sewatama_sfc_baseline_settings";
const FULL_TANK_LITERS = "14000";
const STANDARD_TANK_NUMBER = 14000;

// Batas Kontrak SFC
const SFC_CONTRACT_MIN = 0.2800;
const SFC_CONTRACT_MAX = 0.2842;

// State Aplikasi
let dailyLogsCache = [];
let unsubscribeLogs = null;
let appSettings = {
  flowmeterBaseline: "1250000",
  blocks: ["Blok 1", "Blok 2"],
  tanks: ["Tangki 1", "Tangki 2"],
  blockBaselines: {
    "Blok 1": "4500000.00",
    "Blok 2": "4800000.00"
  }
};

// Elemen DOM
const loginView = document.getElementById("login-view");
const mainApp = document.getElementById("main-app");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");
const btnLogout = document.getElementById("btn-logout");
const firebaseStatusEl = document.getElementById("firebase-status");
const firebaseStatusText = document.getElementById("firebase-status-text");
const appFeedback = document.getElementById("app-feedback");

const inputDate = document.getElementById("input-date");
const inputFlowmeter = document.getElementById("input-flowmeter");
const checkReplaceFlowmeter = document.getElementById("check-replace-flowmeter");
const replaceFlowmeterBox = document.getElementById("replace-flowmeter-box");
const inputFlowmeterNewBase = document.getElementById("input-flowmeter-new-base");
const dynamicBlocksContainer = document.getElementById("dynamic-blocks-container");
const dynamicTanksContainer = document.getElementById("dynamic-tanks-container");
const dailyInputForm = document.getElementById("daily-input-form");
const btnSubmitDaily = document.getElementById("btn-submit-daily");
const submittedLockBanner = document.getElementById("submitted-lock-banner");
const btnUnlockEditToday = document.getElementById("btn-unlock-edit-today");
const referenceBadge = document.getElementById("reference-badge");
const refFlowmeterHint = document.getElementById("ref-flowmeter-hint");

const cardSfcToday = document.getElementById("card-sfc-today");
const cardSfcMtd = document.getElementById("card-sfc-mtd");
const valSfcToday = document.getElementById("val-sfc-today");
const valSfcSource = document.getElementById("val-sfc-source");
const valSfcMtd = document.getElementById("val-sfc-mtd");
const valMtdCount = document.getElementById("val-mtd-count");
const valFuelToday = document.getElementById("val-fuel-today");
const valKwhToday = document.getElementById("val-kwh-today");
const trendChartContainer = document.getElementById("trend-chart-container");
const btnCopyWaDashboard = document.getElementById("btn-copy-wa-dashboard");

const filterStartDate = document.getElementById("filter-start-date");
const filterEndDate = document.getElementById("filter-end-date");
const btnResetFilter = document.getElementById("btn-reset-filter");
const btnExportCsv = document.getElementById("btn-export-csv");
const reportsTableBody = document.getElementById("reports-table-body");

const settingsBaselineForm = document.getElementById("settings-baseline-form");
const baselineFlowmeterInput = document.getElementById("baseline-flowmeter");
const settingsBlocksBaselineContainer = document.getElementById("settings-blocks-baseline-container");
const btnAddBlock = document.getElementById("btn-add-block");
const btnRemoveBlock = document.getElementById("btn-remove-block");
const btnAddTank = document.getElementById("btn-add-tank");
const btnRemoveTank = document.getElementById("btn-remove-tank");
const btnResetDb = document.getElementById("btn-reset-db");

// Elemen Modal Edit
const editModal = document.getElementById("edit-modal");
const editLogForm = document.getElementById("edit-log-form");
const editOriginalDate = document.getElementById("edit-original-date");
const editDateInput = document.getElementById("edit-date");
const editFlowmeterInput = document.getElementById("edit-flowmeter");
const editCheckReplaceFlowmeter = document.getElementById("edit-check-replace-flowmeter");
const editReplaceFlowmeterBox = document.getElementById("edit-replace-flowmeter-box");
const editFlowmeterNewBase = document.getElementById("edit-flowmeter-new-base");
const editBlocksContainer = document.getElementById("edit-blocks-container");
const editTanksContainer = document.getElementById("edit-tanks-container");
const btnCloseEditModal = document.getElementById("btn-close-edit-modal");
const btnCancelEdit = document.getElementById("btn-cancel-edit");

/**
 * Validasi input teks agar hanya menerima karakter angka 0-9 maksimal 15 digit
 */
function sanitizeNumericInput(value) {
  return String(value || "").replace(/[^0-9]/g, "").slice(0, 15);
}

/**
 * Validasi input Metering kWh: mendukung hingga 15 digit bulat + maksimal 2 angka di belakang koma/titik.
 */
function sanitizeKwhDecimalInput(value) {
  const normalized = String(value || "").replace(/,/g, ".");
  const cleaned = normalized.replace(/[^0-9.]/g, "");
  const parts = cleaned.split(".");
  const intPart = (parts[0] || "").slice(0, 15);
  if (parts.length > 1) {
    const decPart = parts.slice(1).join("").slice(0, 2);
    return `${intPart}.${decPart}`;
  }
  return intPart;
}

/**
 * Konversi string kWh (maks 2 desimal) menjadi Scaled BigInt (dikali 100n)
 */
function parseKwhToScaledBigInt(valueStr) {
  const clean = sanitizeKwhDecimalInput(valueStr);
  if (!clean) return 0n;
  const [intPartRaw = "0", decPartRaw = ""] = clean.split(".");
  const intDigits = intPartRaw.replace(/[^0-9]/g, "") || "0";
  const decDigits = decPartRaw.replace(/[^0-9]/g, "").slice(0, 2).padEnd(2, "0");
  return BigInt(intDigits + decDigits);
}

function formatKwhDisplay(val) {
  const num = Number(val || 0);
  if (Number.isNaN(num)) return "0,00";
  return num.toLocaleString("id-ID", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

/**
 * Evaluasi status warna SFC berdasarkan Kontrak (Maks 0.2842):
 * - Hijau: 0.2800 s/d 0.2842
 * - Merah: > 0.2842
 * - Kuning: < 0.2800 (dan > 0)
 */
function evaluateSfcContractStatus(sfcValue) {
  const val = Number(Number(sfcValue || 0).toFixed(4));
  if (val <= 0) {
    return {
      zone: "neutral",
      textClass: "",
      cardBorderClass: "",
      hexColor: "#94a3b8",
      label: "Belum ada data"
    };
  }
  if (val >= SFC_CONTRACT_MIN && val <= SFC_CONTRACT_MAX) {
    return {
      zone: "green",
      textClass: "sfc-green",
      cardBorderClass: "card-border-green",
      hexColor: "#34d399",
      label: "HIJAU · Sesuai Kontrak (0.2800–0.2842)"
    };
  }
  if (val > SFC_CONTRACT_MAX) {
    return {
      zone: "red",
      textClass: "sfc-red",
      cardBorderClass: "card-border-red",
      hexColor: "#fb7185",
      label: "MERAH · Melebihi Kontrak (> 0.2842)"
    };
  }
  return {
    zone: "yellow",
    textClass: "sfc-yellow",
    cardBorderClass: "card-border-yellow",
    hexColor: "#fbbf24",
    label: "KUNING · Di Bawah 0.2800 (< 0.2800)"
  };
}

/**
 * Hitung selisih level tangki BBM terhadap standar 14000 Liter per tangki
 * dan gabungkan dengan keterangan Ganti Alat Meter jika ada.
 */
function computeTankVarianceInfo(tankLevels, meterReplacements = {}) {
  let totalVariance = 0;
  let hasNonStandard = false;

  if (tankLevels && typeof tankLevels === "object") {
    for (const [, rawVal] of Object.entries(tankLevels)) {
      const level = Number(rawVal || 0);
      const diff = level - STANDARD_TANK_NUMBER;
      if (diff !== 0) {
        hasNonStandard = true;
      }
      totalVariance += diff;
    }
  }

  const parts = [];
  if (hasNonStandard) {
    if (totalVariance > 0) {
      parts.push(`BBM +${totalVariance} L`);
    } else if (totalVariance < 0) {
      parts.push(`BBM ${totalVariance} L`);
    } else {
      parts.push("BBM 0 L");
    }
  }

  if (meterReplacements && typeof meterReplacements === "object") {
    const replacedUnits = Object.entries(meterReplacements)
      .filter(([, isReplaced]) => Boolean(isReplaced))
      .map(([unit]) => (unit === "flowmeter" ? "Flowmeter" : unit));
    if (replacedUnits.length > 0) {
      parts.push(`Ganti Meter: ${replacedUnits.join(", ")}`);
    }
  }

  return {
    totalVariance,
    hasNonStandard,
    remark: parts.length > 0 ? parts.join(" · ") : "-"
  };
}

function attachNumericInputGuards(root = document) {
  const inputs = root.querySelectorAll(".numeric-only");
  inputs.forEach((input) => {
    input.addEventListener("input", (e) => {
      const cleaned = sanitizeNumericInput(e.target.value);
      if (e.target.value !== cleaned) {
        e.target.value = cleaned;
      }
    });

    input.addEventListener("keydown", (e) => {
      if (["e", "E", "+", "-", ".", ","].includes(e.key)) {
        e.preventDefault();
      }
    });
  });

  const decInputs = root.querySelectorAll(".decimal-kwh-only");
  decInputs.forEach((input) => {
    input.addEventListener("input", (e) => {
      const cleaned = sanitizeKwhDecimalInput(e.target.value);
      if (e.target.value !== cleaned) {
        e.target.value = cleaned;
      }
    });

    input.addEventListener("keydown", (e) => {
      if (["e", "E", "+", "-"].includes(e.key)) {
        e.preventDefault();
      }
      if ((e.key === "." || e.key === ",") && String(e.target.value).includes(".")) {
        e.preventDefault();
      }
    });
  });
}

function formatDisplayDate(yyyyMmDd) {
  const [year, month, day] = yyyyMmDd.split("-");
  return `${day}-${month}-${year}`;
}

function getYesterdayDateId(todayStr) {
  const [year, month, day] = todayStr.split("-").map(Number);
  const dateObj = new Date(Date.UTC(year, month - 1, day));
  dateObj.setUTCDate(dateObj.getUTCDate() - 1);
  return dateObj.toISOString().slice(0, 10);
}

function getNextDateId(todayStr) {
  const [year, month, day] = todayStr.split("-").map(Number);
  const dateObj = new Date(Date.UTC(year, month - 1, day));
  dateObj.setUTCDate(dateObj.getUTCDate() + 1);
  return dateObj.toISOString().slice(0, 10);
}

function getTodayDateString() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function showFeedback(message, type = "success") {
  appFeedback.textContent = message;
  appFeedback.className = `alert-box ${type === "error" ? "alert-error" : "alert-success"}`;
  appFeedback.classList.remove("hidden");
  setTimeout(() => {
    appFeedback.classList.add("hidden");
  }, 5500);
}

function updateConnectionIndicator(isOnline) {
  if (isOnline) {
    firebaseStatusEl.className = "conn-status conn-online";
    firebaseStatusText.textContent = "Online";
  } else {
    firebaseStatusEl.className = "conn-status conn-offline";
    firebaseStatusText.textContent = "Offline";
  }
}

/**
 * Render input dinamis untuk Blok kWh (beserta fitur Ganti Alat Meter per Blok)
 * dan Tangki BBM pada Dashboard & Settings
 */
function renderDynamicForms() {
  // 1. Render Blok kWh di Dashboard + Checkbox Ganti Alat Meter per Blok
  dynamicBlocksContainer.innerHTML = "";
  appSettings.blocks.forEach((blockName, idx) => {
    const safeId = `input-kwh-block-${idx}`;
    const hintId = `ref-kwh-hint-${idx}`;
    const checkReplaceId = `check-replace-block-${idx}`;
    const replaceBoxId = `replace-block-box-${idx}`;
    const newBaseInputId = `input-block-new-base-${idx}`;

    const wrapper = document.createElement("div");
    wrapper.className = "tank-row";
    wrapper.innerHTML = `
      <div class="tank-header">
        <div>
          <span style="font-size: 13px; font-weight: 600; color: #f1f5f9;">kWh Metering Hari Ini ${blockName}</span>
          <div id="${hintId}" class="form-hint mono-num">Acuan Kemarin: -</div>
        </div>
        <label class="checkbox-label" for="${checkReplaceId}">
          <input type="checkbox" id="${checkReplaceId}" class="block-replace-check" data-block-name="${blockName}" />
          <span>Ganti Alat Meter?</span>
        </label>
      </div>
      <div id="${replaceBoxId}" class="hidden" style="margin-bottom: 10px; padding: 10px; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.35); border-radius: 8px;">
        <label class="form-label" for="${newBaseInputId}" style="font-size: 12px; color: #fbbf24;">
          <span>Stand Awal Meter Baru ${blockName} (Pengurang Pengganti)</span>
          <span class="form-hint" style="color: #fde68a;">Default: 0.00</span>
        </label>
        <input
          type="text"
          id="${newBaseInputId}"
          data-block-name="${blockName}"
          class="form-input mono-num decimal-kwh-only block-new-base-input"
          inputmode="decimal"
          maxlength="18"
          value="0.00"
          placeholder="Stand awal meter baru (contoh: 0.00)"
        />
      </div>
      <input
        type="text"
        id="${safeId}"
        data-block-name="${blockName}"
        class="form-input mono-num decimal-kwh-only kwh-block-input"
        inputmode="decimal"
        maxlength="18"
        placeholder="Contoh: 4505120.25"
        required
      />
    `;
    dynamicBlocksContainer.appendChild(wrapper);

    const checkEl = wrapper.querySelector(`#${checkReplaceId}`);
    const boxEl = wrapper.querySelector(`#${replaceBoxId}`);
    checkEl.addEventListener("change", () => {
      if (checkEl.checked) {
        boxEl.classList.remove("hidden");
      } else {
        boxEl.classList.add("hidden");
      }
    });
  });

  // 2. Render Tangki BBM di Dashboard (Checkbox Ya = auto-isi 14000 & disabled)
  dynamicTanksContainer.innerHTML = "";
  appSettings.tanks.forEach((tankName, idx) => {
    const checkId = `tank-full-check-${idx}`;
    const inputId = `tank-level-input-${idx}`;
    const row = document.createElement("div");
    row.className = "tank-row";
    row.innerHTML = `
      <div class="tank-header">
        <span style="font-size: 13px; font-weight: 600;">${tankName}</span>
        <label class="checkbox-label" for="${checkId}">
          <input type="checkbox" id="${checkId}" data-target-input="${inputId}" />
          <span>Penuh (Ya = 14.000 L)</span>
        </label>
      </div>
      <input
        type="text"
        id="${inputId}"
        data-tank-name="${tankName}"
        class="form-input mono-num numeric-only tank-level-input"
        inputmode="numeric"
        maxlength="15"
        placeholder="Masukkan level ${tankName} (Liter)"
        required
      />
    `;
    dynamicTanksContainer.appendChild(row);

    const checkbox = row.querySelector(`#${checkId}`);
    const levelInput = row.querySelector(`#${inputId}`);
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) {
        levelInput.value = FULL_TANK_LITERS;
        levelInput.disabled = true;
      } else {
        levelInput.disabled = false;
        levelInput.value = "";
        levelInput.focus();
      }
    });
  });

  // 3. Render Data Awal (Baseline) di Menu Settings
  baselineFlowmeterInput.value = appSettings.flowmeterBaseline || "1250000";
  settingsBlocksBaselineContainer.innerHTML = "";
  appSettings.blocks.forEach((blockName, idx) => {
    const baseVal = appSettings.blockBaselines[blockName] || "4500000.00";
    const wrapper = document.createElement("div");
    wrapper.className = "form-group";
    wrapper.innerHTML = `
      <label class="form-label" for="baseline-block-${idx}">Data Awal kWh ${blockName} (Maks 2 Desimal)</label>
      <input
        type="text"
        id="baseline-block-${idx}"
        data-block-name="${blockName}"
        class="form-input mono-num decimal-kwh-only baseline-block-input"
        inputmode="decimal"
        maxlength="18"
        value="${baseVal}"
        required
      />
    `;
    settingsBlocksBaselineContainer.appendChild(wrapper);
  });

  attachNumericInputGuards(document);
  inspectYesterdayReference(inputDate.value);
}

/**
 * Mengambil data pengurang (Hari Kemarin dari Firestore atau Data Awal dari Settings)
 */
async function resolveReferenceMetering(selectedDateStr) {
  const yesterdayId = getYesterdayDateId(selectedDateStr);

  const cachedYesterday = dailyLogsCache.find((item) => item.dateId === yesterdayId);
  if (cachedYesterday) {
    return {
      source: "YESTERDAY",
      yesterdayId,
      flowmeterRef: String(cachedYesterday.flowmeterToday || "0"),
      blockRefs: cachedYesterday.kwhBlocks || {}
    };
  }

  try {
    const yesterdayDocRef = doc(db, DAILY_LOGS_COLLECTION, yesterdayId);
    const yesterdaySnap = await getDoc(yesterdayDocRef);

    if (yesterdaySnap.exists()) {
      const data = yesterdaySnap.data();
      return {
        source: "YESTERDAY",
        yesterdayId,
        flowmeterRef: String(data.flowmeterToday || "0"),
        blockRefs: data.kwhBlocks || {}
      };
    }
  } catch (err) {
    console.warn("Fallback ke Data Awal:", err);
  }

  return {
    source: "BASELINE",
    yesterdayId,
    flowmeterRef: String(appSettings.flowmeterBaseline || "0"),
    blockRefs: { ...appSettings.blockBaselines }
  };
}

async function inspectYesterdayReference(selectedDateStr) {
  if (!selectedDateStr) return;
  const ref = await resolveReferenceMetering(selectedDateStr);

  if (ref.source === "YESTERDAY") {
    referenceBadge.textContent = `Pengurang: Data Kemarin (${ref.yesterdayId})`;
  } else {
    referenceBadge.textContent = "Pengurang: Data Awal (Settings)";
  }

  refFlowmeterHint.textContent = `Acuan Kemarin: ${ref.flowmeterRef}`;
  appSettings.blocks.forEach((blockName, idx) => {
    const hintEl = document.getElementById(`ref-kwh-hint-${idx}`);
    if (hintEl) {
      const blockRefVal = ref.blockRefs[blockName] ?? appSettings.blockBaselines[blockName] ?? "0";
      hintEl.textContent = `Acuan Kemarin: ${blockRefVal}`;
    }
  });
}

/**
 * Fungsi inti pembuat objek log harian (mendukung Fitur Ganti Alat Meter per unit agar tidak minus
 * serta Pertahanan Snapshot Historis agar pengurang data lama tidak berubah).
 */
async function buildDailyLogRecord(
  dateId,
  flowTodayStr,
  kwhBlocksInputMap,
  tankLevelsMap,
  meterReplacements = {},
  customReferences = {},
  existingLockedRecord = null
) {
  const reference = await resolveReferenceMetering(dateId);

  // PERTAHANAN RIWAYAT: Jika sedang mengedit data lama dan tidak ada H-1, gunakan acuan yang sudah terkunci pada dokumen tersebut
  const lockedFlowRef =
    existingLockedRecord && existingLockedRecord.flowmeterReference
      ? String(existingLockedRecord.flowmeterReference)
      : null;
  const lockedBlockRefs =
    existingLockedRecord && existingLockedRecord.blockReferences
      ? existingLockedRecord.blockReferences
      : {};

  const isFlowmeterReplaced = Boolean(meterReplacements.flowmeter);
  const defaultFlowRef =
    reference.source === "YESTERDAY"
      ? reference.flowmeterRef
      : lockedFlowRef !== null
      ? lockedFlowRef
      : reference.flowmeterRef;

  const flowRefStr = isFlowmeterReplaced
    ? sanitizeNumericInput(customReferences.flowmeter ?? "0") || "0"
    : sanitizeNumericInput(defaultFlowRef || "0") || "0";

  // 1. Pengurangan Flowmeter BBM murni menggunakan BigInt
  const flowTodayBig = BigInt(flowTodayStr);
  const flowRefBig = BigInt(flowRefStr);
  const fuelConsumedBig = flowTodayBig - flowRefBig;

  if (fuelConsumedBig < 0n) {
    throw new Error(
      `Validasi Gagal (${dateId}): Flowmeter (${flowTodayStr}) lebih kecil dari pengurang (${flowRefStr}). Jika alat meter baru diganti/reset, aktifkan centang 'Ganti Alat Meter?'.`
    );
  }

  // 2. Pengurangan kWh seluruh Blok menggunakan Scaled BigInt (x100n untuk 2 desimal)
  const kwhBlocksFormatted = {};
  const blockReferencesMap = {};
  let totalKwhProducedScaledBig = 0n;
  let anyMeterReplaced = isFlowmeterReplaced;

  for (const blockName of appSettings.blocks) {
    const rawBlockStr = sanitizeKwhDecimalInput(kwhBlocksInputMap[blockName] || "");
    if (!rawBlockStr) {
      throw new Error(`Nilai Metering kWh untuk ${blockName} wajib diisi.`);
    }

    const isBlockReplaced = Boolean(meterReplacements[blockName]);
    if (isBlockReplaced) anyMeterReplaced = true;

    const fallbackBlockRef =
      reference.source === "YESTERDAY"
        ? reference.blockRefs[blockName]
        : lockedBlockRefs[blockName] !== undefined
        ? lockedBlockRefs[blockName]
        : reference.blockRefs[blockName];

    const kwhRefStr = isBlockReplaced
      ? sanitizeKwhDecimalInput(customReferences[blockName] ?? "0.00") || "0.00"
      : sanitizeKwhDecimalInput(
          fallbackBlockRef ?? appSettings.blockBaselines[blockName] ?? "0"
        ) || "0";

    const kwhTodayScaledBig = parseKwhToScaledBigInt(rawBlockStr);
    const kwhRefScaledBig = parseKwhToScaledBigInt(kwhRefStr);
    const blockDeltaScaledBig = kwhTodayScaledBig - kwhRefScaledBig;

    if (blockDeltaScaledBig < 0n) {
      throw new Error(
        `Validasi Gagal (${dateId}): Metering ${blockName} (${rawBlockStr}) lebih kecil dari pengurang (${kwhRefStr}). Jika alat meter ${blockName} baru diganti, aktifkan centang 'Ganti Alat Meter?'.`
      );
    }

    kwhBlocksFormatted[blockName] = (Number(kwhTodayScaledBig) / 100).toFixed(2);
    blockReferencesMap[blockName] = (Number(kwhRefScaledBig) / 100).toFixed(2);
    totalKwhProducedScaledBig += blockDeltaScaledBig;
  }

  const fuelConsumed = Number(fuelConsumedBig);
  const totalKwhProduced = Number((Number(totalKwhProducedScaledBig) / 100).toFixed(2));

  if (totalKwhProduced <= 0) {
    throw new Error("Total produksi kWh seluruh blok harus lebih besar dari 0 untuk menghitung SFC.");
  }

  // 3. SFC murni dihitung dari selisih Flowmeter dibagi Total Produksi kWh
  const sfc = fuelConsumed / totalKwhProduced;
  const sfcFormatted = sfc.toFixed(4);

  // 4. Catatan selisih level tangki BBM terhadap 14000 L + info Ganti Alat Meter
  const varianceInfo = computeTankVarianceInfo(tankLevelsMap, meterReplacements);

  return {
    dateId,
    displayDate: formatDisplayDate(dateId),
    timestamp: Date.now(),
    flowmeterToday: flowTodayStr,
    flowmeterReference: flowRefStr,
    referenceSource: anyMeterReplaced ? "MANUAL_OVERRIDE" : reference.source,
    fuelConsumed,
    totalKwhProduced,
    sfc: Number(sfcFormatted),
    sfcFormatted,
    kwhBlocks: kwhBlocksFormatted,
    blockReferences: blockReferencesMap,
    meterReplacements,
    tankLevels: tankLevelsMap,
    tankVariance: varianceInfo.totalVariance,
    tankRemark: varianceInfo.remark,
    operator: "ampenan"
  };
}

/**
 * PERTAHANAN RIWAYAT (Historical Immutability Guard):
 * Data harian yang sudah di-submit ke database dikunci sebagai snapshot mandiri.
 * Penggantian alat meter baru atau perubahan pada hari ini TIDAK AKAN PERNAH
 * mengubah inputan maupun hasil SFC hari-hari sebelumnya.
 */
function updateDashboardLockState() {
  const selectedDateStr = inputDate ? inputDate.value : "";
  const existingLog = dailyLogsCache.find((item) => item.dateId === selectedDateStr);

  if (existingLog) {
    if (submittedLockBanner) submittedLockBanner.classList.remove("hidden");
    if (btnSubmitDaily) {
      btnSubmitDaily.disabled = true;
      btnSubmitDaily.textContent = `Terkunci · Data ${existingLog.displayDate} Sudah Di-Submit`;
    }
  } else {
    if (submittedLockBanner) submittedLockBanner.classList.add("hidden");
    if (btnSubmitDaily) {
      btnSubmitDaily.disabled = false;
      btnSubmitDaily.textContent = "Hitung & Simpan Log Harian";
    }
  }
}

/**
 * Kalkulasi Harian dengan BigInt & Simpan ke Firestore (`daily_logs`, Doc ID: `YYYY-MM-DD`)
 * Dilengkapi Pertahanan: Tanggal yang sudah di-submit tidak bisa ditimpa dari Dashboard
 * dan tidak pernah mengubah hasil hari sebelum-sebelumnya.
 */
async function handleDailySubmit(e) {
  e.preventDefault();

  const dateId = inputDate.value;
  const flowTodayStr = sanitizeNumericInput(inputFlowmeter.value);

  if (!dateId || !flowTodayStr) {
    showFeedback("Mohon lengkapi Tanggal dan nilai Flowmeter BBM Hari Ini.", "error");
    return;
  }

  // PERTAHANAN: Cegah penimpaan data yang sudah di-submit dari form input harian
  const alreadySubmitted = dailyLogsCache.find((item) => item.dateId === dateId);
  if (alreadySubmitted) {
    showFeedback(
      `Proteksi Riwayat: Data tanggal ${alreadySubmitted.displayDate} sudah di-submit dan dikunci. Gunakan tombol Edit pada menu Reports jika ingin mengubahnya.`,
      "error"
    );
    updateDashboardLockState();
    return;
  }

  // Cek status Ganti Alat Meter pada Flowmeter dan Blok kWh
  const meterReplacements = {
    flowmeter: Boolean(checkReplaceFlowmeter && checkReplaceFlowmeter.checked)
  };
  const customReferences = {
    flowmeter: sanitizeNumericInput(inputFlowmeterNewBase ? inputFlowmeterNewBase.value : "0") || "0"
  };

  const kwhBlocksInputMap = {};
  const blockInputs = document.querySelectorAll(".kwh-block-input");
  for (const inputEl of blockInputs) {
    const blockName = inputEl.getAttribute("data-block-name");
    kwhBlocksInputMap[blockName] = sanitizeKwhDecimalInput(inputEl.value);
  }

  document.querySelectorAll(".block-replace-check").forEach((chk) => {
    const bName = chk.getAttribute("data-block-name");
    meterReplacements[bName] = Boolean(chk.checked);
  });

  document.querySelectorAll(".block-new-base-input").forEach((inp) => {
    const bName = inp.getAttribute("data-block-name");
    customReferences[bName] = sanitizeKwhDecimalInput(inp.value) || "0.00";
  });

  const tankLevels = {};
  const tankInputs = document.querySelectorAll(".tank-level-input");
  for (const tInput of tankInputs) {
    const tankName = tInput.getAttribute("data-tank-name");
    const levelStr = sanitizeNumericInput(tInput.value);
    if (!levelStr) {
      showFeedback(`Level ${tankName} wajib diisi.`, "error");
      return;
    }
    tankLevels[tankName] = Number(levelStr);
  }

  try {
    const logPayload = await buildDailyLogRecord(
      dateId,
      flowTodayStr,
      kwhBlocksInputMap,
      tankLevels,
      meterReplacements,
      customReferences
    );
    await setDoc(doc(db, DAILY_LOGS_COLLECTION, dateId), logPayload);

    const existingIdx = dailyLogsCache.findIndex((item) => item.dateId === dateId);
    if (existingIdx !== -1) {
      dailyLogsCache[existingIdx] = logPayload;
    } else {
      dailyLogsCache.push(logPayload);
    }

    updateDashboardLockState();

    const statusInfo = evaluateSfcContractStatus(logPayload.sfc);
    showFeedback(
      `Data ${logPayload.displayDate} disimpan & dikunci. SFC: ${logPayload.sfcFormatted} L/kWh (${statusInfo.label}) · Data hari sebelumnya tetap aman.`
    );
  } catch (err) {
    showFeedback(err.message || "Gagal menyimpan data.", "error");
  }
}

/**
 * Render Grafik Tren SFC Harian terhadap Batas Kontrak (0.2800 - 0.2842)
 */
function renderTrendChart() {
  if (!trendChartContainer) return;
  const chronological = [...dailyLogsCache]
    .sort((a, b) => (a.dateId > b.dateId ? 1 : -1))
    .slice(-14);

  if (chronological.length === 0) {
    trendChartContainer.innerHTML = `
      <div style="width: 100%; text-align: center; color: #94a3b8; font-size: 12px; align-self: center;">
        Belum ada data untuk menampilkan grafik tren SFC.
      </div>
    `;
    return;
  }

  const maxSfc = Math.max(0.32, ...chronological.map((d) => Number(d.sfc || 0)));

  trendChartContainer.innerHTML = chronological
    .map((item) => {
      const sfcVal = Number(item.sfc || 0);
      const status = evaluateSfcContractStatus(sfcVal);
      const heightPct = Math.max(12, Math.min(100, Math.round((sfcVal / maxSfc) * 95)));
      const shortDate = item.displayDate ? item.displayDate.slice(0, 5) : item.dateId.slice(5);

      return `
        <div class="trend-bar-col" title="${item.displayDate}: ${sfcVal.toFixed(4)} L/kWh (${status.label})">
          <span class="trend-bar-val mono-num" style="color: ${status.hexColor};">${sfcVal.toFixed(4)}</span>
          <div class="trend-bar" style="height: ${heightPct}%; background-color: ${status.hexColor};"></div>
          <span class="trend-bar-label mono-num">${shortDate}</span>
        </div>
      `;
    })
    .join("");
}

/**
 * Hitung Rata-rata SFC Bulan Berjalan (MTD) dan render tabel Reports
 */
function refreshDashboardAndReports() {
  const currentMonthPrefix = (inputDate.value || getTodayDateString()).slice(0, 7);
  const mtdLogs = dailyLogsCache.filter((item) =>
    String(item.dateId || "").startsWith(currentMonthPrefix)
  );

  if (mtdLogs.length > 0) {
    const sumSfc = mtdLogs.reduce((acc, item) => acc + Number(item.sfc || 0), 0);
    const avgMtd = sumSfc / mtdLogs.length;
    const mtdStatus = evaluateSfcContractStatus(avgMtd);
    valSfcMtd.textContent = avgMtd.toFixed(4);
    valSfcMtd.className = `kpi-value mono-num ${mtdStatus.textClass}`;
    cardSfcMtd.className = `kpi-card ${mtdStatus.cardBorderClass}`;
    valMtdCount.textContent = `${mtdLogs.length} hari · ${mtdStatus.label}`;
  } else {
    valSfcMtd.textContent = "0.0000";
    valSfcMtd.className = "kpi-value mono-num";
    cardSfcMtd.className = "kpi-card";
    valMtdCount.textContent = "Belum ada data bulan ini";
  }

  const selectedLog = dailyLogsCache.find((item) => item.dateId === inputDate.value);
  if (selectedLog) {
    const todayStatus = evaluateSfcContractStatus(selectedLog.sfc);
    valSfcToday.textContent = Number(selectedLog.sfc || 0).toFixed(4);
    valSfcToday.className = `kpi-value mono-num ${todayStatus.textClass}`;
    cardSfcToday.className = `kpi-card highlight ${todayStatus.cardBorderClass}`;
    valSfcSource.textContent = `${todayStatus.label}`;
    valFuelToday.textContent = `${Number(selectedLog.fuelConsumed || 0).toLocaleString("id-ID")} L`;
    valKwhToday.textContent = `${formatKwhDisplay(selectedLog.totalKwhProduced)} kWh`;
  } else {
    valSfcToday.textContent = "0.0000";
    valSfcToday.className = "kpi-value mono-num";
    cardSfcToday.className = "kpi-card highlight";
    valSfcSource.textContent = "Menunggu input tanggal ini";
    valFuelToday.textContent = "0 L";
    valKwhToday.textContent = "0,00 kWh";
  }

  updateDashboardLockState();
  renderTrendChart();
  renderReportsTable();
}

function getFilteredLogs() {
  const start = filterStartDate.value;
  const end = filterEndDate.value;

  return dailyLogsCache.filter((log) => {
    if (start && log.dateId < start) return false;
    if (end && log.dateId > end) return false;
    return true;
  });
}

function renderReportsTable() {
  const filtered = getFilteredLogs();

  if (filtered.length === 0) {
    reportsTableBody.innerHTML = `
      <tr>
        <td colspan="9" style="text-align: center; color: #94a3b8;">Belum ada data pada rentang tanggal ini.</td>
      </tr>
    `;
    return;
  }

  reportsTableBody.innerHTML = filtered
    .map((log) => {
      const blocksSummary = log.kwhBlocks
        ? Object.entries(log.kwhBlocks)
            .map(([k, v]) => `${k}: ${formatKwhDisplay(v)}`)
            .join(" · ")
        : "-";
      const tanksSummary = log.tankLevels
        ? Object.entries(log.tankLevels)
            .map(([k, v]) => `${k}: ${Number(v).toLocaleString("id-ID")}L`)
            .join(" · ")
        : "-";

      const status = evaluateSfcContractStatus(log.sfc);
      const varianceInfo = computeTankVarianceInfo(log.tankLevels, log.meterReplacements);
      const remarkText = log.tankRemark || varianceInfo.remark;
      const remarkColor =
        varianceInfo.totalVariance > 0
          ? "#34d399"
          : varianceInfo.totalVariance < 0
          ? "#fbbf24"
          : remarkText !== "-"
          ? "#38bdf8"
          : "#94a3b8";

      return `
        <tr>
          <td class="mono-num">${log.displayDate}</td>
          <td class="mono-num">${log.flowmeterToday}</td>
          <td class="mono-num">${blocksSummary}</td>
          <td class="mono-num">${Number(log.fuelConsumed).toLocaleString("id-ID")}</td>
          <td class="mono-num">${formatKwhDisplay(log.totalKwhProduced)}</td>
          <td class="mono-num ${status.textClass}" style="font-weight: 700;">${Number(log.sfc).toFixed(4)}</td>
          <td class="mono-num">${tanksSummary}</td>
          <td class="mono-num" style="color: ${remarkColor}; font-weight: 600;">${remarkText}</td>
          <td>
            <div style="display: flex; gap: 6px;">
              <button type="button" class="btn btn-secondary btn-xs btn-edit-row" data-date-id="${log.dateId}">Edit</button>
              <button type="button" class="btn btn-danger btn-xs btn-delete-row" data-date-id="${log.dateId}">Hapus</button>
            </div>
          </td>
        </tr>
      `;
    })
    .join("");

  reportsTableBody.querySelectorAll(".btn-edit-row").forEach((btn) => {
    btn.addEventListener("click", () => {
      const dateId = btn.getAttribute("data-date-id");
      openEditModal(dateId);
    });
  });

  reportsTableBody.querySelectorAll(".btn-delete-row").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const dateId = btn.getAttribute("data-date-id");
      try {
        await deleteDoc(doc(db, DAILY_LOGS_COLLECTION, dateId));
        dailyLogsCache = dailyLogsCache.filter((item) => item.dateId !== dateId);
        updateDashboardLockState();
        showFeedback(`Data tanggal ${formatDisplayDate(dateId)} berhasil dihapus. Data hari lainnya tetap terkunci.`);
      } catch (err) {
        showFeedback(`Gagal menghapus data: ${err.message}`, "error");
      }
    });
  });
}

/**
 * Buka Modal Edit Data untuk tanggal yang dipilih (termasuk kontrol Ganti Alat Meter)
 */
function openEditModal(dateId) {
  const targetLog = dailyLogsCache.find((item) => item.dateId === dateId);
  if (!targetLog) return;

  editOriginalDate.value = targetLog.dateId;
  editDateInput.value = targetLog.dateId;
  editFlowmeterInput.value = targetLog.flowmeterToday || "";

  const isFlowReplaced = Boolean(targetLog.meterReplacements && targetLog.meterReplacements.flowmeter);
  if (editCheckReplaceFlowmeter) {
    editCheckReplaceFlowmeter.checked = isFlowReplaced;
  }
  if (editReplaceFlowmeterBox) {
    if (isFlowReplaced) {
      editReplaceFlowmeterBox.classList.remove("hidden");
    } else {
      editReplaceFlowmeterBox.classList.add("hidden");
    }
  }
  if (editFlowmeterNewBase) {
    editFlowmeterNewBase.value = isFlowReplaced ? targetLog.flowmeterReference || "0" : "0";
  }

  // Render input Metering kWh per Blok + Ganti Alat Meter per Blok
  editBlocksContainer.innerHTML = "";
  appSettings.blocks.forEach((blockName, idx) => {
    const val = (targetLog.kwhBlocks && targetLog.kwhBlocks[blockName]) || "";
    const isBlockReplaced = Boolean(targetLog.meterReplacements && targetLog.meterReplacements[blockName]);
    const blockRefVal =
      isBlockReplaced && targetLog.blockReferences && targetLog.blockReferences[blockName]
        ? targetLog.blockReferences[blockName]
        : "0.00";

    const checkId = `edit-check-replace-block-${idx}`;
    const boxId = `edit-replace-block-box-${idx}`;
    const baseInputId = `edit-block-new-base-${idx}`;

    const div = document.createElement("div");
    div.className = "tank-row";
    div.innerHTML = `
      <div class="tank-header">
        <span style="font-size: 13px; font-weight: 600;">Metering kWh ${blockName}</span>
        <label class="checkbox-label" for="${checkId}">
          <input type="checkbox" id="${checkId}" class="edit-block-replace-check" data-block-name="${blockName}" ${isBlockReplaced ? "checked" : ""} />
          <span>Ganti Alat Meter?</span>
        </label>
      </div>
      <div id="${boxId}" class="${isBlockReplaced ? "" : "hidden"}" style="margin-bottom: 10px;">
        <label class="form-label" for="${baseInputId}" style="font-size: 12px; color: #fbbf24;">
          Stand Awal Meter Baru ${blockName} (Pengurang)
        </label>
        <input
          type="text"
          id="${baseInputId}"
          data-block-name="${blockName}"
          class="form-input mono-num decimal-kwh-only edit-block-new-base"
          inputmode="decimal"
          maxlength="18"
          value="${blockRefVal}"
        />
      </div>
      <input
        type="text"
        id="edit-block-${idx}"
        data-block-name="${blockName}"
        class="form-input mono-num decimal-kwh-only edit-block-input"
        inputmode="decimal"
        maxlength="18"
        value="${val}"
        required
      />
    `;
    editBlocksContainer.appendChild(div);

    const chk = div.querySelector(`#${checkId}`);
    const box = div.querySelector(`#${boxId}`);
    chk.addEventListener("change", () => {
      if (chk.checked) {
        box.classList.remove("hidden");
      } else {
        box.classList.add("hidden");
      }
    });
  });

  // Render input Level BBM per Tangki
  editTanksContainer.innerHTML = "";
  appSettings.tanks.forEach((tankName, idx) => {
    const levelNum =
      targetLog.tankLevels && targetLog.tankLevels[tankName] !== undefined
        ? Number(targetLog.tankLevels[tankName])
        : STANDARD_TANK_NUMBER;
    const isFull = levelNum === STANDARD_TANK_NUMBER;
    const checkId = `edit-tank-check-${idx}`;
    const inputId = `edit-tank-input-${idx}`;

    const row = document.createElement("div");
    row.className = "tank-row";
    row.innerHTML = `
      <div class="tank-header">
        <span style="font-size: 13px; font-weight: 600;">${tankName}</span>
        <label class="checkbox-label" for="${checkId}">
          <input type="checkbox" id="${checkId}" ${isFull ? "checked" : ""} />
          <span>Penuh (Ya = 14.000 L)</span>
        </label>
      </div>
      <input
        type="text"
        id="${inputId}"
        data-tank-name="${tankName}"
        class="form-input mono-num numeric-only edit-tank-input"
        inputmode="numeric"
        maxlength="15"
        value="${levelNum}"
        ${isFull ? "disabled" : ""}
        required
      />
    `;
    editTanksContainer.appendChild(row);

    const checkbox = row.querySelector(`#${checkId}`);
    const levelInput = row.querySelector(`#${inputId}`);
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) {
        levelInput.value = FULL_TANK_LITERS;
        levelInput.disabled = true;
      } else {
        levelInput.disabled = false;
        levelInput.focus();
      }
    });
  });

  attachNumericInputGuards(editModal);
  editModal.classList.remove("hidden");
}

function closeEditModal() {
  editModal.classList.add("hidden");
}

/**
 * Simpan hasil Edit Data Log Harian & hitung ulang SFC
 */
async function handleEditLogSubmit(e) {
  e.preventDefault();
  const origDateId = editOriginalDate.value;
  const newDateId = editDateInput.value;
  const newFlowmeter = sanitizeNumericInput(editFlowmeterInput.value);

  if (!newDateId || !newFlowmeter) {
    showFeedback("Tanggal dan Flowmeter BBM wajib diisi.", "error");
    return;
  }

  const meterReplacements = {
    flowmeter: Boolean(editCheckReplaceFlowmeter && editCheckReplaceFlowmeter.checked)
  };
  const customReferences = {
    flowmeter: sanitizeNumericInput(editFlowmeterNewBase ? editFlowmeterNewBase.value : "0") || "0"
  };

  const kwhBlocksMap = {};
  editBlocksContainer.querySelectorAll(".edit-block-input").forEach((inp) => {
    const bName = inp.getAttribute("data-block-name");
    kwhBlocksMap[bName] = sanitizeKwhDecimalInput(inp.value);
  });

  editBlocksContainer.querySelectorAll(".edit-block-replace-check").forEach((chk) => {
    const bName = chk.getAttribute("data-block-name");
    meterReplacements[bName] = Boolean(chk.checked);
  });

  editBlocksContainer.querySelectorAll(".edit-block-new-base").forEach((inp) => {
    const bName = inp.getAttribute("data-block-name");
    customReferences[bName] = sanitizeKwhDecimalInput(inp.value) || "0.00";
  });

  const tankLevelsMap = {};
  for (const inp of editTanksContainer.querySelectorAll(".edit-tank-input")) {
    const tName = inp.getAttribute("data-tank-name");
    const valStr = sanitizeNumericInput(inp.value);
    if (!valStr) {
      showFeedback(`Level ${tName} wajib diisi.`, "error");
      return;
    }
    tankLevelsMap[tName] = Number(valStr);
  }

  try {
    const existingOriginalRecord =
      origDateId === newDateId
        ? dailyLogsCache.find((item) => item.dateId === origDateId) || null
        : null;

    if (origDateId && origDateId !== newDateId) {
      await deleteDoc(doc(db, DAILY_LOGS_COLLECTION, origDateId));
      dailyLogsCache = dailyLogsCache.filter((item) => item.dateId !== origDateId);
    }

    const updatedRecord = await buildDailyLogRecord(
      newDateId,
      newFlowmeter,
      kwhBlocksMap,
      tankLevelsMap,
      meterReplacements,
      customReferences,
      existingOriginalRecord
    );
    await setDoc(doc(db, DAILY_LOGS_COLLECTION, newDateId), updatedRecord);

    const idx = dailyLogsCache.findIndex((item) => item.dateId === newDateId);
    if (idx !== -1) {
      dailyLogsCache[idx] = updatedRecord;
    } else {
      dailyLogsCache.push(updatedRecord);
    }

    updateDashboardLockState();
    closeEditModal();
    showFeedback(
      `Data tanggal ${updatedRecord.displayDate} berhasil diperbarui secara manual. SFC: ${updatedRecord.sfcFormatted} L/kWh (Data hari lainnya tetap terkunci).`
    );
  } catch (err) {
    showFeedback(err.message || "Gagal memperbarui data.", "error");
  }
}

/**
 * Salin Ringkasan Laporan Harian ke Clipboard (Format WhatsApp)
 */
function copyWhatsAppSummary() {
  const targetLog =
    dailyLogsCache.find((item) => item.dateId === inputDate.value) || dailyLogsCache[0];
  if (!targetLog) {
    showFeedback("Belum ada data log harian untuk disalin.", "error");
    return;
  }

  const status = evaluateSfcContractStatus(targetLog.sfc);
  const variance = computeTankVarianceInfo(targetLog.tankLevels, targetLog.meterReplacements);
  const blocksLines = Object.entries(targetLog.kwhBlocks || {})
    .map(([k, v]) => `• Metering ${k}: ${formatKwhDisplay(v)} kWh`)
    .join("\n");
  const tanksLines = Object.entries(targetLog.tankLevels || {})
    .map(([k, v]) => `${k}: ${Number(v).toLocaleString("id-ID")} L`)
    .join(" | ");

  const text = [
    `*LAPORAN HARIAN SFC - PLTD AMPENAN*`,
    `Tanggal: ${targetLog.displayDate}`,
    `--------------------------------`,
    `• Flowmeter BBM: ${targetLog.flowmeterToday} L (Acuan: ${targetLog.flowmeterReference} L)`,
    `• Konsumsi BBM: ${Number(targetLog.fuelConsumed).toLocaleString("id-ID")} L`,
    blocksLines,
    `• Total Produksi: ${formatKwhDisplay(targetLog.totalKwhProduced)} kWh`,
    `• *SFC Harian: ${Number(targetLog.sfc).toFixed(4)} L/kWh (${status.label})*`,
    `• Level Tangki: ${tanksLines}`,
    `• Keterangan: ${targetLog.tankRemark || variance.remark}`
  ].join("\n");

  navigator.clipboard.writeText(text).then(() => {
    showFeedback(`Ringkasan laporan ${targetLog.displayDate} berhasil disalin (siap tempel ke WhatsApp).`);
  });
}

/**
 * Ekspor data laporan yang difilter ke file CSV (Termasuk kolom Keterangan BBM & Ganti Meter)
 */
function exportReportsToCsv() {
  const rows = getFilteredLogs();
  if (rows.length === 0) {
    showFeedback("Tidak ada data untuk diekspor.", "error");
    return;
  }

  const headers = [
    "Tanggal (DD-MM-YYYY)",
    "Flowmeter Hari Ini",
    "Sumber Pengurang",
    "Konsumsi BBM (Liter)",
    "Total Produksi (kWh)",
    "SFC (Liter/kWh)",
    "Status Kontrak SFC",
    "Detail Blok kWh",
    "Detail Level Tangki (Liter)",
    "Keterangan"
  ];

  const csvLines = [
    headers.join(","),
    ...rows.map((r) => {
      const blocksText = r.kwhBlocks
        ? Object.entries(r.kwhBlocks)
            .map(([k, v]) => `${k}:${Number(v || 0).toFixed(2)}`)
            .join(" | ")
        : "";
      const tanksText = r.tankLevels
        ? Object.entries(r.tankLevels)
            .map(([k, v]) => `${k}:${v}L`)
            .join(" | ")
        : "";
      const status = evaluateSfcContractStatus(r.sfc);
      const variance = computeTankVarianceInfo(r.tankLevels, r.meterReplacements);
      const remark = r.tankRemark || variance.remark;

      return [
        `"${r.displayDate}"`,
        `"${r.flowmeterToday}"`,
        `"${r.referenceSource || "BASELINE"}"`,
        r.fuelConsumed,
        Number(r.totalKwhProduced || 0).toFixed(2),
        Number(r.sfc).toFixed(4),
        `"${status.label}"`,
        `"${blocksText}"`,
        `"${tanksText}"`,
        `"${remark}"`
      ].join(",");
    })
  ];

  const blob = new Blob([csvLines.join("\n")], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `Sewatama_SFC_Report_${getTodayDateString()}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Real-time Listener (onSnapshot) pada koleksi `daily_logs`
 */
function startRealtimeListeners() {
  if (unsubscribeLogs) unsubscribeLogs();

  const colRef = collection(db, DAILY_LOGS_COLLECTION);
  unsubscribeLogs = onSnapshot(
    colRef,
    { includeMetadataChanges: true },
    (snapshot) => {
      const isOffline = snapshot.metadata.fromCache && !navigator.onLine;
      updateConnectionIndicator(!isOffline);

      const docs = [];
      snapshot.forEach((docSnap) => {
        docs.push({ dateId: docSnap.id, ...docSnap.data() });
      });

      docs.sort((a, b) => (a.dateId < b.dateId ? 1 : -1));
      dailyLogsCache = docs;

      refreshDashboardAndReports();
      inspectYesterdayReference(inputDate.value);
    },
    (error) => {
      console.error("Error onSnapshot daily_logs:", error);
      updateConnectionIndicator(false);
    }
  );

  const settingsRef = doc(db, SETTINGS_COLLECTION, BASELINE_DOC_ID);
  onSnapshot(
    settingsRef,
    (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        appSettings = {
          flowmeterBaseline: data.flowmeterBaseline || "1250000",
          blocks: Array.isArray(data.blocks) && data.blocks.length ? data.blocks : ["Blok 1", "Blok 2"],
          tanks: Array.isArray(data.tanks) && data.tanks.length ? data.tanks : ["Tangki 1", "Tangki 2"],
          blockBaselines: data.blockBaselines || { "Blok 1": "4500000.00", "Blok 2": "4800000.00" }
        };
        localStorage.setItem(LOCAL_SETTINGS_KEY, JSON.stringify(appSettings));
        renderDynamicForms();
      }
    },
    (err) => {
      console.warn("Menggunakan pengaturan Data Awal lokal:", err);
    }
  );
}

async function saveSettingsToFirestore() {
  localStorage.setItem(LOCAL_SETTINGS_KEY, JSON.stringify(appSettings));
  try {
    await setDoc(doc(db, SETTINGS_COLLECTION, BASELINE_DOC_ID), {
      flowmeterBaseline: appSettings.flowmeterBaseline,
      blockBaselines: appSettings.blockBaselines,
      blocks: appSettings.blocks,
      tanks: appSettings.tanks,
      updatedAt: Date.now(),
      operator: "ampenan"
    });
    showFeedback("Konfigurasi Data Awal (Baseline) berhasil disimpan.");
  } catch (err) {
    console.error("Gagal menyimpan pengaturan ke Firestore:", err);
    showFeedback("Disimpan di perangkat lokal (menunggu koneksi Firestore).", "error");
  }
}

/**
 * Inisialisasi Aplikasi
 */
function initApp() {
  const savedLocal = localStorage.getItem(LOCAL_SETTINGS_KEY);
  if (savedLocal) {
    try {
      appSettings = { ...appSettings, ...JSON.parse(savedLocal) };
    } catch (e) {
      console.error(e);
    }
  }

  inputDate.value = getTodayDateString();
  renderDynamicForms();

  // Toggle Ganti Alat Meter pada Flowmeter di Dashboard
  if (checkReplaceFlowmeter && replaceFlowmeterBox) {
    checkReplaceFlowmeter.addEventListener("change", () => {
      if (checkReplaceFlowmeter.checked) {
        replaceFlowmeterBox.classList.remove("hidden");
      } else {
        replaceFlowmeterBox.classList.add("hidden");
      }
    });
  }

  // Toggle Ganti Alat Meter pada Flowmeter di Modal Edit
  if (editCheckReplaceFlowmeter && editReplaceFlowmeterBox) {
    editCheckReplaceFlowmeter.addEventListener("change", () => {
      if (editCheckReplaceFlowmeter.checked) {
        editReplaceFlowmeterBox.classList.remove("hidden");
      } else {
        editReplaceFlowmeterBox.classList.add("hidden");
      }
    });
  }

  const session = getActiveSession();
  if (session) {
    loginView.classList.add("hidden");
    mainApp.classList.remove("hidden");
    startRealtimeListeners();
  } else {
    loginView.classList.remove("hidden");
    mainApp.classList.add("hidden");
  }

  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const u = document.getElementById("login-username").value;
    const p = document.getElementById("login-password").value;
    const res = loginOperator(u, p);

    if (res.success) {
      loginError.classList.add("hidden");
      loginView.classList.add("hidden");
      mainApp.classList.remove("hidden");
      startRealtimeListeners();
    } else {
      loginError.textContent = res.message;
      loginError.classList.remove("hidden");
    }
  });

  btnLogout.addEventListener("click", () => {
    logoutOperator();
    if (unsubscribeLogs) unsubscribeLogs();
    mainApp.classList.add("hidden");
    loginView.classList.remove("hidden");
  });

  inputDate.addEventListener("change", () => {
    inspectYesterdayReference(inputDate.value);
    updateDashboardLockState();
    refreshDashboardAndReports();
  });

  if (btnUnlockEditToday) {
    btnUnlockEditToday.addEventListener("click", () => {
      if (inputDate && inputDate.value) {
        openEditModal(inputDate.value);
      }
    });
  }

  dailyInputForm.addEventListener("submit", handleDailySubmit);

  if (btnCopyWaDashboard) {
    btnCopyWaDashboard.addEventListener("click", copyWhatsAppSummary);
  }

  if (editLogForm) {
    editLogForm.addEventListener("submit", handleEditLogSubmit);
  }
  if (btnCloseEditModal) {
    btnCloseEditModal.addEventListener("click", closeEditModal);
  }
  if (btnCancelEdit) {
    btnCancelEdit.addEventListener("click", closeEditModal);
  }

  filterStartDate.addEventListener("change", renderReportsTable);
  filterEndDate.addEventListener("change", renderReportsTable);
  btnResetFilter.addEventListener("click", () => {
    filterStartDate.value = "";
    filterEndDate.value = "";
    renderReportsTable();
  });
  btnExportCsv.addEventListener("click", exportReportsToCsv);

  settingsBaselineForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    appSettings.flowmeterBaseline = sanitizeNumericInput(baselineFlowmeterInput.value) || "0";
    const blockBaseInputs = document.querySelectorAll(".baseline-block-input");
    blockBaseInputs.forEach((inp) => {
      const bName = inp.getAttribute("data-block-name");
      appSettings.blockBaselines[bName] = sanitizeKwhDecimalInput(inp.value) || "0.00";
    });
    await saveSettingsToFirestore();
    inspectYesterdayReference(inputDate.value);
  });

  btnAddBlock.addEventListener("click", async () => {
    const nextNum = appSettings.blocks.length + 1;
    const newBlockName = `Blok ${nextNum}`;
    appSettings.blocks.push(newBlockName);
    appSettings.blockBaselines[newBlockName] = "0.00";
    renderDynamicForms();
    await saveSettingsToFirestore();
  });

  btnRemoveBlock.addEventListener("click", async () => {
    if (appSettings.blocks.length <= 1) {
      showFeedback("Minimal harus terdapat 1 Blok kWh.", "error");
      return;
    }
    const removed = appSettings.blocks.pop();
    delete appSettings.blockBaselines[removed];
    renderDynamicForms();
    await saveSettingsToFirestore();
  });

  btnAddTank.addEventListener("click", async () => {
    const nextNum = appSettings.tanks.length + 1;
    appSettings.tanks.push(`Tangki ${nextNum}`);
    renderDynamicForms();
    await saveSettingsToFirestore();
  });

  btnRemoveTank.addEventListener("click", async () => {
    if (appSettings.tanks.length <= 1) {
      showFeedback("Minimal harus terdapat 1 Tangki BBM.", "error");
      return;
    }
    appSettings.tanks.pop();
    renderDynamicForms();
    await saveSettingsToFirestore();
  });

  btnResetDb.addEventListener("click", async () => {
    try {
      const snap = await getDocs(collection(db, DAILY_LOGS_COLLECTION));
      const deletions = [];
      snap.forEach((d) => {
        deletions.push(deleteDoc(doc(db, DAILY_LOGS_COLLECTION, d.id)));
      });
      await Promise.all(deletions);
      showFeedback("Seluruh data riwayat daily_logs berhasil dihapus dari database.");
    } catch (err) {
      showFeedback(`Gagal mereset database: ${err.message}`, "error");
    }
  });

  const navTabs = document.querySelectorAll(".nav-tab");
  navTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      navTabs.forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");

      const targetId = tab.getAttribute("data-target");
      ["tab-dashboard", "tab-reports", "tab-settings"].forEach((id) => {
        const el = document.getElementById(id);
        if (id === targetId) {
          el.classList.remove("hidden");
        } else {
          el.classList.add("hidden");
        }
      });
    });
  });

  window.addEventListener("online", () => updateConnectionIndicator(true));
  window.addEventListener("offline", () => updateConnectionIndicator(false));
  updateConnectionIndicator(navigator.onLine);
}

document.addEventListener("DOMContentLoaded", initApp);
