// public/app.js
// Logika Utama Kalkulasi SFC Harian (BigInt & Scaled BigInt 2 Desimal kWh),
// Fitur Ganti Alat Meter (Reset Stand Awal per Unit agar tidak minus),
// Keterangan Selisih Tangki BBM (14000 L), Indikator Warna Kontrak SFC (0.2800 - 0.2842),
// Fitur Edit Data Harian + Rekalkulasi Otomatis, Grafik Tren SFC, dan Sinkronisasi Real-time Firestore

import {
  db,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  onSnapshot
} from "./firebaseConfig.js";
import {
  loginOperator,
  getActiveSession,
  logoutOperator,
  getStoredPltdAccounts,
  saveLocalPltdAccount,
  removeLocalPltdAccount,
  syncLocalPltdAccounts,
  isAdminSession,
  setAdminManagedSite,
  sanitizeAccountId
} from "./auth.js";

const DAILY_LOGS_COLLECTION = "daily_logs";
const SETTINGS_COLLECTION = "settings";
const PLTD_ACCOUNTS_COLLECTION = "pltd_accounts";
const BASELINE_DOC_ID = "baseline_config";
const LOCAL_SETTINGS_KEY = "sewatama_sfc_baseline_settings";
const FULL_TANK_LITERS = "14000";
const STANDARD_TANK_NUMBER = 14000;

function getActiveSiteId() {
  const s = getActiveSession();
  if (!s) return "ampenan";
  if (s.managedSiteId) return s.managedSiteId;
  return s.username && s.username !== "admin" ? s.username : "ampenan";
}

function getActiveSiteName() {
  const s = getActiveSession();
  if (!s) return "PLTD Ampenan";
  if (s.managedSiteName) return s.managedSiteName;
  return s.siteName && s.role !== "admin" ? s.siteName : "PLTD Ampenan";
}

function getLogsCollectionPath(siteId = getActiveSiteId()) {
  return siteId === "ampenan" ? DAILY_LOGS_COLLECTION : `sites/${siteId}/daily_logs`;
}

function getSettingsCollectionPath(siteId = getActiveSiteId()) {
  return siteId === "ampenan" ? SETTINGS_COLLECTION : `sites/${siteId}/settings`;
}

function getLocalSettingsStorageKey(siteId = getActiveSiteId()) {
  return siteId === "ampenan" ? LOCAL_SETTINGS_KEY : `${LOCAL_SETTINGS_KEY}_${siteId}`;
}

function getDefaultAppSettings() {
  return {
    flowmeterBaseline: "1250000",
    blocks: ["Blok 1", "Blok 2"],
    tanks: ["Tangki 1", "Tangki 2"],
    blockBaselines: {
      "Blok 1": "4500000.00",
      "Blok 2": "4800000.00"
    }
  };
}

// Batas Kontrak SFC
const SFC_CONTRACT_MIN = 0.2800;
const SFC_CONTRACT_MAX = 0.2842;

// State Aplikasi
let dailyLogsCache = [];
let pltdAccountsCache = getStoredPltdAccounts();
let unsubscribeLogs = null;
let unsubscribeSettings = null;
let unsubscribeAccounts = null;
let appSettings = getDefaultAppSettings();

// Elemen DOM
const loginView = document.getElementById("login-view");
const mainApp = document.getElementById("main-app");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");
const btnLogout = document.getElementById("btn-logout");
const firebaseStatusEl = document.getElementById("firebase-status");
const firebaseStatusText = document.getElementById("firebase-status-text");
const appFeedback = document.getElementById("app-feedback");

const inputDate = document.getElementById("input-date");
const inputFlowmeter = document.getElementById("input-flowmeter");
const checkReplaceFlowmeter = document.getElementById("check-replace-flowmeter");
const replaceFlowmeterBox = document.getElementById("replace-flowmeter-box");
const inputFlowmeterNewBase = document.getElementById("input-flowmeter-new-base");
const dynamicBlocksContainer = document.getElementById("dynamic-blocks-container");
const dynamicTanksContainer = document.getElementById("dynamic-tanks-container");
const dailyInputForm = document.getElementById("daily-input-form");
const btnSubmitDaily = document.getElementById("btn-submit-daily");
const submittedLockBanner = document.getElementById("submitted-lock-banner");
const btnUnlockEditToday = document.getElementById("btn-unlock-edit-today");
const referenceBadge = document.getElementById("reference-badge");
const refFlowmeterHint = document.getElementById("ref-flowmeter-hint");

const cardSfcToday = document.getElementById("card-sfc-today");
const cardSfcMtd = document.getElementById("card-sfc-mtd");
const valSfcToday = document.getElementById("val-sfc-today");
const valSfcSource = document.getElementById("val-sfc-source");
const valSfcMtd = document.getElementById("val-sfc-mtd");
const valMtdCount = document.getElementById("val-mtd-count");
const valFuelToday = document.getElementById("val-fuel-today");
const valKwhToday = document.getElementById("val-kwh-today");
const trendChartContainer = document.getElementById("trend-chart-container");
const btnCopyWaDashboard = document.getElementById("btn-copy-wa-dashboard");

const filterStartDate = document.getElementById("filter-start-date");
const filterEndDate = document.getElementById("filter-end-date");
const btnResetFilter = document.getElementById("btn-reset-filter");
const btnExportCsv = document.getElementById("btn-export-csv");
const btnShareExcel = document.getElementById("btn-share-excel");
const reportsTableBody = document.getElementById("reports-table-body");

const settingsBaselineForm = document.getElementById("settings-baseline-form");
const baselineFlowmeterInput = document.getElementById("baseline-flowmeter");
const settingsBlocksBaselineContainer = document.getElementById("settings-blocks-baseline-container");
const btnAddBlock = document.getElementById("btn-add-block");
const btnRemoveBlock = document.getElementById("btn-remove-block");
const btnAddTank = document.getElementById("btn-add-tank");
const btnRemoveTank = document.getElementById("btn-remove-tank");
const btnResetDb = document.getElementById("btn-reset-db");
const activeSiteBadge = document.getElementById("active-site-badge");
const adminControlBar = document.getElementById("admin-control-bar");
const adminActiveBranchTitle = document.getElementById("admin-active-branch-title");
const adminBranchSelect = document.getElementById("admin-branch-select");
const btnGotoAdminPanel = document.getElementById("btn-goto-admin-panel");
const btnRefreshAllBranches = document.getElementById("btn-refresh-all-branches");
const adminAllBranchesTbody = document.getElementById("admin-all-branches-tbody");
const navTabAdmin = document.getElementById("nav-tab-admin");
const settingsActiveSiteName = document.getElementById("settings-active-site-name");
const settingsActiveDbPath = document.getElementById("settings-active-db-path");
const resetDbSiteLabel = document.getElementById("reset-db-site-label");
const pltdAccountsListEl = document.getElementById("pltd-accounts-list");
const addPltdAccountForm = document.getElementById("add-pltd-account-form");
const newPltdUsernameInput = document.getElementById("new-pltd-username");
const newPltdSitenameInput = document.getElementById("new-pltd-sitename");
const newPltdPasswordInput = document.getElementById("new-pltd-password");

// Elemen Modal Edit
const editModal = document.getElementById("edit-modal");
const editLogForm = document.getElementById("edit-log-form");
const editOriginalDate = document.getElementById("edit-original-date");
const editDateInput = document.getElementById("edit-date");
const editFlowmeterInput = document.getElementById("edit-flowmeter");
const editCheckReplaceFlowmeter = document.getElementById("edit-check-replace-flowmeter");
const editReplaceFlowmeterBox = document.getElementById("edit-replace-flowmeter-box");
const editFlowmeterNewBase = document.getElementById("edit-flowmeter-new-base");
const editBlocksContainer = document.getElementById("edit-blocks-container");
const editTanksContainer = document.getElementById("edit-tanks-container");
const btnCloseEditModal = document.getElementById("btn-close-edit-modal");
const btnCancelEdit = document.getElementById("btn-cancel-edit");

/**
 * Validasi input teks agar hanya menerima karakter angka 0-9 maksimal 15 digit
 */
function sanitizeNumericInput(value) {
  return String(value || "").replace(/[^0-9]/g, "").slice(0, 15);
}

/**
 * Validasi input Metering kWh: mendukung hingga 15 digit bulat + maksimal 2 angka di belakang koma/titik.
 */
function sanitizeKwhDecimalInput(value) {
  const normalized = String(value || "").replace(/,/g, ".");
  const cleaned = normalized.replace(/[^0-9.]/g, "");
  const parts = cleaned.split(".");
  const intPart = (parts[0] || "").slice(0, 15);
  if (parts.length > 1) {
    const decPart = parts.slice(1).join("").slice(0, 2);
    return `${intPart}.${decPart}`;
  }
  return intPart;
}

/**
 * Konversi string kWh (maks 2 desimal) menjadi Scaled BigInt (dikali 100n)
 */
function parseKwhToScaledBigInt(valueStr) {
  const clean = sanitizeKwhDecimalInput(valueStr);
  if (!clean) return 0n;
  const [intPartRaw = "0", decPartRaw = ""] = clean.split(".");
  const intDigits = intPartRaw.replace(/[^0-9]/g, "") || "0";
  const decDigits = decPartRaw.replace(/[^0-9]/g, "").slice(0, 2).padEnd(2, "0");
  return BigInt(intDigits + decDigits);
}

function formatKwhDisplay(val) {
  const num = Number(val || 0);
  if (Number.isNaN(num)) return "0,00";
  return num.toLocaleString("id-ID", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

/**
 * Evaluasi status warna SFC berdasarkan Kontrak (Maks 0.2842):
 * - Hijau: 0.2800 s/d 0.2842
 * - Merah: > 0.2842
 * - Kuning: < 0.2800 (dan > 0)
 */
function evaluateSfcContractStatus(sfcValue) {
  const val = Number(Number(sfcValue || 0).toFixed(4));
  if (val <= 0) {
    return {
      zone: "neutral",
      textClass: "",
      cardBorderClass: "",
      hexColor: "#94a3b8",
      label: "Belum ada data"
    };
  }
  if (val >= SFC_CONTRACT_MIN && val <= SFC_CONTRACT_MAX) {
    return {
      zone: "green",
      textClass: "sfc-green",
      cardBorderClass: "card-border-green",
      hexColor: "#34d399",
      label: "HIJAU · Sesuai Kontrak (0.2800–0.2842)"
    };
  }
  if (val > SFC_CONTRACT_MAX) {
    return {
      zone: "red",
      textClass: "sfc-red",
      cardBorderClass: "card-border-red",
      hexColor: "#fb7185",
      label: "MERAH · Melebihi Kontrak (> 0.2842)"
    };
  }
  return {
    zone: "yellow",
    textClass: "sfc-yellow",
    cardBorderClass: "card-border-yellow",
    hexColor: "#fbbf24",
    label: "KUNING · Di Bawah 0.2800 (< 0.2800)"
  };
}

/**
 * Hitung selisih level tangki BBM terhadap standar 14000 Liter per tangki
 * dan gabungkan dengan keterangan Ganti Alat Meter jika ada.
 */
function computeTankVarianceInfo(tankLevels, meterReplacements = {}) {
  let totalVariance = 0;
  let hasNonStandard = false;

  if (tankLevels && typeof tankLevels === "object") {
    for (const [, rawVal] of Object.entries(tankLevels)) {
      const level = Number(rawVal || 0);
      const diff = level - STANDARD_TANK_NUMBER;
      if (diff !== 0) {
        hasNonStandard = true;
      }
      totalVariance += diff;
    }
  }

  const parts = [];
  if (hasNonStandard) {
    if (totalVariance > 0) {
      parts.push(`BBM +${totalVariance} L`);
    } else if (totalVariance < 0) {
      parts.push(`BBM ${totalVariance} L`);
    } else {
      parts.push("BBM 0 L");
    }
  }

  if (meterReplacements && typeof meterReplacements === "object") {
    const replacedUnits = Object.entries(meterReplacements)
      .filter(([, isReplaced]) => Boolean(isReplaced))
      .map(([unit]) => (unit === "flowmeter" ? "Flowmeter" : unit));
    if (replacedUnits.length > 0) {
      parts.push(`Ganti Meter: ${replacedUnits.join(", ")}`);
    }
  }

  return {
    totalVariance,
    hasNonStandard,
    remark: parts.length > 0 ? parts.join(" · ") : "-"
  };
}

function attachNumericInputGuards(root = document) {
  const inputs = root.querySelectorAll(".numeric-only");
  inputs.forEach((input) => {
    input.addEventListener("input", (e) => {
      const cleaned = sanitizeNumericInput(e.target.value);
      if (e.target.value !== cleaned) {
        e.target.value = cleaned;
      }
    });

    input.addEventListener("keydown", (e) => {
      if (["e", "E", "+", "-", ".", ","].includes(e.key)) {
        e.preventDefault();
      }
    });
  });

  const decInputs = root.querySelectorAll(".decimal-kwh-only");
  decInputs.forEach((input) => {
    input.addEventListener("input", (e) => {
      const cleaned = sanitizeKwhDecimalInput(e.target.value);
      if (e.target.value !== cleaned) {
        e.target.value = cleaned;
      }
    });

    input.addEventListener("keydown", (e) => {
      if (["e", "E", "+", "-"].includes(e.key)) {
        e.preventDefault();
      }
      if ((e.key === "." || e.key === ",") && String(e.target.value).includes(".")) {
        e.preventDefault();
      }
    });
  });
}

function formatDisplayDate(yyyyMmDd) {
  const [year, month, day] = yyyyMmDd.split("-");
  return `${day}-${month}-${year}`;
}

function getYesterdayDateId(todayStr) {
  const [year, month, day] = todayStr.split("-").map(Number);
  const dateObj = new Date(Date.UTC(year, month - 1, day));
  dateObj.setUTCDate(dateObj.getUTCDate() - 1);
  return dateObj.toISOString().slice(0, 10);
}

function getNextDateId(todayStr) {
  const [year, month, day] = todayStr.split("-").map(Number);
  const dateObj = new Date(Date.UTC(year, month - 1, day));
  dateObj.setUTCDate(dateObj.getUTCDate() + 1);
  return dateObj.toISOString().slice(0, 10);
}

function getTodayDateString() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function showFeedback(message, type = "success") {
  appFeedback.textContent = message;
  appFeedback.className = `alert-box ${type === "error" ? "alert-error" : "alert-success"}`;
  appFeedback.classList.remove("hidden");
  setTimeout(() => {
    appFeedback.classList.add("hidden");
  }, 5500);
}

function updateConnectionIndicator(isOnline) {
  if (isOnline) {
    firebaseStatusEl.className = "conn-status conn-online";
    firebaseStatusText.textContent = "Online";
  } else {
    firebaseStatusEl.className = "conn-status conn-offline";
    firebaseStatusText.textContent = "Offline";
  }
}

/**
 * Render input dinamis untuk Blok kWh (beserta fitur Ganti Alat Meter per Blok)
 * dan Tangki BBM pada Dashboard & Settings
 */
function renderDynamicForms() {
  // 1. Render Blok kWh di Dashboard + Checkbox Ganti Alat Meter per Blok
  dynamicBlocksContainer.innerHTML = "";
  appSettings.blocks.forEach((blockName, idx) => {
    const safeId = `input-kwh-block-${idx}`;
    const hintId = `ref-kwh-hint-${idx}`;
    const checkReplaceId = `check-replace-block-${idx}`;
    const replaceBoxId = `replace-block-box-${idx}`;
    const newBaseInputId = `input-block-new-base-${idx}`;

    const wrapper = document.createElement("div");
    wrapper.className = "tank-row";
    wrapper.innerHTML = `
      <div class="tank-header">
        <div>
          <span style="font-size: 13px; font-weight: 600; color: #f1f5f9;">kWh Metering Hari Ini ${blockName}</span>
          <div id="${hintId}" class="form-hint mono-num">Acuan Kemarin: -</div>
        </div>
        <label class="checkbox-label" for="${checkReplaceId}">
          <input type="checkbox" id="${checkReplaceId}" class="block-replace-check" data-block-name="${blockName}" />
          <span>Ganti Alat Meter?</span>
        </label>
      </div>
      <div id="${replaceBoxId}" class="hidden" style="margin-bottom: 10px; padding: 10px; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.35); border-radius: 8px;">
        <label class="form-label" for="${newBaseInputId}" style="font-size: 12px; color: #fbbf24;">
          <span>Stand Awal Meter Baru ${blockName} (Pengurang Pengganti)</span>
          <span class="form-hint" style="color: #fde68a;">Default: 0.00</span>
        </label>
        <input
          type="text"
          id="${newBaseInputId}"
          data-block-name="${blockName}"
          class="form-input mono-num decimal-kwh-only block-new-base-input"
          inputmode="decimal"
          maxlength="18"
          value="0.00"
          placeholder="Stand awal meter baru (contoh: 0.00)"
        />
      </div>
      <input
        type="text"
        id="${safeId}"
        data-block-name="${blockName}"
        class="form-input mono-num decimal-kwh-only kwh-block-input"
        inputmode="decimal"
        maxlength="18"
        placeholder="Contoh: 4505120.25"
        required
      />
    `;
    dynamicBlocksContainer.appendChild(wrapper);

    const checkEl = wrapper.querySelector(`#${checkReplaceId}`);
    const boxEl = wrapper.querySelector(`#${replaceBoxId}`);
    checkEl.addEventListener("change", () => {
      if (checkEl.checked) {
        boxEl.classList.remove("hidden");
      } else {
        boxEl.classList.add("hidden");
      }
    });
  });

  // 2. Render Tangki BBM di Dashboard (Checkbox Ya = auto-isi 14000 & disabled)
  dynamicTanksContainer.innerHTML = "";
  appSettings.tanks.forEach((tankName, idx) => {
    const checkId = `tank-full-check-${idx}`;
    const inputId = `tank-level-input-${idx}`;
    const row = document.createElement("div");
    row.className = "tank-row";
    row.innerHTML = `
      <div class="tank-header">
        <span style="font-size: 13px; font-weight: 600;">${tankName}</span>
        <label class="checkbox-label" for="${checkId}">
          <input type="checkbox" id="${checkId}" data-target-input="${inputId}" />
          <span>Penuh (Ya = 14.000 L)</span>
        </label>
      </div>
      <input
        type="text"
        id="${inputId}"
        data-tank-name="${tankName}"
        class="form-input mono-num numeric-only tank-level-input"
        inputmode="numeric"
        maxlength="15"
        placeholder="Masukkan level ${tankName} (Liter)"
        required
      />
    `;
    dynamicTanksContainer.appendChild(row);

    const checkbox = row.querySelector(`#${checkId}`);
    const levelInput = row.querySelector(`#${inputId}`);
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) {
        levelInput.value = FULL_TANK_LITERS;
        levelInput.disabled = true;
      } else {
        levelInput.disabled = false;
        levelInput.value = "";
        levelInput.focus();
      }
    });
  });

  // 3. Render Data Awal (Baseline) di Menu Settings
  baselineFlowmeterInput.value = appSettings.flowmeterBaseline || "1250000";
  settingsBlocksBaselineContainer.innerHTML = "";
  appSettings.blocks.forEach((blockName, idx) => {
    const baseVal = appSettings.blockBaselines[blockName] || "4500000.00";
    const wrapper = document.createElement("div");
    wrapper.className = "form-group";
    wrapper.innerHTML = `
      <label class="form-label" for="baseline-block-${idx}">Data Awal kWh ${blockName} (Maks 2 Desimal)</label>
      <input
        type="text"
        id="baseline-block-${idx}"
        data-block-name="${blockName}"
        class="form-input mono-num decimal-kwh-only baseline-block-input"
        inputmode="decimal"
        maxlength="18"
        value="${baseVal}"
        required
      />
    `;
    settingsBlocksBaselineContainer.appendChild(wrapper);
  });

  attachNumericInputGuards(document);
  inspectYesterdayReference(inputDate.value);
}

/**
 * Mengambil data pengurang (Hari Kemarin dari Firestore atau Data Awal dari Settings)
 */
async function resolveReferenceMetering(selectedDateStr) {
  const yesterdayId = getYesterdayDateId(selectedDateStr);

  const cachedYesterday = dailyLogsCache.find((item) => item.dateId === yesterdayId);
  if (cachedYesterday) {
    return {
      source: "YESTERDAY",
      yesterdayId,
      flowmeterRef: String(cachedYesterday.flowmeterToday || "0"),
      blockRefs: cachedYesterday.kwhBlocks || {}
    };
  }

  try {
    const yesterdayDocRef = doc(db, getLogsCollectionPath(), yesterdayId);
    const yesterdaySnap = await getDoc(yesterdayDocRef);

    if (yesterdaySnap.exists()) {
      const data = yesterdaySnap.data();
      return {
        source: "YESTERDAY",
        yesterdayId,
        flowmeterRef: String(data.flowmeterToday || "0"),
        blockRefs: data.kwhBlocks || {}
      };
    }
  } catch (err) {
    console.warn("Fallback ke Data Awal:", err);
  }

  return {
    source: "BASELINE",
    yesterdayId,
    flowmeterRef: String(appSettings.flowmeterBaseline || "0"),
    blockRefs: { ...appSettings.blockBaselines }
  };
}

async function inspectYesterdayReference(selectedDateStr) {
  if (!selectedDateStr) return;
  const ref = await resolveReferenceMetering(selectedDateStr);

  if (ref.source === "YESTERDAY") {
    referenceBadge.textContent = `Pengurang: Data Kemarin (${ref.yesterdayId})`;
  } else {
    referenceBadge.textContent = "Pengurang: Data Awal (Settings)";
  }

  refFlowmeterHint.textContent = `Acuan Kemarin: ${ref.flowmeterRef}`;
  appSettings.blocks.forEach((blockName, idx) => {
    const hintEl = document.getElementById(`ref-kwh-hint-${idx}`);
    if (hintEl) {
      const blockRefVal = ref.blockRefs[blockName] ?? appSettings.blockBaselines[blockName] ?? "0";
      hintEl.textContent = `Acuan Kemarin: ${blockRefVal}`;
    }
  });
}

/**
 * Fungsi inti pembuat objek log harian (mendukung Fitur Ganti Alat Meter per unit agar tidak minus
 * serta Pertahanan Snapshot Historis agar pengurang data lama tidak berubah).
 */
async function buildDailyLogRecord(
  dateId,
  flowTodayStr,
  kwhBlocksInputMap,
  tankLevelsMap,
  meterReplacements = {},
  customReferences = {},
  existingLockedRecord = null
) {
  const reference = await resolveReferenceMetering(dateId);

  // PERTAHANAN RIWAYAT: Jika sedang mengedit data lama dan tidak ada H-1, gunakan acuan yang sudah terkunci pada dokumen tersebut
  const lockedFlowRef =
    existingLockedRecord && existingLockedRecord.flowmeterReference
      ? String(existingLockedRecord.flowmeterReference)
      : null;
  const lockedBlockRefs =
    existingLockedRecord && existingLockedRecord.blockReferences
      ? existingLockedRecord.blockReferences
      : {};

  const isFlowmeterReplaced = Boolean(meterReplacements.flowmeter);
  const defaultFlowRef =
    reference.source === "YESTERDAY"
      ? reference.flowmeterRef
      : lockedFlowRef !== null
      ? lockedFlowRef
      : reference.flowmeterRef;

  const flowRefStr = isFlowmeterReplaced
    ? sanitizeNumericInput(customReferences.flowmeter ?? "0") || "0"
    : sanitizeNumericInput(defaultFlowRef || "0") || "0";

  // 1. Pengurangan Flowmeter BBM murni menggunakan BigInt
  const flowTodayBig = BigInt(flowTodayStr);
  const flowRefBig = BigInt(flowRefStr);
  const fuelConsumedBig = flowTodayBig - flowRefBig;

  if (fuelConsumedBig < 0n) {
    throw new Error(
      `Validasi Gagal (${dateId}): Flowmeter (${flowTodayStr}) lebih kecil dari pengurang (${flowRefStr}). Jika alat meter baru diganti/reset, aktifkan centang 'Ganti Alat Meter?'.`
    );
  }

  // 2. Pengurangan kWh seluruh Blok menggunakan Scaled BigInt (x100n untuk 2 desimal)
  const kwhBlocksFormatted = {};
  const blockReferencesMap = {};
  let totalKwhProducedScaledBig = 0n;
  let anyMeterReplaced = isFlowmeterReplaced;

  for (const blockName of appSettings.blocks) {
    const rawBlockStr = sanitizeKwhDecimalInput(kwhBlocksInputMap[blockName] || "");
    if (!rawBlockStr) {
      throw new Error(`Nilai Metering kWh untuk ${blockName} wajib diisi.`);
    }

    const isBlockReplaced = Boolean(meterReplacements[blockName]);
    if (isBlockReplaced) anyMeterReplaced = true;

    const fallbackBlockRef =
      reference.source === "YESTERDAY"
        ? reference.blockRefs[blockName]
        : lockedBlockRefs[blockName] !== undefined
        ? lockedBlockRefs[blockName]
        : reference.blockRefs[blockName];

    const kwhRefStr = isBlockReplaced
      ? sanitizeKwhDecimalInput(customReferences[blockName] ?? "0.00") || "0.00"
      : sanitizeKwhDecimalInput(
          fallbackBlockRef ?? appSettings.blockBaselines[blockName] ?? "0"
        ) || "0";

    const kwhTodayScaledBig = parseKwhToScaledBigInt(rawBlockStr);
    const kwhRefScaledBig = parseKwhToScaledBigInt(kwhRefStr);
    const blockDeltaScaledBig = kwhTodayScaledBig - kwhRefScaledBig;

    if (blockDeltaScaledBig < 0n) {
      throw new Error(
        `Validasi Gagal (${dateId}): Metering ${blockName} (${rawBlockStr}) lebih kecil dari pengurang (${kwhRefStr}). Jika alat meter ${blockName} baru diganti, aktifkan centang 'Ganti Alat Meter?'.`
      );
    }

    kwhBlocksFormatted[blockName] = (Number(kwhTodayScaledBig) / 100).toFixed(2);
    blockReferencesMap[blockName] = (Number(kwhRefScaledBig) / 100).toFixed(2);
    totalKwhProducedScaledBig += blockDeltaScaledBig;
  }

  const fuelConsumed = Number(fuelConsumedBig);
  const totalKwhProduced = Number((Number(totalKwhProducedScaledBig) / 100).toFixed(2));

  if (totalKwhProduced <= 0) {
    throw new Error("Total produksi kWh seluruh blok harus lebih besar dari 0 untuk menghitung SFC.");
  }

  // 3. SFC murni dihitung dari selisih Flowmeter dibagi Total Produksi kWh
  const sfc = fuelConsumed / totalKwhProduced;
  const sfcFormatted = sfc.toFixed(4);

  // 4. Catatan selisih level tangki BBM terhadap 14000 L + info Ganti Alat Meter
  const varianceInfo = computeTankVarianceInfo(tankLevelsMap, meterReplacements);

  return {
    dateId,
    displayDate: formatDisplayDate(dateId),
    timestamp: Date.now(),
    flowmeterToday: flowTodayStr,
    flowmeterReference: flowRefStr,
    referenceSource: anyMeterReplaced ? "MANUAL_OVERRIDE" : reference.source,
    fuelConsumed,
    totalKwhProduced,
    sfc: Number(sfcFormatted),
    sfcFormatted,
    kwhBlocks: kwhBlocksFormatted,
    blockReferences: blockReferencesMap,
    meterReplacements,
    tankLevels: tankLevelsMap,
    tankVariance: varianceInfo.totalVariance,
    tankRemark: varianceInfo.remark,
    operator: getActiveSiteId()
  };
}

/**
 * PERTAHANAN RIWAYAT (Historical Immutability Guard):
 * Data harian yang sudah di-submit ke database dikunci sebagai snapshot mandiri.
 * Penggantian alat meter baru atau perubahan pada hari ini TIDAK AKAN PERNAH
 * mengubah inputan maupun hasil SFC hari-hari sebelumnya.
 */
function updateDashboardLockState() {
  const selectedDateStr = inputDate ? inputDate.value : "";
  const existingLog = dailyLogsCache.find((item) => item.dateId === selectedDateStr);
  const isAdmin = isAdminSession();

  if (existingLog) {
    if (submittedLockBanner) submittedLockBanner.classList.remove("hidden");
    if (btnUnlockEditToday) {
      btnUnlockEditToday.textContent = isAdmin
        ? `Edit / Koreksi Data ${existingLog.displayDate} (Akses Super User Admin)`
        : "Edit Manual Data Tanggal Ini";
    }
    if (btnSubmitDaily) {
      btnSubmitDaily.disabled = true;
      btnSubmitDaily.textContent = `Terkunci · Data ${existingLog.displayDate} Sudah Di-Submit`;
    }
  } else {
    if (submittedLockBanner) submittedLockBanner.classList.add("hidden");
    if (btnSubmitDaily) {
      btnSubmitDaily.disabled = false;
      btnSubmitDaily.textContent = isAdmin
        ? `Hitung & Simpan Log Harian (${getActiveSiteName()})`
        : "Hitung & Simpan Log Harian";
    }
  }
}

/**
 * Kalkulasi Harian dengan BigInt & Simpan ke Firestore (`daily_logs`, Doc ID: `YYYY-MM-DD`)
 * Dilengkapi Pertahanan: Tanggal yang sudah di-submit tidak bisa ditimpa dari Dashboard
 * dan tidak pernah mengubah hasil hari sebelum-sebelumnya.
 */
async function handleDailySubmit(e) {
  e.preventDefault();

  const dateId = inputDate.value;
  const flowTodayStr = sanitizeNumericInput(inputFlowmeter.value);

  if (!dateId || !flowTodayStr) {
    showFeedback("Mohon lengkapi Tanggal dan nilai Flowmeter BBM Hari Ini.", "error");
    return;
  }

  // PERTAHANAN: Cegah penimpaan data yang sudah di-submit dari form input harian
  const alreadySubmitted = dailyLogsCache.find((item) => item.dateId === dateId);
  if (alreadySubmitted) {
    showFeedback(
      `Proteksi Riwayat: Data tanggal ${alreadySubmitted.displayDate} sudah di-submit dan dikunci. Gunakan tombol Edit pada menu Reports jika ingin mengubahnya.`,
      "error"
    );
    updateDashboardLockState();
    return;
  }

  // Cek status Ganti Alat Meter pada Flowmeter dan Blok kWh
  const meterReplacements = {
    flowmeter: Boolean(checkReplaceFlowmeter && checkReplaceFlowmeter.checked)
  };
  const customReferences = {
    flowmeter: sanitizeNumericInput(inputFlowmeterNewBase ? inputFlowmeterNewBase.value : "0") || "0"
  };

  const kwhBlocksInputMap = {};
  const blockInputs = document.querySelectorAll(".kwh-block-input");
  for (const inputEl of blockInputs) {
    const blockName = inputEl.getAttribute("data-block-name");
    kwhBlocksInputMap[blockName] = sanitizeKwhDecimalInput(inputEl.value);
  }

  document.querySelectorAll(".block-replace-check").forEach((chk) => {
    const bName = chk.getAttribute("data-block-name");
    meterReplacements[bName] = Boolean(chk.checked);
  });

  document.querySelectorAll(".block-new-base-input").forEach((inp) => {
    const bName = inp.getAttribute("data-block-name");
    customReferences[bName] = sanitizeKwhDecimalInput(inp.value) || "0.00";
  });

  const tankLevels = {};
  const tankInputs = document.querySelectorAll(".tank-level-input");
  for (const tInput of tankInputs) {
    const tankName = tInput.getAttribute("data-tank-name");
    const levelStr = sanitizeNumericInput(tInput.value);
    if (!levelStr) {
      showFeedback(`Level ${tankName} wajib diisi.`, "error");
      return;
    }
    tankLevels[tankName] = Number(levelStr);
  }

  try {
    const logPayload = await buildDailyLogRecord(
      dateId,
      flowTodayStr,
      kwhBlocksInputMap,
      tankLevels,
      meterReplacements,
      customReferences
    );
    await setDoc(doc(db, getLogsCollectionPath(), dateId), logPayload);

    const existingIdx = dailyLogsCache.findIndex((item) => item.dateId === dateId);
    if (existingIdx !== -1) {
      dailyLogsCache[existingIdx] = logPayload;
    } else {
      dailyLogsCache.push(logPayload);
    }

    updateDashboardLockState();

    const statusInfo = evaluateSfcContractStatus(logPayload.sfc);
    showFeedback(
      `Data ${logPayload.displayDate} disimpan & dikunci. SFC: ${logPayload.sfcFormatted} L/kWh (${statusInfo.label}) · Data hari sebelumnya tetap aman.`
    );
  } catch (err) {
    showFeedback(err.message || "Gagal menyimpan data.", "error");
  }
}

/**
 * Render Grafik Tren SFC Harian terhadap Batas Kontrak (0.2800 - 0.2842)
 */
function renderTrendChart() {
  if (!trendChartContainer) return;
  const chronological = [...dailyLogsCache]
    .sort((a, b) => (a.dateId > b.dateId ? 1 : -1))
    .slice(-14);

  if (chronological.length === 0) {
    trendChartContainer.innerHTML = `
      <div style="width: 100%; text-align: center; color: #94a3b8; font-size: 12px; align-self: center;">
        Belum ada data untuk menampilkan grafik tren SFC.
      </div>
    `;
    return;
  }

  const maxSfc = Math.max(0.32, ...chronological.map((d) => Number(d.sfc || 0)));

  trendChartContainer.innerHTML = chronological
    .map((item) => {
      const sfcVal = Number(item.sfc || 0);
      const status = evaluateSfcContractStatus(sfcVal);
      const heightPct = Math.max(12, Math.min(100, Math.round((sfcVal / maxSfc) * 95)));
      const shortDate = item.displayDate ? item.displayDate.slice(0, 5) : item.dateId.slice(5);

      return `
        <div class="trend-bar-col" title="${item.displayDate}: ${sfcVal.toFixed(4)} L/kWh (${status.label})">
          <span class="trend-bar-val mono-num" style="color: ${status.hexColor};">${sfcVal.toFixed(4)}</span>
          <div class="trend-bar" style="height: ${heightPct}%; background-color: ${status.hexColor};"></div>
          <span class="trend-bar-label mono-num">${shortDate}</span>
        </div>
      `;
    })
    .join("");
}

/**
 * Hitung Rata-rata SFC Bulan Berjalan (MTD) dan render tabel Reports
 */
function refreshDashboardAndReports() {
  const currentMonthPrefix = (inputDate.value || getTodayDateString()).slice(0, 7);
  const mtdLogs = dailyLogsCache.filter((item) =>
    String(item.dateId || "").startsWith(currentMonthPrefix)
  );

  if (mtdLogs.length > 0) {
    const sumSfc = mtdLogs.reduce((acc, item) => acc + Number(item.sfc || 0), 0);
    const avgMtd = sumSfc / mtdLogs.length;
    const mtdStatus = evaluateSfcContractStatus(avgMtd);
    valSfcMtd.textContent = avgMtd.toFixed(4);
    valSfcMtd.className = `kpi-value mono-num ${mtdStatus.textClass}`;
    cardSfcMtd.className = `kpi-card ${mtdStatus.cardBorderClass}`;
    valMtdCount.textContent = `${mtdLogs.length} hari · ${mtdStatus.label}`;
  } else {
    valSfcMtd.textContent = "0.0000";
    valSfcMtd.className = "kpi-value mono-num";
    cardSfcMtd.className = "kpi-card";
    valMtdCount.textContent = "Belum ada data bulan ini";
  }

  const selectedLog = dailyLogsCache.find((item) => item.dateId === inputDate.value);
  if (selectedLog) {
    const todayStatus = evaluateSfcContractStatus(selectedLog.sfc);
    valSfcToday.textContent = Number(selectedLog.sfc || 0).toFixed(4);
    valSfcToday.className = `kpi-value mono-num ${todayStatus.textClass}`;
    cardSfcToday.className = `kpi-card highlight ${todayStatus.cardBorderClass}`;
    valSfcSource.textContent = `${todayStatus.label}`;
    valFuelToday.textContent = `${Number(selectedLog.fuelConsumed || 0).toLocaleString("id-ID")} L`;
    valKwhToday.textContent = `${formatKwhDisplay(selectedLog.totalKwhProduced)} kWh`;
  } else {
    valSfcToday.textContent = "0.0000";
    valSfcToday.className = "kpi-value mono-num";
    cardSfcToday.className = "kpi-card highlight";
    valSfcSource.textContent = "Menunggu input tanggal ini";
    valFuelToday.textContent = "0 L";
    valKwhToday.textContent = "0,00 kWh";
  }

  updateDashboardLockState();
  renderTrendChart();
  renderReportsTable();
}

function getFilteredLogs() {
  const start = filterStartDate.value;
  const end = filterEndDate.value;

  return dailyLogsCache.filter((log) => {
    if (start && log.dateId < start) return false;
    if (end && log.dateId > end) return false;
    return true;
  });
}

function renderReportsTable() {
  const filtered = getFilteredLogs();

  if (filtered.length === 0) {
    reportsTableBody.innerHTML = `
      <tr>
        <td colspan="9" style="text-align: center; color: #94a3b8;">Belum ada data pada rentang tanggal ini.</td>
      </tr>
    `;
    return;
  }

  reportsTableBody.innerHTML = filtered
    .map((log) => {
      const blocksSummary = log.kwhBlocks
        ? Object.entries(log.kwhBlocks)
            .map(([k, v]) => `${k}: ${formatKwhDisplay(v)}`)
            .join(" · ")
        : "-";
      const tanksSummary = log.tankLevels
        ? Object.entries(log.tankLevels)
            .map(([k, v]) => `${k}: ${Number(v).toLocaleString("id-ID")}L`)
            .join(" · ")
        : "-";

      const status = evaluateSfcContractStatus(log.sfc);
      const varianceInfo = computeTankVarianceInfo(log.tankLevels, log.meterReplacements);
      const remarkText = log.tankRemark || varianceInfo.remark;
      const remarkColor =
        varianceInfo.totalVariance > 0
          ? "#34d399"
          : varianceInfo.totalVariance < 0
          ? "#fbbf24"
          : remarkText !== "-"
          ? "#38bdf8"
          : "#94a3b8";

      return `
        <tr>
          <td class="mono-num">${log.displayDate}</td>
          <td class="mono-num">${log.flowmeterToday}</td>
          <td class="mono-num">${blocksSummary}</td>
          <td class="mono-num">${Number(log.fuelConsumed).toLocaleString("id-ID")}</td>
          <td class="mono-num">${formatKwhDisplay(log.totalKwhProduced)}</td>
          <td class="mono-num ${status.textClass}" style="font-weight: 700;">${Number(log.sfc).toFixed(4)}</td>
          <td class="mono-num">${tanksSummary}</td>
          <td class="mono-num" style="color: ${remarkColor}; font-weight: 600;">${remarkText}</td>
          <td>
            <div style="display: flex; gap: 6px;">
              <button type="button" class="btn btn-secondary btn-xs btn-edit-row" data-date-id="${log.dateId}">Edit</button>
              <button type="button" class="btn btn-danger btn-xs btn-delete-row" data-date-id="${log.dateId}">Hapus</button>
            </div>
          </td>
        </tr>
      `;
    })
    .join("");

  reportsTableBody.querySelectorAll(".btn-edit-row").forEach((btn) => {
    btn.addEventListener("click", () => {
      const dateId = btn.getAttribute("data-date-id");
      openEditModal(dateId);
    });
  });

  reportsTableBody.querySelectorAll(".btn-delete-row").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const dateId = btn.getAttribute("data-date-id");
      try {
        await deleteDoc(doc(db, getLogsCollectionPath(), dateId));
        dailyLogsCache = dailyLogsCache.filter((item) => item.dateId !== dateId);
        updateDashboardLockState();
        showFeedback(`Data tanggal ${formatDisplayDate(dateId)} berhasil dihapus dari ${getActiveSiteName()}. Data hari lainnya tetap terkunci.`);
      } catch (err) {
        showFeedback(`Gagal menghapus data: ${err.message}`, "error");
      }
    });
  });
}

/**
 * Buka Modal Edit Data untuk tanggal yang dipilih (termasuk kontrol Ganti Alat Meter)
 */
function openEditModal(dateId) {
  const targetLog = dailyLogsCache.find((item) => item.dateId === dateId);
  if (!targetLog) return;

  editOriginalDate.value = targetLog.dateId;
  editDateInput.value = targetLog.dateId;
  editFlowmeterInput.value = targetLog.flowmeterToday || "";

  const isFlowReplaced = Boolean(targetLog.meterReplacements && targetLog.meterReplacements.flowmeter);
  if (editCheckReplaceFlowmeter) {
    editCheckReplaceFlowmeter.checked = isFlowReplaced;
  }
  if (editReplaceFlowmeterBox) {
    if (isFlowReplaced) {
      editReplaceFlowmeterBox.classList.remove("hidden");
    } else {
      editReplaceFlowmeterBox.classList.add("hidden");
    }
  }
  if (editFlowmeterNewBase) {
    editFlowmeterNewBase.value = isFlowReplaced ? targetLog.flowmeterReference || "0" : "0";
  }

  // Render input Metering kWh per Blok + Ganti Alat Meter per Blok
  editBlocksContainer.innerHTML = "";
  appSettings.blocks.forEach((blockName, idx) => {
    const val = (targetLog.kwhBlocks && targetLog.kwhBlocks[blockName]) || "";
    const isBlockReplaced = Boolean(targetLog.meterReplacements && targetLog.meterReplacements[blockName]);
    const blockRefVal =
      isBlockReplaced && targetLog.blockReferences && targetLog.blockReferences[blockName]
        ? targetLog.blockReferences[blockName]
        : "0.00";

    const checkId = `edit-check-replace-block-${idx}`;
    const boxId = `edit-replace-block-box-${idx}`;
    const baseInputId = `edit-block-new-base-${idx}`;

    const div = document.createElement("div");
    div.className = "tank-row";
    div.innerHTML = `
      <div class="tank-header">
        <span style="font-size: 13px; font-weight: 600;">Metering kWh ${blockName}</span>
        <label class="checkbox-label" for="${checkId}">
          <input type="checkbox" id="${checkId}" class="edit-block-replace-check" data-block-name="${blockName}" ${isBlockReplaced ? "checked" : ""} />
          <span>Ganti Alat Meter?</span>
        </label>
      </div>
      <div id="${boxId}" class="${isBlockReplaced ? "" : "hidden"}" style="margin-bottom: 10px;">
        <label class="form-label" for="${baseInputId}" style="font-size: 12px; color: #fbbf24;">
          Stand Awal Meter Baru ${blockName} (Pengurang)
        </label>
        <input
          type="text"
          id="${baseInputId}"
          data-block-name="${blockName}"
          class="form-input mono-num decimal-kwh-only edit-block-new-base"
          inputmode="decimal"
          maxlength="18"
          value="${blockRefVal}"
        />
      </div>
      <input
        type="text"
        id="edit-block-${idx}"
        data-block-name="${blockName}"
        class="form-input mono-num decimal-kwh-only edit-block-input"
        inputmode="decimal"
        maxlength="18"
        value="${val}"
        required
      />
    `;
    editBlocksContainer.appendChild(div);

    const chk = div.querySelector(`#${checkId}`);
    const box = div.querySelector(`#${boxId}`);
    chk.addEventListener("change", () => {
      if (chk.checked) {
        box.classList.remove("hidden");
      } else {
        box.classList.add("hidden");
      }
    });
  });

  // Render input Level BBM per Tangki
  editTanksContainer.innerHTML = "";
  appSettings.tanks.forEach((tankName, idx) => {
    const levelNum =
      targetLog.tankLevels && targetLog.tankLevels[tankName] !== undefined
        ? Number(targetLog.tankLevels[tankName])
        : STANDARD_TANK_NUMBER;
    const isFull = levelNum === STANDARD_TANK_NUMBER;
    const checkId = `edit-tank-check-${idx}`;
    const inputId = `edit-tank-input-${idx}`;

    const row = document.createElement("div");
    row.className = "tank-row";
    row.innerHTML = `
      <div class="tank-header">
        <span style="font-size: 13px; font-weight: 600;">${tankName}</span>
        <label class="checkbox-label" for="${checkId}">
          <input type="checkbox" id="${checkId}" ${isFull ? "checked" : ""} />
          <span>Penuh (Ya = 14.000 L)</span>
        </label>
      </div>
      <input
        type="text"
        id="${inputId}"
        data-tank-name="${tankName}"
        class="form-input mono-num numeric-only edit-tank-input"
        inputmode="numeric"
        maxlength="15"
        value="${levelNum}"
        ${isFull ? "disabled" : ""}
        required
      />
    `;
    editTanksContainer.appendChild(row);

    const checkbox = row.querySelector(`#${checkId}`);
    const levelInput = row.querySelector(`#${inputId}`);
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) {
        levelInput.value = FULL_TANK_LITERS;
        levelInput.disabled = true;
      } else {
        levelInput.disabled = false;
        levelInput.focus();
      }
    });
  });

  attachNumericInputGuards(editModal);
  editModal.classList.remove("hidden");
}

function closeEditModal() {
  editModal.classList.add("hidden");
}

/**
 * Simpan hasil Edit Data Log Harian & hitung ulang SFC
 */
async function handleEditLogSubmit(e) {
  e.preventDefault();
  const origDateId = editOriginalDate.value;
  const newDateId = editDateInput.value;
  const newFlowmeter = sanitizeNumericInput(editFlowmeterInput.value);

  if (!newDateId || !newFlowmeter) {
    showFeedback("Tanggal dan Flowmeter BBM wajib diisi.", "error");
    return;
  }

  const meterReplacements = {
    flowmeter: Boolean(editCheckReplaceFlowmeter && editCheckReplaceFlowmeter.checked)
  };
  const customReferences = {
    flowmeter: sanitizeNumericInput(editFlowmeterNewBase ? editFlowmeterNewBase.value : "0") || "0"
  };

  const kwhBlocksMap = {};
  editBlocksContainer.querySelectorAll(".edit-block-input").forEach((inp) => {
    const bName = inp.getAttribute("data-block-name");
    kwhBlocksMap[bName] = sanitizeKwhDecimalInput(inp.value);
  });

  editBlocksContainer.querySelectorAll(".edit-block-replace-check").forEach((chk) => {
    const bName = chk.getAttribute("data-block-name");
    meterReplacements[bName] = Boolean(chk.checked);
  });

  editBlocksContainer.querySelectorAll(".edit-block-new-base").forEach((inp) => {
    const bName = inp.getAttribute("data-block-name");
    customReferences[bName] = sanitizeKwhDecimalInput(inp.value) || "0.00";
  });

  const tankLevelsMap = {};
  for (const inp of editTanksContainer.querySelectorAll(".edit-tank-input")) {
    const tName = inp.getAttribute("data-tank-name");
    const valStr = sanitizeNumericInput(inp.value);
    if (!valStr) {
      showFeedback(`Level ${tName} wajib diisi.`, "error");
      return;
    }
    tankLevelsMap[tName] = Number(valStr);
  }

  try {
    const existingOriginalRecord =
      origDateId === newDateId
        ? dailyLogsCache.find((item) => item.dateId === origDateId) || null
        : null;

    if (origDateId && origDateId !== newDateId) {
      await deleteDoc(doc(db, getLogsCollectionPath(), origDateId));
      dailyLogsCache = dailyLogsCache.filter((item) => item.dateId !== origDateId);
    }

    const updatedRecord = await buildDailyLogRecord(
      newDateId,
      newFlowmeter,
      kwhBlocksMap,
      tankLevelsMap,
      meterReplacements,
      customReferences,
      existingOriginalRecord
    );
    await setDoc(doc(db, getLogsCollectionPath(), newDateId), updatedRecord);

    const idx = dailyLogsCache.findIndex((item) => item.dateId === newDateId);
    if (idx !== -1) {
      dailyLogsCache[idx] = updatedRecord;
    } else {
      dailyLogsCache.push(updatedRecord);
    }

    updateDashboardLockState();
    closeEditModal();
    showFeedback(
      `Data tanggal ${updatedRecord.displayDate} berhasil diperbarui secara manual. SFC: ${updatedRecord.sfcFormatted} L/kWh (Data hari lainnya tetap terkunci).`
    );
  } catch (err) {
    showFeedback(err.message || "Gagal memperbarui data.", "error");
  }
}

/**
 * Salin Ringkasan Laporan Harian ke Clipboard (Format WhatsApp)
 */
function copyWhatsAppSummary() {
  const targetLog =
    dailyLogsCache.find((item) => item.dateId === inputDate.value) || dailyLogsCache[0];
  if (!targetLog) {
    showFeedback("Belum ada data log harian untuk disalin.", "error");
    return;
  }

  const status = evaluateSfcContractStatus(targetLog.sfc);
  const variance = computeTankVarianceInfo(targetLog.tankLevels, targetLog.meterReplacements);
  const blocksLines = Object.entries(targetLog.kwhBlocks || {})
    .map(([k, v]) => `• Metering ${k}: ${formatKwhDisplay(v)} kWh`)
    .join("\n");
  const tanksLines = Object.entries(targetLog.tankLevels || {})
    .map(([k, v]) => `${k}: ${Number(v).toLocaleString("id-ID")} L`)
    .join(" | ");

  const siteUpper = getActiveSiteName().toUpperCase();
  const text = [
    `*LAPORAN HARIAN SFC - ${siteUpper}*`,
    `Tanggal: ${targetLog.displayDate}`,
    `--------------------------------`,
    `• Flowmeter BBM: ${targetLog.flowmeterToday} L (Acuan: ${targetLog.flowmeterReference} L)`,
    `• Konsumsi BBM: ${Number(targetLog.fuelConsumed).toLocaleString("id-ID")} L`,
    blocksLines,
    `• Total Produksi: ${formatKwhDisplay(targetLog.totalKwhProduced)} kWh`,
    `• *SFC Harian: ${Number(targetLog.sfc).toFixed(4)} L/kWh (${status.label})*`,
    `• Level Tangki: ${tanksLines}`,
    `• Keterangan: ${targetLog.tankRemark || variance.remark}`
  ].join("\n");

  navigator.clipboard.writeText(text).then(() => {
    showFeedback(`Ringkasan laporan ${targetLog.displayDate} berhasil disalin (siap tempel ke WhatsApp).`);
  });
}

/**
 * ============================================================================
 * GENERATOR FILE EXCEL (.XLSX) MURNI (ECMA-376 OPENXML SPREADSHEET)
 * Bekerja 100% Offline Tanpa CDN Eksternal, Mendukung Styling, Kolom Otomatis,
 * Tipe Data Numerik Asli Excel, serta Native Android Capacitor (Filesystem/Share)
 * ============================================================================
 */
function escapeXmlText(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function getExcelColumnLetter(colIdx0) {
  let dividend = colIdx0 + 1;
  let colName = "";
  while (dividend > 0) {
    const modulo = (dividend - 1) % 26;
    colName = String.fromCharCode(65 + modulo) + colName;
    dividend = Math.floor((dividend - modulo) / 26);
  }
  return colName;
}

function computeCrc32(bytes) {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc ^= bytes[i];
    for (let j = 0; j < 8; j++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function createZipArchive(entries) {
  const encoder = new TextEncoder();
  const fileRecords = entries.map((entry) => {
    const nameBytes = encoder.encode(entry.name);
    const dataBytes =
      typeof entry.content === "string" ? encoder.encode(entry.content) : entry.content;
    const crc = computeCrc32(dataBytes);
    return { nameBytes, dataBytes, crc, offset: 0 };
  });

  let localSize = 0;
  let centralSize = 0;
  for (const rec of fileRecords) {
    rec.offset = localSize;
    localSize += 30 + rec.nameBytes.length + rec.dataBytes.length;
    centralSize += 46 + rec.nameBytes.length;
  }

  const totalSize = localSize + centralSize + 22;
  const out = new Uint8Array(totalSize);
  const view = new DataView(out.buffer);
  let pos = 0;

  // 1. Local File Headers + Data
  for (const rec of fileRecords) {
    view.setUint32(pos, 0x04034b50, true); // Local file header signature
    view.setUint16(pos + 4, 20, true); // Version needed to extract (2.0)
    view.setUint16(pos + 6, 0, true); // General purpose bit flag
    view.setUint16(pos + 8, 0, true); // Compression method (0 = STORE)
    view.setUint16(pos + 10, 0x6000, true); // File modification time
    view.setUint16(pos + 12, 0x593e, true); // File modification date
    view.setUint32(pos + 14, rec.crc, true); // CRC-32
    view.setUint32(pos + 18, rec.dataBytes.length, true); // Compressed size
    view.setUint32(pos + 22, rec.dataBytes.length, true); // Uncompressed size
    view.setUint16(pos + 26, rec.nameBytes.length, true); // File name length
    view.setUint16(pos + 28, 0, true); // Extra field length
    pos += 30;
    out.set(rec.nameBytes, pos);
    pos += rec.nameBytes.length;
    out.set(rec.dataBytes, pos);
    pos += rec.dataBytes.length;
  }

  const centralDirOffset = pos;

  // 2. Central Directory File Headers
  for (const rec of fileRecords) {
    view.setUint32(pos, 0x02014b50, true); // Central directory signature
    view.setUint16(pos + 4, 20, true); // Version made by
    view.setUint16(pos + 6, 20, true); // Version needed to extract
    view.setUint16(pos + 8, 0, true); // General purpose bit flag
    view.setUint16(pos + 10, 0, true); // Compression method (0 = STORE)
    view.setUint16(pos + 12, 0x6000, true); // File modification time
    view.setUint16(pos + 14, 0x593e, true); // File modification date
    view.setUint32(pos + 16, rec.crc, true); // CRC-32
    view.setUint32(pos + 20, rec.dataBytes.length, true); // Compressed size
    view.setUint32(pos + 24, rec.dataBytes.length, true); // Uncompressed size
    view.setUint16(pos + 28, rec.nameBytes.length, true); // File name length
    view.setUint16(pos + 30, 0, true); // Extra field length
    view.setUint16(pos + 32, 0, true); // File comment length
    view.setUint16(pos + 34, 0, true); // Disk number start
    view.setUint16(pos + 36, 0, true); // Internal file attributes
    view.setUint32(pos + 38, 0, true); // External file attributes
    view.setUint32(pos + 42, rec.offset, true); // Relative offset of local header
    pos += 46;
    out.set(rec.nameBytes, pos);
    pos += rec.nameBytes.length;
  }

  // 3. End of Central Directory Record (EOCD)
  view.setUint32(pos, 0x06054b50, true);
  view.setUint16(pos + 4, 0, true);
  view.setUint16(pos + 6, 0, true);
  view.setUint16(pos + 8, fileRecords.length, true);
  view.setUint16(pos + 10, fileRecords.length, true);
  view.setUint32(pos + 12, centralSize, true);
  view.setUint32(pos + 16, centralDirOffset, true);
  view.setUint16(pos + 20, 0, true);

  return out;
}

function uint8ArrayToBase64(bytes) {
  let binary = "";
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, chunk);
  }
  return btoa(binary);
}

function buildXlsxWorkbookBytes(rows) {
  const blockNames = Array.isArray(appSettings.blocks) && appSettings.blocks.length
    ? appSettings.blocks
    : ["Blok 1", "Blok 2"];
  const tankNames = Array.isArray(appSettings.tanks) && appSettings.tanks.length
    ? appSettings.tanks
    : ["Tangki 1", "Tangki 2"];

  // Susun daftar kolom dinamis
  const columns = [
    { header: "No", width: 6 },
    { header: "Tanggal (DD-MM-YYYY)", width: 18 },
    { header: "Flowmeter Hari Ini (L)", width: 22 },
    { header: "Flowmeter Pengurang (L)", width: 23 },
    { header: "Sumber Pengurang", width: 18 },
    ...blockNames.map((b) => ({ header: `Metering ${b} (kWh)`, width: 20 })),
    { header: "Konsumsi BBM (Liter)", width: 21 },
    { header: "Total Produksi (kWh)", width: 21 },
    { header: "SFC Harian (L/kWh)", width: 19 },
    { header: "Status Kontrak SFC", width: 28 },
    ...tankNames.map((t) => ({ header: `Level ${t} (L)`, width: 17 })),
    { header: "Total Tangki BBM (L)", width: 20 },
    { header: "Keterangan BBM & Meter", width: 28 }
  ];

  const lastColLetter = getExcelColumnLetter(columns.length - 1);
  const colsXml =
    "<cols>" +
    columns
      .map(
        (c, i) =>
          `<col min="${i + 1}" max="${i + 1}" width="${c.width}" customWidth="1"/>`
      )
      .join("") +
    "</cols>";

  const makeCellXml = (colIdx, rowNum, val, styleId, isNumeric = false) => {
    const ref = `${getExcelColumnLetter(colIdx)}${rowNum}`;
    const numVal = Number(val);
    if (isNumeric && val !== "" && val !== null && val !== undefined && Number.isFinite(numVal)) {
      return `<c r="${ref}" s="${styleId}" t="n"><v>${numVal}</v></c>`;
    }
    return `<c r="${ref}" s="${styleId}" t="inlineStr"><is><t>${escapeXmlText(val)}</t></is></c>`;
  };

  const sheetRowsXml = [];

  // Baris 1: Judul Laporan (Sesuai Unit PLTD Aktif)
  const siteUpper = getActiveSiteName().toUpperCase();
  sheetRowsXml.push(
    `<row r="1" ht="24" customHeight="1">` +
      makeCellXml(
        0,
        1,
        `LAPORAN HARIAN SPECIFIC FUEL CONSUMPTION (SFC) — ${siteUpper}`,
        1,
        false
      ) +
      `</row>`
  );

  // Baris 2: Subjudul & Informasi Ekspor
  const exportDateStr = formatDisplayDate(getTodayDateString());
  sheetRowsXml.push(
    `<row r="2" ht="18" customHeight="1">` +
      makeCellXml(
        0,
        2,
        `PT Sumberdaya Sewatama | Unit: ${getActiveSiteName()} | Tanggal Unduh: ${exportDateStr} | Jumlah Data: ${rows.length} Hari | Target Kontrak SFC: 0.2800 - 0.2842 L/kWh`,
        2,
        false
      ) +
      `</row>`
  );

  // Baris 3: Spasi Kosong
  sheetRowsXml.push(`<row r="3" ht="10" customHeight="1"/>`);

  // Baris 4: Header Tabel
  const headerCells = columns.map((col, idx) => makeCellXml(idx, 4, col.header, 3, false)).join("");
  sheetRowsXml.push(`<row r="4" ht="26" customHeight="1">${headerCells}</row>`);

  // Baris 5 dst: Data Harian (Urut Kronologis / sesuai filter)
  let totalFuelSum = 0;
  let totalKwhSum = 0;
  let totalSfcSum = 0;

  rows.forEach((r, rowIdx) => {
    const excelRowNum = 5 + rowIdx;
    const status = evaluateSfcContractStatus(r.sfc);
    const variance = computeTankVarianceInfo(r.tankLevels, r.meterReplacements);
    const remark = r.tankRemark || variance.remark;

    const fuelNum = Number(r.fuelConsumed || 0);
    const kwhNum = Number(r.totalKwhProduced || 0);
    const sfcNum = Number(r.sfc || 0);

    totalFuelSum += fuelNum;
    totalKwhSum += kwhNum;
    totalSfcSum += sfcNum;

    const statusStyleId =
      status.zone === "green" ? 9 : status.zone === "yellow" ? 10 : 11;

    const refSourceLabel =
      r.referenceSource === "MANUAL_OVERRIDE" || r.referenceSource === "METER_REPLACEMENT"
        ? "Ganti Alat Meter"
        : r.referenceSource === "YESTERDAY"
        ? "H-1 Kemarin"
        : "Data Awal";

    let totalTankLiters = 0;
    const tankValues = tankNames.map((tName) => {
      const lv =
        r.tankLevels && r.tankLevels[tName] !== undefined
          ? Number(r.tankLevels[tName])
          : STANDARD_TANK_NUMBER;
      totalTankLiters += lv;
      return lv;
    });

    const rowCells = [];
    let colCursor = 0;

    // 1. No
    rowCells.push(makeCellXml(colCursor++, excelRowNum, rowIdx + 1, 5, true));
    // 2. Tanggal
    rowCells.push(makeCellXml(colCursor++, excelRowNum, r.displayDate || r.dateId, 5, false));
    // 3. Flowmeter Hari Ini
    rowCells.push(makeCellXml(colCursor++, excelRowNum, Number(r.flowmeterToday || 0), 6, true));
    // 4. Flowmeter Pengurang
    rowCells.push(makeCellXml(colCursor++, excelRowNum, Number(r.flowmeterReference || 0), 6, true));
    // 5. Sumber Pengurang
    rowCells.push(makeCellXml(colCursor++, excelRowNum, refSourceLabel, 5, false));
    // 6. Metering kWh per Blok
    blockNames.forEach((bName) => {
      const bVal = r.kwhBlocks && r.kwhBlocks[bName] !== undefined ? Number(r.kwhBlocks[bName]) : 0;
      rowCells.push(makeCellXml(colCursor++, excelRowNum, bVal, 7, true));
    });
    // 7. Konsumsi BBM (Liter)
    rowCells.push(makeCellXml(colCursor++, excelRowNum, fuelNum, 6, true));
    // 8. Total Produksi (kWh)
    rowCells.push(makeCellXml(colCursor++, excelRowNum, kwhNum, 7, true));
    // 9. SFC Harian (L/kWh)
    rowCells.push(makeCellXml(colCursor++, excelRowNum, Number(sfcNum.toFixed(4)), 8, true));
    // 10. Status Kontrak SFC
    rowCells.push(makeCellXml(colCursor++, excelRowNum, status.label, statusStyleId, false));
    // 11. Level Tangki BBM per Unit
    tankValues.forEach((lv) => {
      rowCells.push(makeCellXml(colCursor++, excelRowNum, lv, 6, true));
    });
    // 12. Total Tangki BBM (L)
    rowCells.push(makeCellXml(colCursor++, excelRowNum, totalTankLiters, 6, true));
    // 13. Keterangan BBM
    rowCells.push(makeCellXml(colCursor++, excelRowNum, remark, 4, false));

    sheetRowsXml.push(
      `<row r="${excelRowNum}" ht="20" customHeight="1">${rowCells.join("")}</row>`
    );
  });

  // Baris Ringkasan (Total BBM, Total kWh, Rata-rata SFC)
  const summaryRowNum = 5 + rows.length;
  const avgSfc = rows.length > 0 ? totalSfcSum / rows.length : 0;
  const avgStatus = evaluateSfcContractStatus(avgSfc);
  const summaryCells = [];
  let sumCol = 0;

  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, "", 12, false));
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, "TOTAL / RATA-RATA", 12, false));
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, "", 12, false));
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, "", 12, false));
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, `${rows.length} Hari`, 12, false));
  blockNames.forEach(() => {
    summaryCells.push(makeCellXml(sumCol++, summaryRowNum, "", 12, false));
  });
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, totalFuelSum, 13, true));
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, Number(totalKwhSum.toFixed(2)), 14, true));
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, Number(avgSfc.toFixed(4)), 15, true));
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, `Rata-rata: ${avgStatus.label}`, 12, false));
  tankNames.forEach(() => {
    summaryCells.push(makeCellXml(sumCol++, summaryRowNum, "", 12, false));
  });
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, "", 12, false));
  summaryCells.push(makeCellXml(sumCol++, summaryRowNum, "", 12, false));

  sheetRowsXml.push(
    `<row r="${summaryRowNum}" ht="22" customHeight="1">${summaryCells.join("")}</row>`
  );

  const sheet1Xml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
    colsXml +
    `<sheetData>${sheetRowsXml.join("")}</sheetData>` +
    `<mergeCells count="2">` +
    `<mergeCell ref="A1:${lastColLetter}1"/>` +
    `<mergeCell ref="A2:${lastColLetter}2"/>` +
    `</mergeCells>` +
    `</worksheet>`;

  const stylesXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
    `<numFmts count="3">` +
    `<numFmt numFmtId="164" formatCode="#,##0"/>` +
    `<numFmt numFmtId="165" formatCode="#,##0.00"/>` +
    `<numFmt numFmtId="166" formatCode="0.0000"/>` +
    `</numFmts>` +
    `<fonts count="7">` +
    `<font><sz val="10"/><color rgb="FF0F172A"/><name val="Calibri"/></font>` +
    `<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>` +
    `<font><b/><sz val="13"/><color rgb="FF0B132B"/><name val="Calibri"/></font>` +
    `<font><b/><sz val="10"/><color rgb="FF0F172A"/><name val="Calibri"/></font>` +
    `<font><b/><sz val="10"/><color rgb="FF065F46"/><name val="Calibri"/></font>` +
    `<font><b/><sz val="10"/><color rgb="FF92400E"/><name val="Calibri"/></font>` +
    `<font><b/><sz val="10"/><color rgb="FF991B1B"/><name val="Calibri"/></font>` +
    `</fonts>` +
    `<fills count="7">` +
    `<fill><patternFill patternType="none"/></fill>` +
    `<fill><patternFill patternType="gray125"/></fill>` +
    `<fill><patternFill patternType="solid"><fgColor rgb="FF0B132B"/><bgColor indexed="64"/></patternFill></fill>` +
    `<fill><patternFill patternType="solid"><fgColor rgb="FFE2E8F0"/><bgColor indexed="64"/></patternFill></fill>` +
    `<fill><patternFill patternType="solid"><fgColor rgb="FFD1FAE5"/><bgColor indexed="64"/></patternFill></fill>` +
    `<fill><patternFill patternType="solid"><fgColor rgb="FFFEF3C7"/><bgColor indexed="64"/></patternFill></fill>` +
    `<fill><patternFill patternType="solid"><fgColor rgb="FFFEE2E2"/><bgColor indexed="64"/></patternFill></fill>` +
    `</fills>` +
    `<borders count="2">` +
    `<border><left/><right/><top/><bottom/><diagonal/></border>` +
    `<border>` +
    `<left style="thin"><color rgb="FFCBD5E1"/></left>` +
    `<right style="thin"><color rgb="FFCBD5E1"/></right>` +
    `<top style="thin"><color rgb="FFCBD5E1"/></top>` +
    `<bottom style="thin"><color rgb="FFCBD5E1"/></bottom>` +
    `<diagonal/>` +
    `</border>` +
    `</borders>` +
    `<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>` +
    `<cellXfs count="16">` +
    `<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>` +
    `<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"><alignment vertical="center"/></xf>` +
    `<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1"><alignment vertical="center"/></xf>` +
    `<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>` +
    `<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>` +
    `<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>` +
    `<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>` +
    `<xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>` +
    `<xf numFmtId="166" fontId="3" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>` +
    `<xf numFmtId="0" fontId="4" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>` +
    `<xf numFmtId="0" fontId="5" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>` +
    `<xf numFmtId="0" fontId="6" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>` +
    `<xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>` +
    `<xf numFmtId="164" fontId="3" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>` +
    `<xf numFmtId="165" fontId="3" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>` +
    `<xf numFmtId="166" fontId="3" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>` +
    `</cellXfs>` +
    `</styleSheet>`;

  const workbookXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">` +
    `<sheets><sheet name="Laporan Harian SFC" sheetId="1" r:id="rId1"/></sheets>` +
    `</workbook>`;

  const workbookRelsXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>` +
    `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
    `</Relationships>`;

  const rootRelsXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>` +
    `</Relationships>`;

  const contentTypesXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
    `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
    `<Default Extension="xml" ContentType="application/xml"/>` +
    `<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>` +
    `<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>` +
    `<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>` +
    `</Types>`;

  return createZipArchive([
    { name: "[Content_Types].xml", content: contentTypesXml },
    { name: "_rels/.rels", content: rootRelsXml },
    { name: "xl/workbook.xml", content: workbookXml },
    { name: "xl/_rels/workbook.xml.rels", content: workbookRelsXml },
    { name: "xl/styles.xml", content: stylesXml },
    { name: "xl/worksheets/sheet1.xml", content: sheet1Xml }
  ]);
}

/**
 * Ekspor & Bagikan Laporan ke File Excel / Spreadsheet (.xlsx)
 * Mendukung penuh:
 * 1. Aplikasi Android APK Capacitor (via @capacitor/filesystem & @capacitor/share)
 * 2. Browser Mobile Chrome / Web Share API (File .xlsx)
 * 3. Browser Desktop & Mobile Download (dengan penundaan revokeObjectURL 60 detik)
 */
async function exportReportsToExcel(forceShare = false) {
  const rows = getFilteredLogs();
  if (rows.length === 0) {
    showFeedback("Tidak ada data laporan pada rentang tanggal ini untuk diekspor.", "error");
    return;
  }

  try {
    const xlsxBytes = buildXlsxWorkbookBytes(rows);
    const siteSlug = getActiveSiteId().toUpperCase();
    const fileName = `Sewatama_SFC_${siteSlug}_${getTodayDateString()}.xlsx`;
    const mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    // LAYER 1: Native Android Capacitor APK (Filesystem + Share Plugin)
    const cap = window.Capacitor;
    const isNative = Boolean(cap && typeof cap.isNativePlatform === "function" && cap.isNativePlatform());
    const fsPlugin = cap && cap.Plugins && cap.Plugins.Filesystem;
    const sharePlugin = cap && cap.Plugins && cap.Plugins.Share;

    if (isNative && fsPlugin) {
      const base64Data = uint8ArrayToBase64(xlsxBytes);
      let savedDocPath = "";

      // Coba simpan salinan langsung ke folder DOCUMENTS HP jika diizinkan OS Android
      try {
        await fsPlugin.writeFile({
          path: fileName,
          data: base64Data,
          directory: "DOCUMENTS",
          recursive: true
        });
        savedDocPath = `Documents/${fileName}`;
      } catch (docErr) {
        console.warn("Info simpan DOCUMENTS:", docErr);
      }

      // Selalu tulis ke CACHE (bebas izin di seluruh versi Android 8-15) lalu buka dialog Simpan/Bagikan
      const cacheRes = await fsPlugin.writeFile({
        path: fileName,
        data: base64Data,
        directory: "CACHE"
      });

      if (sharePlugin && cacheRes && cacheRes.uri) {
        await sharePlugin.share({
          title: fileName,
          text: `Laporan Harian Sewatama SFC — ${getActiveSiteName()} (Format Microsoft Excel / Spreadsheet .xlsx)`,
          url: cacheRes.uri,
          dialogTitle: "Simpan atau Buka File Excel (.xlsx)"
        });
        showFeedback(
          savedDocPath
            ? `File Excel berhasil disimpan di ${savedDocPath} & siap dibuka di Excel / Google Sheets.`
            : `File Excel (${fileName}) siap disimpan atau dibuka di Excel / Google Sheets.`
        );
        return;
      } else if (savedDocPath) {
        showFeedback(`File Excel berhasil disimpan di folder ${savedDocPath}!`);
        return;
      }
    }

    // LAYER 2: Web Share API (Jika user menekan tombol "Bagikan / Buka Spreadsheet" di HP)
    const blob = new Blob([xlsxBytes], { type: mimeType });
    if (forceShare && navigator.canShare && typeof File !== "undefined") {
      const excelFile = new File([blob], fileName, { type: mimeType });
      if (navigator.canShare({ files: [excelFile] })) {
        await navigator.share({
          title: fileName,
          text: `Laporan Harian Sewatama SFC — ${getActiveSiteName()} (.xlsx)`,
          files: [excelFile]
        });
        showFeedback(`File Excel (${fileName}) berhasil dibagikan.`);
        return;
      }
    }

    // LAYER 3: Download Browser Standar (Mobile Chrome & Desktop)
    // PENTING: Jangan panggil URL.revokeObjectURL secara instan agar Download Manager Android tidak gagal!
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.style.display = "none";
    link.href = url;
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
      URL.revokeObjectURL(url);
    }, 60000);

    showFeedback(`File Excel (${fileName}) berhasil diunduh! Siap dibuka di Microsoft Excel atau Google Sheets.`);
  } catch (err) {
    console.error("Gagal mengekspor file Excel:", err);
    showFeedback(`Gagal mengekspor Excel: ${err.message || "Terjadi kesalahan"}`, "error");
  }
}

function switchNavTab(targetId) {
  const navTabs = document.querySelectorAll(".nav-tab");
  navTabs.forEach((t) => {
    if (t.getAttribute("data-target") === targetId) {
      t.classList.add("active");
    } else {
      t.classList.remove("active");
    }
  });

  ["tab-admin", "tab-dashboard", "tab-reports", "tab-settings"].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (id === targetId) {
      el.classList.remove("hidden");
    } else {
      el.classList.add("hidden");
    }
  });
}

/**
 * Perbarui tampilan identitas Unit PLTD aktif & Mode Super User Admin di Header / Kontrol
 */
function updateActiveSiteUiLabels() {
  const isAdmin = isAdminSession();
  const siteId = getActiveSiteId();
  const siteName = getActiveSiteName();
  const logsPath = getLogsCollectionPath(siteId);

  if (activeSiteBadge) {
    activeSiteBadge.textContent = isAdmin
      ? `ADMIN PUSAT · ${siteName}`
      : siteName;
  }
  if (settingsActiveSiteName) {
    settingsActiveSiteName.textContent = `${siteName} (username: ${siteId})`;
  }
  if (settingsActiveDbPath) {
    settingsActiveDbPath.textContent = logsPath;
  }
  if (resetDbSiteLabel) {
    resetDbSiteLabel.textContent = siteName;
  }

  if (isAdmin) {
    if (adminControlBar) adminControlBar.classList.remove("hidden");
    if (navTabAdmin) navTabAdmin.classList.remove("hidden");
    if (adminActiveBranchTitle) {
      adminActiveBranchTitle.textContent = `${siteName} (username: ${siteId})`;
    }
    if (adminBranchSelect) {
      pltdAccountsCache = getStoredPltdAccounts();
      adminBranchSelect.innerHTML = pltdAccountsCache
        .map(
          (acc) =>
            `<option value="${acc.username}" ${acc.username === siteId ? "selected" : ""}>${acc.siteName} (login: ${acc.username})</option>`
        )
        .join("");
    }
  } else {
    if (adminControlBar) adminControlBar.classList.add("hidden");
    if (navTabAdmin) navTabAdmin.classList.add("hidden");
    const tabAdminEl = document.getElementById("tab-admin");
    if (tabAdminEl && !tabAdminEl.classList.contains("hidden")) {
      switchNavTab("tab-dashboard");
    }
  }
}

/**
 * Muat & tampilkan tabel Monitoring Hasil Perhitungan SFC Seluruh Cabang PLTD (Khusus Admin)
 */
async function loadAllBranchesSummaryForAdmin() {
  if (!isAdminSession() || !adminAllBranchesTbody) return;
  pltdAccountsCache = getStoredPltdAccounts();
  const activeSiteId = getActiveSiteId();
  const currentMonthPrefix = getTodayDateString().slice(0, 7);

  try {
    const rowsHtml = await Promise.all(
      pltdAccountsCache.map(async (branch) => {
        const logsPath = getLogsCollectionPath(branch.username);
        let branchLogs = [];
        try {
          const snap = await getDocs(collection(db, logsPath));
          snap.forEach((d) => {
            branchLogs.push({ dateId: d.id, ...d.data() });
          });
          branchLogs.sort((a, b) => (a.dateId < b.dateId ? 1 : -1));
        } catch (err) {
          console.warn(`Gagal mengambil log cabang ${branch.username}:`, err);
        }

        const latest = branchLogs[0] || null;
        const mtdLogs = branchLogs.filter((l) =>
          String(l.dateId || "").startsWith(currentMonthPrefix)
        );
        const avgMtd =
          mtdLogs.length > 0
            ? mtdLogs.reduce((acc, item) => acc + Number(item.sfc || 0), 0) / mtdLogs.length
            : 0;
        const totalFuelMtd = mtdLogs.reduce((acc, item) => acc + Number(item.fuelConsumed || 0), 0);
        const totalKwhMtd = mtdLogs.reduce(
          (acc, item) => acc + Number(item.totalKwhProduced || 0),
          0
        );

        const latestStatus = latest ? evaluateSfcContractStatus(latest.sfc) : evaluateSfcContractStatus(0);
        const mtdStatus = evaluateSfcContractStatus(avgMtd);
        const isSelected = branch.username === activeSiteId;

        return `
          <tr style="${isSelected ? "background: rgba(251, 191, 36, 0.08);" : ""}">
            <td style="font-weight: 700; color: ${isSelected ? "#fbbf24" : "#f1f5f9"};">
              ${branch.siteName} ${isSelected ? "· [Sedang Dikelola]" : ""}
            </td>
            <td class="mono-num">${branch.username}</td>
            <td class="mono-num">${latest ? latest.displayDate : "Belum ada input"}</td>
            <td class="mono-num ${latestStatus.textClass}" style="font-weight: 700;">
              ${latest ? Number(latest.sfc).toFixed(4) : "-"}
            </td>
            <td class="mono-num ${mtdStatus.textClass}" style="font-weight: 700;">
              ${mtdLogs.length > 0 ? `${avgMtd.toFixed(4)} (${mtdLogs.length} hr)` : "-"}
            </td>
            <td class="mono-num">
              ${totalFuelMtd.toLocaleString("id-ID")} L / ${formatKwhDisplay(totalKwhMtd)} kWh
            </td>
            <td style="font-size: 11px;" class="${latest ? latestStatus.textClass : ""}">
              ${latest ? latestStatus.label : "Belum ada data"}
            </td>
            <td>
              <div style="display: flex; gap: 6px;">
                <button type="button" class="btn btn-primary btn-xs btn-admin-input-branch" data-username="${branch.username}" style="width: auto;">
                  Input SMS / Dashboard
                </button>
                <button type="button" class="btn btn-secondary btn-xs btn-admin-edit-branch" data-username="${branch.username}">
                  Edit / Riwayat SFC
                </button>
              </div>
            </td>
          </tr>
        `;
      })
    );

    adminAllBranchesTbody.innerHTML = rowsHtml.join("");

    adminAllBranchesTbody.querySelectorAll(".btn-admin-input-branch").forEach((btn) => {
      btn.addEventListener("click", () => {
        const u = btn.getAttribute("data-username");
        const target = pltdAccountsCache.find((a) => a.username === u);
        if (!target) return;
        setAdminManagedSite(target);
        loadLocalSettingsForActiveSite();
        updateActiveSiteUiLabels();
        renderPltdAccountsList();
        startRealtimeListeners();
        switchNavTab("tab-dashboard");
        showFeedback(
          `Mode Admin: Siap menginput data SFC (kiriman SMS/offline) untuk ${target.siteName}.`
        );
      });
    });

    adminAllBranchesTbody.querySelectorAll(".btn-admin-edit-branch").forEach((btn) => {
      btn.addEventListener("click", () => {
        const u = btn.getAttribute("data-username");
        const target = pltdAccountsCache.find((a) => a.username === u);
        if (!target) return;
        setAdminManagedSite(target);
        loadLocalSettingsForActiveSite();
        updateActiveSiteUiLabels();
        renderPltdAccountsList();
        startRealtimeListeners();
        switchNavTab("tab-reports");
        showFeedback(
          `Mode Admin: Menampilkan tabel Riwayat & Edit SFC untuk ${target.siteName}.`
        );
      });
    });
  } catch (err) {
    console.error("Gagal memuat ringkasan cabang untuk Admin:", err);
  }
}

/**
 * Render daftar akun cabang PLTD di Panel Admin (mendukung Pilih Cabang & Hapus Akun yang tidak beroperasi)
 */
function renderPltdAccountsList() {
  if (!pltdAccountsListEl) return;
  if (!isAdminSession()) {
    pltdAccountsListEl.innerHTML = "";
    return;
  }

  const activeSiteId = getActiveSiteId();
  pltdAccountsCache = getStoredPltdAccounts();

  pltdAccountsListEl.innerHTML = pltdAccountsCache
    .map((acc) => {
      const isCurrent = acc.username === activeSiteId;
      const dbPath = getLogsCollectionPath(acc.username);
      const canDelete = pltdAccountsCache.length > 1;
      return `
        <div class="tank-row" style="margin-bottom: 0; display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap; border-color: ${isCurrent ? "rgba(251, 191, 36, 0.55)" : "rgba(148, 163, 184, 0.2)"};">
          <div>
            <div style="font-size: 13px; font-weight: 700; color: ${isCurrent ? "#fbbf24" : "#f1f5f9"};">
              ${acc.siteName} ${isCurrent ? "· [SEDANG DIKELOLA ADMIN]" : ""}
            </div>
            <div class="mono-num" style="font-size: 11px; color: #94a3b8;">
              Username Cabang: <strong>${acc.username}</strong> · Password: <strong>${acc.password}</strong> · Database: ${dbPath}
            </div>
          </div>
          <div style="display: flex; gap: 6px; align-items: center;">
            ${
              !isCurrent
                ? `<button type="button" class="btn btn-secondary btn-xs btn-switch-pltd" data-username="${acc.username}">Kelola Cabang Ini</button>`
                : ""
            }
            ${
              canDelete
                ? `<button type="button" class="btn btn-danger btn-xs btn-delete-pltd" data-username="${acc.username}">Hapus Akun Cabang</button>`
                : ""
            }
          </div>
        </div>
      `;
    })
    .join("");

  pltdAccountsListEl.querySelectorAll(".btn-switch-pltd").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetUser = btn.getAttribute("data-username");
      const targetAcc = pltdAccountsCache.find((a) => a.username === targetUser);
      if (!targetAcc) return;
      setAdminManagedSite(targetAcc);
      loadLocalSettingsForActiveSite();
      updateActiveSiteUiLabels();
      renderPltdAccountsList();
      startRealtimeListeners();
      showFeedback(`Admin kini mengelola ${targetAcc.siteName} (Database: ${getLogsCollectionPath(targetAcc.username)}).`);
    });
  });

  pltdAccountsListEl.querySelectorAll(".btn-delete-pltd").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const targetUser = btn.getAttribute("data-username");
      if (!targetUser || targetUser === "admin") return;
      if (pltdAccountsCache.length <= 1) {
        showFeedback("Minimal harus tersisa 1 akun cabang PLTD di dalam sistem.", "error");
        return;
      }
      removeLocalPltdAccount(targetUser);
      try {
        await deleteDoc(doc(db, PLTD_ACCOUNTS_COLLECTION, targetUser));
      } catch (err) {
        console.warn("Info hapus akun di Firestore:", err);
      }
      const remaining = getStoredPltdAccounts();
      if (getActiveSiteId() === targetUser && remaining.length > 0) {
        setAdminManagedSite(remaining[0]);
        loadLocalSettingsForActiveSite();
      }
      updateActiveSiteUiLabels();
      renderPltdAccountsList();
      startRealtimeListeners();
      showFeedback(`Akun cabang PLTD (${targetUser}) yang tidak digunakan berhasil dihapus oleh Administrator.`);
    });
  });
}

function loadLocalSettingsForActiveSite() {
  const siteKey = getLocalSettingsStorageKey();
  const savedLocal = localStorage.getItem(siteKey);
  if (savedLocal) {
    try {
      appSettings = { ...getDefaultAppSettings(), ...JSON.parse(savedLocal) };
    } catch (e) {
      appSettings = getDefaultAppSettings();
    }
  } else {
    appSettings = getDefaultAppSettings();
  }
  renderDynamicForms();
}

/**
 * Real-time Listener (onSnapshot) pada koleksi `daily_logs` dan `settings` sesuai Unit PLTD aktif
 */
function startRealtimeListeners() {
  if (unsubscribeLogs) unsubscribeLogs();
  if (unsubscribeSettings) unsubscribeSettings();
  if (unsubscribeAccounts) unsubscribeAccounts();

  dailyLogsCache = [];
  refreshDashboardAndReports();
  updateActiveSiteUiLabels();

  const activeSiteId = getActiveSiteId();
  const logsCollectionPath = getLogsCollectionPath(activeSiteId);
  const settingsCollectionPath = getSettingsCollectionPath(activeSiteId);

  const colRef = collection(db, logsCollectionPath);
  unsubscribeLogs = onSnapshot(
    colRef,
    { includeMetadataChanges: true },
    (snapshot) => {
      const isOffline = snapshot.metadata.fromCache && !navigator.onLine;
      updateConnectionIndicator(!isOffline);

      const docs = [];
      snapshot.forEach((docSnap) => {
        docs.push({ dateId: docSnap.id, ...docSnap.data() });
      });

      docs.sort((a, b) => (a.dateId < b.dateId ? 1 : -1));
      dailyLogsCache = docs;

      refreshDashboardAndReports();
      inspectYesterdayReference(inputDate.value);
      if (isAdminSession()) {
        loadAllBranchesSummaryForAdmin();
      }
    },
    (error) => {
      console.error("Error onSnapshot daily_logs:", error);
      updateConnectionIndicator(false);
    }
  );

  const settingsRef = doc(db, settingsCollectionPath, BASELINE_DOC_ID);
  unsubscribeSettings = onSnapshot(
    settingsRef,
    (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        appSettings = {
          flowmeterBaseline: data.flowmeterBaseline || "1250000",
          blocks: Array.isArray(data.blocks) && data.blocks.length ? data.blocks : ["Blok 1", "Blok 2"],
          tanks: Array.isArray(data.tanks) && data.tanks.length ? data.tanks : ["Tangki 1", "Tangki 2"],
          blockBaselines: data.blockBaselines || { "Blok 1": "4500000.00", "Blok 2": "4800000.00" }
        };
        localStorage.setItem(getLocalSettingsStorageKey(activeSiteId), JSON.stringify(appSettings));
        renderDynamicForms();
      } else {
        loadLocalSettingsForActiveSite();
      }
    },
    (err) => {
      console.warn("Menggunakan pengaturan Data Awal lokal:", err);
    }
  );

  const accountsColRef = collection(db, PLTD_ACCOUNTS_COLLECTION);
  unsubscribeAccounts = onSnapshot(
    accountsColRef,
    (snapshot) => {
      const remoteAccounts = [];
      snapshot.forEach((d) => {
        remoteAccounts.push(d.data());
      });
      if (remoteAccounts.length > 0) {
        syncLocalPltdAccounts(remoteAccounts);
      }
      updateActiveSiteUiLabels();
      renderPltdAccountsList();
      if (isAdminSession()) {
        loadAllBranchesSummaryForAdmin();
      }
    },
    (err) => {
      console.warn("Menggunakan daftar akun PLTD lokal:", err);
      renderPltdAccountsList();
      if (isAdminSession()) {
        loadAllBranchesSummaryForAdmin();
      }
    }
  );
}

async function saveSettingsToFirestore() {
  const activeSiteId = getActiveSiteId();
  localStorage.setItem(getLocalSettingsStorageKey(activeSiteId), JSON.stringify(appSettings));
  try {
    await setDoc(doc(db, getSettingsCollectionPath(activeSiteId), BASELINE_DOC_ID), {
      flowmeterBaseline: appSettings.flowmeterBaseline,
      blockBaselines: appSettings.blockBaselines,
      blocks: appSettings.blocks,
      tanks: appSettings.tanks,
      updatedAt: Date.now(),
      operator: activeSiteId
    });
    showFeedback(`Konfigurasi Data Awal (Baseline) untuk ${getActiveSiteName()} berhasil disimpan.`);
  } catch (err) {
    console.error("Gagal menyimpan pengaturan ke Firestore:", err);
    showFeedback("Disimpan di perangkat lokal (menunggu koneksi Firestore).", "error");
  }
}

/**
 * Inisialisasi Aplikasi
 */
function initApp() {
  loadLocalSettingsForActiveSite();
  inputDate.value = getTodayDateString();
  renderDynamicForms();
  renderPltdAccountsList();

  // Toggle Ganti Alat Meter pada Flowmeter di Dashboard
  if (checkReplaceFlowmeter && replaceFlowmeterBox) {
    checkReplaceFlowmeter.addEventListener("change", () => {
      if (checkReplaceFlowmeter.checked) {
        replaceFlowmeterBox.classList.remove("hidden");
      } else {
        replaceFlowmeterBox.classList.add("hidden");
      }
    });
  }

  // Toggle Ganti Alat Meter pada Flowmeter di Modal Edit
  if (editCheckReplaceFlowmeter && editReplaceFlowmeterBox) {
    editCheckReplaceFlowmeter.addEventListener("change", () => {
      if (editCheckReplaceFlowmeter.checked) {
        editReplaceFlowmeterBox.classList.remove("hidden");
      } else {
        editReplaceFlowmeterBox.classList.add("hidden");
      }
    });
  }

  const session = getActiveSession();
  if (session) {
    loginView.classList.add("hidden");
    mainApp.classList.remove("hidden");
    updateActiveSiteUiLabels();
    startRealtimeListeners();
  } else {
    loginView.classList.remove("hidden");
    mainApp.classList.add("hidden");
  }

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = document.getElementById("login-username").value;
    const p = document.getElementById("login-password").value;
    let res = loginOperator(u, p);

    // Jika belum ditemukan di cache lokal, cek ke koleksi Firestore pltd_accounts
    if (!res.success) {
      const cleanUser = sanitizeAccountId(u);
      if (cleanUser) {
        try {
          const remoteAccSnap = await getDoc(doc(db, PLTD_ACCOUNTS_COLLECTION, cleanUser));
          if (remoteAccSnap.exists()) {
            const remoteAcc = remoteAccSnap.data();
            saveLocalPltdAccount(remoteAcc);
            res = loginOperator(u, p);
          }
        } catch (err) {
          console.warn("Gagal memeriksa akun di Firestore:", err);
        }
      }
    }

    if (res.success) {
      loginError.classList.add("hidden");
      loginView.classList.add("hidden");
      mainApp.classList.remove("hidden");
      loadLocalSettingsForActiveSite();
      updateActiveSiteUiLabels();
      renderPltdAccountsList();
      startRealtimeListeners();
      if (isAdminSession()) {
        switchNavTab("tab-admin");
      } else {
        switchNavTab("tab-dashboard");
      }
    } else {
      loginError.textContent = res.message;
      loginError.classList.remove("hidden");
    }
  });

  btnLogout.addEventListener("click", () => {
    logoutOperator();
    if (unsubscribeLogs) unsubscribeLogs();
    if (unsubscribeSettings) unsubscribeSettings();
    if (unsubscribeAccounts) unsubscribeAccounts();
    mainApp.classList.add("hidden");
    loginView.classList.remove("hidden");
  });

  if (adminBranchSelect) {
    adminBranchSelect.addEventListener("change", () => {
      if (!isAdminSession()) return;
      const targetUser = adminBranchSelect.value;
      const targetAcc = pltdAccountsCache.find((a) => a.username === targetUser);
      if (!targetAcc) return;
      setAdminManagedSite(targetAcc);
      loadLocalSettingsForActiveSite();
      updateActiveSiteUiLabels();
      renderPltdAccountsList();
      startRealtimeListeners();
      showFeedback(
        `Mode Admin: Beralih ke cabang ${targetAcc.siteName}. Anda dapat menginput data SFC (kiriman SMS) atau mengedit riwayat cabang ini.`
      );
    });
  }

  if (btnGotoAdminPanel) {
    btnGotoAdminPanel.addEventListener("click", () => {
      if (isAdminSession()) {
        switchNavTab("tab-admin");
        loadAllBranchesSummaryForAdmin();
      }
    });
  }

  if (btnRefreshAllBranches) {
    btnRefreshAllBranches.addEventListener("click", () => {
      if (isAdminSession()) {
        loadAllBranchesSummaryForAdmin();
        showFeedback("Data ringkasan seluruh cabang PLTD berhasil dimuat ulang.");
      }
    });
  }

  if (addPltdAccountForm) {
    addPltdAccountForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!isAdminSession()) {
        showFeedback("Hanya Administrator (akun admin) yang diizinkan menambah cabang PLTD baru.", "error");
        return;
      }
      const rawUser = newPltdUsernameInput ? newPltdUsernameInput.value : "";
      const cleanUser = sanitizeAccountId(rawUser);
      const siteName = String(newPltdSitenameInput ? newPltdSitenameInput.value : "").trim();
      const password = String(newPltdPasswordInput ? newPltdPasswordInput.value : "sewatama").trim();

      if (!cleanUser || cleanUser === "admin") {
        showFeedback("Gunakan kode username cabang yang valid (selain 'admin').", "error");
        return;
      }
      if (!siteName || !password) {
        showFeedback("Username, Nama Unit PLTD, dan Password wajib diisi.", "error");
        return;
      }

      const accountPayload = {
        username: cleanUser,
        password,
        siteName,
        createdAt: Date.now()
      };

      saveLocalPltdAccount(accountPayload);
      try {
        await setDoc(doc(db, PLTD_ACCOUNTS_COLLECTION, cleanUser), accountPayload);
      } catch (err) {
        console.warn("Akun disimpan lokal (menunggu sinkronisasi Firestore):", err);
      }

      if (newPltdUsernameInput) newPltdUsernameInput.value = "";
      if (newPltdSitenameInput) newPltdSitenameInput.value = "";
      if (newPltdPasswordInput) newPltdPasswordInput.value = "sewatama";

      updateActiveSiteUiLabels();
      renderPltdAccountsList();
      loadAllBranchesSummaryForAdmin();
      showFeedback(
        `Akun cabang ${siteName} (username: ${cleanUser}) berhasil ditambahkan oleh Admin! Database terisolasi siap di: sites/${cleanUser}/daily_logs`
      );
    });
  }

  inputDate.addEventListener("change", () => {
    inspectYesterdayReference(inputDate.value);
    updateDashboardLockState();
    refreshDashboardAndReports();
  });

  if (btnUnlockEditToday) {
    btnUnlockEditToday.addEventListener("click", () => {
      if (inputDate && inputDate.value) {
        openEditModal(inputDate.value);
      }
    });
  }

  dailyInputForm.addEventListener("submit", handleDailySubmit);

  if (btnCopyWaDashboard) {
    btnCopyWaDashboard.addEventListener("click", copyWhatsAppSummary);
  }

  if (editLogForm) {
    editLogForm.addEventListener("submit", handleEditLogSubmit);
  }
  if (btnCloseEditModal) {
    btnCloseEditModal.addEventListener("click", closeEditModal);
  }
  if (btnCancelEdit) {
    btnCancelEdit.addEventListener("click", closeEditModal);
  }

  filterStartDate.addEventListener("change", renderReportsTable);
  filterEndDate.addEventListener("change", renderReportsTable);
  btnResetFilter.addEventListener("click", () => {
    filterStartDate.value = "";
    filterEndDate.value = "";
    renderReportsTable();
  });
  if (btnExportCsv) {
    btnExportCsv.addEventListener("click", () => exportReportsToExcel(false));
  }
  if (btnShareExcel) {
    btnShareExcel.addEventListener("click", () => exportReportsToExcel(true));
  }

  settingsBaselineForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    appSettings.flowmeterBaseline = sanitizeNumericInput(baselineFlowmeterInput.value) || "0";
    const blockBaseInputs = document.querySelectorAll(".baseline-block-input");
    blockBaseInputs.forEach((inp) => {
      const bName = inp.getAttribute("data-block-name");
      appSettings.blockBaselines[bName] = sanitizeKwhDecimalInput(inp.value) || "0.00";
    });
    await saveSettingsToFirestore();
    inspectYesterdayReference(inputDate.value);
  });

  btnAddBlock.addEventListener("click", async () => {
    const nextNum = appSettings.blocks.length + 1;
    const newBlockName = `Blok ${nextNum}`;
    appSettings.blocks.push(newBlockName);
    appSettings.blockBaselines[newBlockName] = "0.00";
    renderDynamicForms();
    await saveSettingsToFirestore();
  });

  btnRemoveBlock.addEventListener("click", async () => {
    if (appSettings.blocks.length <= 1) {
      showFeedback("Minimal harus terdapat 1 Blok kWh.", "error");
      return;
    }
    const removed = appSettings.blocks.pop();
    delete appSettings.blockBaselines[removed];
    renderDynamicForms();
    await saveSettingsToFirestore();
  });

  btnAddTank.addEventListener("click", async () => {
    const nextNum = appSettings.tanks.length + 1;
    appSettings.tanks.push(`Tangki ${nextNum}`);
    renderDynamicForms();
    await saveSettingsToFirestore();
  });

  btnRemoveTank.addEventListener("click", async () => {
    if (appSettings.tanks.length <= 1) {
      showFeedback("Minimal harus terdapat 1 Tangki BBM.", "error");
      return;
    }
    appSettings.tanks.pop();
    renderDynamicForms();
    await saveSettingsToFirestore();
  });

  btnResetDb.addEventListener("click", async () => {
    try {
      const targetLogsPath = getLogsCollectionPath();
      const snap = await getDocs(collection(db, targetLogsPath));
      const deletions = [];
      snap.forEach((d) => {
        deletions.push(deleteDoc(doc(db, targetLogsPath, d.id)));
      });
      await Promise.all(deletions);
      showFeedback(`Seluruh data riwayat harian untuk ${getActiveSiteName()} berhasil dihapus dari database.`);
    } catch (err) {
      showFeedback(`Gagal mereset database: ${err.message}`, "error");
    }
  });

  const navTabs = document.querySelectorAll(".nav-tab");
  navTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const targetId = tab.getAttribute("data-target");
      if (targetId === "tab-admin" && !isAdminSession()) return;
      switchNavTab(targetId);
      if (targetId === "tab-admin") {
        loadAllBranchesSummaryForAdmin();
      }
    });
  });

  window.addEventListener("online", () => updateConnectionIndicator(true));
  window.addEventListener("offline", () => updateConnectionIndicator(false));
  updateConnectionIndicator(navigator.onLine);
}

document.addEventListener("DOMContentLoaded", initApp);
