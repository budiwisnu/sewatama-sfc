// public/auth.js
// Modul Autentikasi Operator Hardcoded untuk Sewatama SFC

const SESSION_STORAGE_KEY = "sewatama_sfc_operator_session";
const VALID_USERNAME = "ampenan";
const VALID_PASSWORD = "sewatama";

/**
 * Memvalidasi login operator secara hardcoded (ampenan / sewatama).
 * Jika valid, menyimpan sesi login ke dalam localStorage.
 *
 * @param {string} username
 * @param {string} password
 * @returns {{ success: boolean, message: string, session?: object }}
 */
export function loginOperator(username, password) {
  const cleanUser = String(username || "").trim().toLowerCase();
  const cleanPass = String(password || "").trim();

  if (!cleanUser || !cleanPass) {
    return {
      success: false,
      message: "Username dan password wajib diisi."
    };
  }

  if (cleanUser === VALID_USERNAME && cleanPass === VALID_PASSWORD) {
    const sessionData = {
      username: VALID_USERNAME,
      siteName: "PLTD Ampenan",
      role: "Operator Harian",
      loggedInAt: new Date().toISOString()
    };

    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(sessionData));

    return {
      success: true,
      message: "Login berhasil.",
      session: sessionData
    };
  }

  return {
    success: false,
    message: "Kredensial tidak valid. Gunakan akun operator resmi PLTD."
  };
}

/**
 * Mengambil sesi aktif dari localStorage
 * @returns {object|null}
 */
export function getActiveSession() {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.username === VALID_USERNAME) {
      return parsed;
    }
    return null;
  } catch (err) {
    console.error("Gagal membaca sesi:", err);
    return null;
  }
}

/**
 * Menghapus sesi operator dari localStorage
 */
export function logoutOperator() {
  localStorage.removeItem(SESSION_STORAGE_KEY);
}
