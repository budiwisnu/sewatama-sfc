// public/auth.js
// Modul Autentikasi Berjenjang (Role-Based Hierarchy) untuk Sewatama SFC:
// 1. Akun Super User / Administrator (admin / sewatama):
//    - Memantau hasil SFC seluruh cabang PLTD yang terdaftar
//    - Menambah akun cabang PLTD baru & menghapus akun cabang yang tidak beroperasi lagi
//    - Menginput data SFC (misal kiriman via SMS saat cabang offline) & mengedit hasil SFC seluruh cabang
// 2. Akun Operator Cabang PLTD (contoh: ampenan / sewatama, jakarta / sewatama):
//    - Hanya mengakses Dashboard, Input Harian, Reports, dan Settings milik PLTD-nya sendiri
//    - Tidak memiliki fitur manajemen akun cabang PLTD lain

const SESSION_STORAGE_KEY = "sewatama_sfc_operator_session";
const ACCOUNTS_STORAGE_KEY = "sewatama_sfc_pltd_accounts";

export const ADMIN_ACCOUNT = {
  username: "admin",
  password: "sewatama",
  siteName: "Administrator Pusat (Super User)",
  role: "admin"
};

/**
 * Daftar Akun Cabang PLTD Bawaan (Default).
 * Penambahan atau penghapusan cabang PLTD lain hanya dapat dilakukan oleh akun "admin".
 */
export const DEFAULT_PLTD_ACCOUNTS = [
  {
    username: "ampenan",
    password: "sewatama",
    siteName: "PLTD Ampenan",
    createdAt: 1700000000000
  }
];

export function sanitizeAccountId(raw) {
  return String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, "")
    .slice(0, 32);
}

/**
 * Mengambil seluruh daftar akun cabang PLTD (tidak termasuk akun 'admin')
 */
export function getStoredPltdAccounts() {
  const map = new Map();
  DEFAULT_PLTD_ACCOUNTS.forEach((acc) => {
    map.set(acc.username, { ...acc });
  });

  try {
    const raw = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        parsed.forEach((item) => {
          const cleanUser = sanitizeAccountId(item.username);
          if (cleanUser && cleanUser !== "admin" && item.password && item.siteName) {
            map.set(cleanUser, {
              username: cleanUser,
              password: String(item.password).trim(),
              siteName: String(item.siteName).trim(),
              createdAt: Number(item.createdAt || Date.now())
            });
          }
        });
      }
    }
  } catch (err) {
    console.warn("Gagal membaca daftar akun lokal:", err);
  }

  return Array.from(map.values());
}

/**
 * Menyimpan sinkronisasi daftar akun cabang PLTD dari Firestore ke localStorage
 */
export function syncLocalPltdAccounts(accountsList) {
  try {
    const map = new Map();
    DEFAULT_PLTD_ACCOUNTS.forEach((acc) => map.set(acc.username, { ...acc }));
    if (Array.isArray(accountsList)) {
      accountsList.forEach((acc) => {
        const cleanUser = sanitizeAccountId(acc.username);
        if (cleanUser && cleanUser !== "admin" && acc.password && acc.siteName) {
          map.set(cleanUser, {
            username: cleanUser,
            password: String(acc.password).trim(),
            siteName: String(acc.siteName).trim(),
            createdAt: Number(acc.createdAt || Date.now())
          });
        }
      });
    }
    localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(Array.from(map.values())));
  } catch (err) {
    console.warn("Gagal menyimpan sinkronisasi akun lokal:", err);
  }
}

/**
 * Menambahkan atau memperbarui 1 akun cabang PLTD ke penyimpanan lokal (Khusus Admin)
 */
export function saveLocalPltdAccount(account) {
  const cleanUser = sanitizeAccountId(account.username);
  if (!cleanUser || cleanUser === "admin") return null;
  const current = getStoredPltdAccounts().filter((a) => a.username !== cleanUser);
  const nextEntry = {
    username: cleanUser,
    password: String(account.password || "sewatama").trim(),
    siteName: String(account.siteName || `PLTD ${cleanUser.toUpperCase()}`).trim(),
    createdAt: Number(account.createdAt || Date.now())
  };
  current.push(nextEntry);
  localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(current));
  return nextEntry;
}

/**
 * Menghapus 1 akun cabang PLTD dari penyimpanan lokal (Khusus Admin)
 */
export function removeLocalPltdAccount(username) {
  const cleanUser = sanitizeAccountId(username);
  if (!cleanUser || cleanUser === "admin") return false;
  const filtered = getStoredPltdAccounts().filter((a) => a.username !== cleanUser);
  localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(filtered));
  return true;
}

/**
 * Memvalidasi login untuk Administrator ("admin" / "sewatama") maupun Operator Cabang PLTD.
 */
export function loginOperator(username, password, extraAccounts = []) {
  const cleanUser = sanitizeAccountId(username);
  const cleanPass = String(password || "").trim();

  if (!cleanUser || !cleanPass) {
    return {
      success: false,
      message: "Username dan password wajib diisi."
    };
  }

  if (extraAccounts && extraAccounts.length > 0) {
    syncLocalPltdAccounts(extraAccounts);
  }

  const allBranches = getStoredPltdAccounts();
  const defaultBranch = allBranches[0] || DEFAULT_PLTD_ACCOUNTS[0];

  // 1. Cek Login Super User Administrator (admin / sewatama)
  if (cleanUser === ADMIN_ACCOUNT.username && cleanPass === ADMIN_ACCOUNT.password) {
    const adminSession = {
      username: ADMIN_ACCOUNT.username,
      siteName: ADMIN_ACCOUNT.siteName,
      role: "admin",
      managedSiteId: defaultBranch.username,
      managedSiteName: defaultBranch.siteName,
      loggedInAt: new Date().toISOString()
    };
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(adminSession));
    return {
      success: true,
      message: "Login berhasil sebagai Administrator Pusat (Super User).",
      session: adminSession
    };
  }

  // 2. Cek Login Operator Cabang PLTD
  const matched = allBranches.find(
    (acc) => acc.username === cleanUser && acc.password === cleanPass
  );

  if (matched) {
    const userSession = {
      username: matched.username,
      siteName: matched.siteName,
      role: "user",
      managedSiteId: matched.username,
      managedSiteName: matched.siteName,
      loggedInAt: new Date().toISOString()
    };

    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(userSession));

    return {
      success: true,
      message: `Login berhasil ke ${matched.siteName}.`,
      session: userSession
    };
  }

  return {
    success: false,
    message: "Username atau password tidak sesuai. Pastikan akun PLTD sudah terdaftar oleh Administrator."
  };
}

/**
 * Memeriksa apakah sesi yang sedang aktif adalah Administrator ("admin")
 */
export function isAdminSession() {
  const s = getActiveSession();
  return Boolean(s && (s.role === "admin" || s.username === "admin"));
}

/**
 * Mengubah cabang PLTD yang sedang dikelola/diinspeksi oleh Admin (Hanya untuk role "admin")
 */
export function setAdminManagedSite(account) {
  const s = getActiveSession();
  if (!s || (s.role !== "admin" && s.username !== "admin")) return null;
  const cleanUser = sanitizeAccountId(account.username);
  if (!cleanUser || cleanUser === "admin") return null;

  const updatedSession = {
    ...s,
    managedSiteId: cleanUser,
    managedSiteName: String(account.siteName || `PLTD ${cleanUser.toUpperCase()}`)
  };
  localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(updatedSession));
  return updatedSession;
}

/**
 * Mengambil sesi aktif dari localStorage
 */
export function getActiveSession() {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const cleanUser = sanitizeAccountId(parsed && parsed.username);
    if (!cleanUser) return null;

    if (cleanUser === "admin" || parsed.role === "admin") {
      const branches = getStoredPltdAccounts();
      const fallbackBranch = branches[0] || DEFAULT_PLTD_ACCOUNTS[0];
      const managedId = sanitizeAccountId(parsed.managedSiteId) || fallbackBranch.username;
      const matchedBranch = branches.find((b) => b.username === managedId);
      return {
        username: "admin",
        siteName: ADMIN_ACCOUNT.siteName,
        role: "admin",
        managedSiteId: managedId,
        managedSiteName:
          (matchedBranch && matchedBranch.siteName) ||
          parsed.managedSiteName ||
          fallbackBranch.siteName,
        loggedInAt: parsed.loggedInAt || new Date().toISOString()
      };
    }

    return {
      username: cleanUser,
      siteName:
        parsed.siteName ||
        (cleanUser === "ampenan" ? "PLTD Ampenan" : `PLTD ${cleanUser.toUpperCase()}`),
      role: "user",
      managedSiteId: cleanUser,
      managedSiteName:
        parsed.siteName ||
        (cleanUser === "ampenan" ? "PLTD Ampenan" : `PLTD ${cleanUser.toUpperCase()}`),
      loggedInAt: parsed.loggedInAt || new Date().toISOString()
    };
  } catch (err) {
    console.error("Gagal membaca sesi:", err);
    return null;
  }
}

/**
 * Menghapus sesi operator/admin dari localStorage
 */
export function logoutOperator() {
  localStorage.removeItem(SESSION_STORAGE_KEY);
}
